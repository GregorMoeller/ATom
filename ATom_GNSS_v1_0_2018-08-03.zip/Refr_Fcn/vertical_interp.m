function  [pres1,hght1,temp1,wvpr1] = vertical_interp(pres,hght,temp,wvpr,phi,href,id)
% This function uses input matrices with values of pressure, temperature and water vapour at
% specific height levels and refines them using interpolation and extrapolation technique.
% 
%---------------------------------------------------------------------------------------------------
% 
% INPUT:
%       pres  ...   pressure values [hPa], p(i,j,k)
%       hght  ...   height values [m], hght(i,j,k)
%       temp  ...   temperature [K], temp(i,j,k)
%       wvpr  ...   water vapour pressure [hPa], wvpr(i,j,k)
%       phi   ...   POI latitude [�], phi
%       href  ...   POI orthometric height [m], href(i)
%       id    ...   defines interpolation method ('Pressure levels','GPT2w',...)
% 
% OUTPUT:
%       meteo parameters at point of interest (POI)
% 
%===================================================================================================

%% Define and calculate parameters

% gas constant (see scriptum Atmospheric Effects in Geodesy, equation (1.23))
R = 8314.459; % in [kg*m^2/(kmol*K*s^2)] = [J/(kmol*K)], % R = 8314.3;

% molar weight of water vapour and dry constituents (see scriptum Atmospheric Effects in Geodesy,
% equations (1.35) and (1.36))
Mw = 18.01528; % in [kg/kmol]
Md = 28.9645; % in [kg/kmol] % Md = 28.965; % in [kg/kmol]

% specific gas constants (see scriptum Atmospheric Effects in Geodesy, page 7 between eq. (1.27) and (1.28))
Rd = R/Md; % in [m^2/(K*s^2)] = [J/(kg*K)]

% transform station latitude from [�] to [rad]
phi=phi*pi/180;

% gravity values for all height levels (incl. extrapolated levels), see scriptum Atmospheric Effects in Geodesy, equation (1.64)
grav = 9.80665*(1-0.0026373*cos(2*phi) + 0.0000059*(cos(2*phi))^2)*(1-3.14e-7*hght); % in [m/s^2]    

% calculate virtual temperature
% see scriptum Atmospheric Effects in Geodesy, equation (1.67)
%vtem = temp.*(1+0.378*wvpr./pres);
vtem = temp.*pres./(pres - (1 - Mw/Md)*wvpr); % in [K]

% set negative values in wvpr to zero
wvpr(wvpr<0) = 0;

% Initialise variable
pres1 = zeros(length(href),1);
hght1 = zeros(length(href),1);
wvpr1 = zeros(length(href),1);
temp1 = zeros(length(href),1);

% Loop over POIs
for i = 1:length(href)    
    % Find closest pressure level
    [~,index] = min(abs(hght - href(i)));
    % Restore reference height
    hght1(i) = href(i);
    
    % reduce virtual temperature to mean height 
    %vtem_href = vtem(index) - (temp(index)-temp1(i))./2;
    hmean = href(i) - (href(i)-hght(index))./2;
    vtem_hmean = interp1(hght,vtem,hmean,'linear','extrap');
    
    % Interpolate pressure to height href 
    pres1(i) = pres(index)*exp(grav(index)/Rd/vtem_hmean*(hght(index)-href(i))); % see scriptum Atmospheric Effects in Geodesy, equation (1.50) or Nafisi et al. 2012, equation (20)
    
    if strcmp(id,'Pressure levels')
        % Increase if index <= 1
        if index <= 1; index = 2; end
        
        % Make sure that href is always between given pressure levels
        if hght(2) > hght(1) % ascending levels
            if href(i) > hght(index);   index = index + 1;
            elseif href(i) < hght(index-1); index = index - 1; end
        else            
            if href(i) < hght(index); index = index + 1;
            elseif href(i) > hght(index-1);   index = index - 1; end
        end       
        
        % Increase if index < 2 and decrease if index > max
        if index <= 1; index = 2; end
        if index >= length(hght); index = length(hght) - 1; end

        % Determine water vapour gradient
        if ~((wvpr(index-1)==0)||(wvpr(index)==0)||(wvpr(index)==wvpr(index-1)))
            c = (hght(index-1) - hght(index))/log(wvpr(index-1)./wvpr(index)); % see Nafisi et al. 2012, equation (23) or B�hm and Schuh 2003
            wvpr1(i) = wvpr(index)*exp((href(i) - hght(index))./c);
            % Write output to screen  
            %fprintf('%5.0f %7.2f %7.2f %5.3f %5.3f %8.4f %5.3f\n',href(i),hght(index-1),hght(index),wvpr(index-1),wvpr(index),c,wvpr1(i));
        else
            % if c would deliver inf, do linear interpolation for wvpr
            wvpr1(i) = interp1(hght,wvpr,href(i),'linear','extrap');
        end
        
        % linear interpolation for temperature values
        temp1(i) = interp1(hght,temp,href(i),'linear','extrap');   
        
        % Take value of lowest level if href is below given levels
        if href(i) < min(hght)
            wvpr1(i) = wvpr(index);
            temp1(i) = temp(index);
        end
        
    elseif strcmp(id,'GPT2w')
        % Extrapolate water vapour with gradient (lam) from GPT2w
        wvpr1(i) = wvpr(index).*(pres1(i)./pres(index)).^(gpt2w(2)+1);

        % Extrapolate temperature with gradient (dT) from GPT2w
        temp1(i) = temp(index) + gpt2w(1).* (href(i)-hght(index))/1000;
    end
end

% figure(1)
% hold on
% plot(wvpr,hght)
% plot(wvpr1,href,'x')
% hold off


