function  [pres1,hght1,temp1,wvpr1] = vertical_increment(pres,hght,temp,wvpr,phi,href,gpm)

% This function uses input vectors with values of pressure, temperature and water vapour at
% specific height levels and refines them using interpolation and extrapolation technique.

%---------------------------------------------------------------------------------------------------
% History:
% 
% jboehm 2003 Jul 2
%        2003 Aug 4
%        2003 Aug 18
%        2003 Aug 19
% 
% Armin Hofmeister
% 18.07.2013: added comments, changes in programming
% 19.07.2013: added comments, changes in programming
% 22.07.2013: added comments, changes in programming (i.e. if station height is higher than 2000 m)
% 23.07.2013: change input unit of phi from [rad] to [�]
% 29.07.2013: changes in programming
% 01.08.2013: change comments, changes in programming
% 18.09.2013: correct comments
% 19.09.2013: correct comments
% 07.07.2015: adapted to ATom software
% 
% 
%---------------------------------------------------------------------------------------------------
% 
% INPUT:
%       pres...   pressure values in [hPa], vector containing all levels
%       hght...   vector with height values in [m], maximum height should be at least 25km, vector containing all levels
%       temp...   temperature in [K], vector containing all levels
%       wvpr...   water vapour pressure in [hPa], vector containing all levels
%       phi....   latitude in [�], scalar for position (station)
%       href...   station height (orthometric) in [m], scalar
%       gpm....   defines type of height in variable hght
%                 1, if geopotential meters (=geopotential height = dynamic height)
%                 0, if geometric meters (= orthometric height)
% 
% 
% OUTPUT:
%       Vectors of input with same units, but with higher resolution, starting at the station height
%       (min. 0 if station height is negative) up to 136 km.
% 
% 
%===================================================================================================

%% Define and calculate parameters

% gas constant (see scriptum Atmospheric Effects in Geodesy, equation (1.23))
R = 8314.459; % in [kg*m^2/(kmol*K*s^2)] = [J/(kmol*K)]

% molar weight of water vapour and dry constituents (see scriptum Atmospheric Effects in Geodesy,
% equations (1.35) and (1.36))
Mw = 18.01528; % in [kg/kmol]
Md = 28.9645; % in [kg/kmol]

% specific gas constants (see scriptum Atmospheric Effects in Geodesy, page 7 between eq. (1.27) and (1.28))
Rd = R/Md; % in [m^2/(K*s^2)] = [J/(kg*K)]

% define transformation coefficient for conversion from [�] to [rad]
deg2rad=pi/180;

% transform station latitude from [�] to [rad]
phi=phi*deg2rad;

%% Prepare input data for further calculations

% conversion of geopotential meters (geopotential heights=dynamic heights) to meters above the geoid
% (geometric=orthometric heights)
% gpm  .. 1 if geopotential meters
%         0 if geometric meters
if gpm == 1
    hght = gpm2z(hght,phi);
end

%% Get maximum height and values for the other parameters there

[hmax,index] = max(hght);
tmax = temp(index);
pmax = pres(index);


%% Define standard model values for extrapolation of temperature and water vapour pressure above deliverd input height levels

% temperature values from Niell, email 2003 Aug 19 or see scriptum Atmospheric Effects in Geodesy, table 1.3
hext0 = [ 25000, 50000, 80000,100000,130000,150000];
text0 = [   220,   268,   200,   210,   533,   893];
eext0 = [     0,     0,     0,     0,     0,     0];


%% Extend height levels up to 150 km (extrapolation with standard model values)

% define vector of height levels used for extrapolation (25km - 150km)
% step-width is set to 5km
hext = 25000:5000:150000;

% linear extrapolation of temperature and water vapour for the interval (25km - 150km)
text = interp1(hext0,text0,hext,'linear','extrap');
eext = interp1(hext0,eext0,hext,'linear','extrap');

% use extrapolated values only above the maximum input height level
% --> set all extrapolated values below max. input height level to [] (--> delets the specific entry)
k = find (hext < hmax);
hext(k) = [];
text(k) = [];
eext(k) = [];

% define new intervals for extrapolation (starting with max. input height level)
hext = [hmax,hext];
text = [tmax,text];
eext = [   0,eext];

% pressure at highest input level
pext = pmax;


%%% find the corresponding pressure values for all levels above max. input height level --> extrapolation

% gravity values for extrapolated height levels, see scriptum Atmospheric Effects in Geodesy, equation (1.64)
gext = 9.80665*(1-0.0026373*cos(2*phi) + 0.0000059*(cos(2*phi))^2)*(1-3.14e-7*hext); % in [m/s^2]

% get pressure values
for i = 2:length(hext)
    % calculate mid-height level between two extrapolation levels
    hmid = (hext(i) + hext(i-1))/2;
    % calculate temperature and gravity values at the new mid-height level
    tmid = interp1(hext,text,hmid,'linear');
    gmid = interp1(hext,gext,hmid,'linear');
    % calculate pressure value for the space between two layers using te new mid-height level values
    % --> pressure values at extrapolation height levels are derived
    % see scriptum Atmospheric Effects in Geodesy, equation (1.50) or Nafisi et al. 2012, equation (20)
    pext(i) = pext(i-1)*exp(gmid/Rd/tmid*(hext(i-1)-hext(i))); % in [hPa] ???? equation for pressure ????
end

% add values of standard atmosphere (extrapolated values) above the maximum input height level
k = find(hext > hmax);
hght = [fliplr(hght), hext(k)];
pres = [fliplr(pres), pext(k)];
temp = [fliplr(temp), text(k)];
wvpr = [fliplr(wvpr), eext(k)];

% calculate virtual temperature
% see scriptum Atmospheric Effects in Geodesy, equation (1.67)
vtem = temp.*pres./(pres - (1 - Mw/Md)*wvpr); % in [K]

% gravity values for all height levels (incl. extrapolated levels), see scriptum Atmospheric Effects in Geodesy, equation (1.64)
grav = 9.80665*(1-0.0026373*cos(2*phi) + 0.0000059*(cos(2*phi))^2)*(1-3.14e-7*hght); % in [m/s^2]


%% Increase resolution of the parameters (set finer increments = height steps)

% see scriptum Atmospheric Effects in Geodesy, table 1.4 for increments (height steps and specific
% valid interval)

% define counter
icount = 0;

%%% interpolate values for the first interval of height levels with a step-width of 10m for heigths from station height - 2000 m
%%% (using the height levels and according values for variable hght)

for ht = href:10:2000
    % raise counter
    icount = icount + 1;
    
    % set new refined height level to variable hght1 (according to loop)
    hght1(icount) = ht;
     
    % get index of value from old height levels (hght) where the difference between the new refined
    % layer (ht) and the old levels is a minimum --> nearest level to new interpolation point
    % --> used to get according values needed for interpolation
    [~,index]  = min(abs(ht - hght));
    
    % reduce virtual temperature to mean height 
    %hmean = ht - (ht-hght(index))./2;
    %vtem_hmean = interp1(hght,vtem,hmean,'linear','extrap');
       
    % interpolate for refined values of total pressure
    % see scriptum Atmospheric Effects in Geodesy, equation (1.50) or Nafisi et al. 2012, equation (20)
    pres1(icount) = pres(index)*exp(grav(index)/Rd/vtem(index)*(hght(index)-ht)); % in [hPa] ???? equation for pressure ????
    %pres1(icount) = pres(index)*exp(grav(index)/Rd/vtem_hmean*(hght(index)-ht));
    % get index of value from old height levels (hght) where the difference between the new refined
    % layer (ht) and the old levels is a minimum --> nearest level above new interpolation point
    % --> used to get according values needed for interpolation
    if max(ht-hght) < 0; index = 2; else index = find(ht-hght < 0,1); end    
        
    % Determine water vapour gradient
    if ~((wvpr(index-1)==0)||(wvpr(index)==0)||(wvpr(index)==wvpr(index-1)))
        c = (hght(index-1) - hght(index))/log(wvpr(index-1)./wvpr(index)); % see Nafisi et al. 2012, equation (23) or B�hm and Schuh 2003
        wvpr1(icount) = wvpr(index)*exp((ht - hght(index))./c);
        % Write output to screen  
        %fprintf('%5.0f %7.2f %7.2f %5.3f %5.3f %8.4f %5.3f\n',ht,hght(index-1),hght(index),wvpr(index-1),wvpr(index),c,wvpr1(icount));
    else
        % if c would deliver inf, do linear interpolation for wvpr
        wvpr1(icount) = interp1(hght,wvpr,ht,'linear','extrap');
    end

    % linear interpolation for temperature values
    temp1(icount) = interp1(hght,temp,ht,'linear','extrap');
end

%%% interpolate values for the second interval of height levels with a step-width of 20 m for heigths from 2020 m - 6000 m 
%%% (using the height levels and according values for variable hght)

% check if the station height is above the first height level interval (higher than 2000 m)
if href > 2000
    % if true --> set new interval start to station height 
    ht1 = href;
    
    % delete unnecessry levels with according values of lower levels
    hght1=[];
    pres1=[];
    wvpr1=[];
    temp1=[];
    
    % reset icount
    icount=0;
else
    % if false --> set new interval start to latest entry (=last entry) of the first interval + step width
    ht1 = hght1(icount)+20;
end

for ht = ht1:20:6000
    % raise counter
    icount = icount + 1;
    
    % set new refined height level to variable hght1 (according to loop)
    hght1(icount) = ht;
       
    % get index of value from old height levels (hght) where the difference between the new refined
    % layer (ht) and the old levels is a minimum --> nearest level to new interpolation point
    % --> used to get according values needed for interpolation
    [~,index]  = min(abs(ht - hght));
    
    % reduce virtual temperature to mean height 
    %hmean = ht - (ht-hght(index))./2;
    %vtem_hmean = interp1(hght,vtem,hmean,'linear','extrap');
    
    % interpolate for refined values of total pressure
    % see scriptum Atmospheric Effects in Geodesy, equation (1.50) or Nafisi et al. 2012, equation (20)
    pres1(icount) = pres(index)*exp(grav(index)/Rd/vtem(index)*(hght(index)-ht));
    %pres1(icount) = pres(index)*exp(grav(index)/Rd/vtem_hmean*(hght(index)-ht));
    
    % get index of value from old height levels (hght) where the difference between the new refined
    % layer (ht) and the old levels is a minimum --> nearest level above new interpolation point
    % --> used to get according values needed for interpolation
    if max(ht-hght) < 0; index = 2; else index = find(ht-hght < 0,1); end    
    
    % Determine water vapour gradient
    if ~((wvpr(index-1)==0)||(wvpr(index)==0)||(wvpr(index)==wvpr(index-1)))
        c = (hght(index-1) - hght(index))/log(wvpr(index-1)./wvpr(index)); % see Nafisi et al. 2012, equation (23) or B�hm and Schuh 2003
        wvpr1(icount) = wvpr(index)*exp((ht - hght(index))./c);
        % Write output to screen  
        %fprintf('%5.0f %7.2f %7.2f %5.3f %5.3f %8.4f %5.3f\n',ht,hght(index-1),hght(index),wvpr(index-1),wvpr(index),c,wvpr1(icount));
    else
        % if c would deliver inf, do linear interpolation for wvpr
        wvpr1(icount) = interp1(hght,wvpr,ht,'linear','extrap');
    end

    % linear interpolation for temperature values
    temp1(icount) = interp1(hght,temp,ht,'linear','extrap');
end


%%% interpolate values for the third interval of height levels with a step-width of 50 m for heigths from 6050 m - 16000 m 
%%% (using the height levels and according values for variable hght)

% check if the station height is above the second height level interval (higher than 6000 m)
if href > 6000
    % if true --> set new interval start to station height 
    ht1 = href;
    
    % delete unnecessry levels with according values
    hght1=[];
    pres1=[];
    wvpr1=[];
    temp1=[];
    
    % reset icount
    icount=0;
else
    % if false --> set new interval start to latest entry (=last entry) of the second interval + step width
    ht1 = hght1(icount)+50;
end

for ht = ht1:50:16000
    % raise counter
    icount = icount + 1;
    
    % set new refined height level to variable hght1 (according to loop)
    hght1(icount) = ht;
       
    % get index of value from old height levels (hght) where the difference between the new refined
    % layer (ht) and the old levels is a minimum --> nearest level to new interpolation point
    % --> used to get according values needed for interpolation
    [~,index]  = min(abs(ht - hght));    
     
    % interpolate for refined values of total pressure
    % see scriptum Atmospheric Effects in Geodesy, equation (1.50) or Nafisi et al. 2012, equation (20)
    pres1(icount) = pres(index)*exp(grav(index)/Rd/vtem(index)*(hght(index)-ht));
    
    % get index of value from old height levels (hght) where the difference between the new refined
    % layer (ht) and the old levels is a minimum --> nearest level above new interpolation point
    % --> used to get according values needed for interpolation
    if max(ht-hght) < 0; index = 2; else index = find(ht-hght < 0,1); end    
       
    % Determine water vapour gradient
    if ~((wvpr(index-1)==0)||(wvpr(index)==0)||(wvpr(index)==wvpr(index-1)))
        c = (hght(index-1) - hght(index))/log(wvpr(index-1)./wvpr(index)); % see Nafisi et al. 2012, equation (23) or B�hm and Schuh 2003
        wvpr1(icount) = wvpr(index)*exp((ht - hght(index))./c);
        % Write output to screen  
        %fprintf('%5.0f %7.2f %7.2f %5.3f %5.3f %8.4f %5.3f\n',href(i),hght(index-1),hght(index),wvpr(index-1),wvpr(index),c,wvpr1(i));
    else
        % if c would deliver inf, do linear interpolation for wvpr
        wvpr1(icount) = interp1(hght,wvpr,ht,'linear','extrap');
    end    
    % linear interpolation for temperature values
    temp1(icount) = interp1(hght,temp,ht,'linear','extrap');
end


%%% interpolate values for the fourth interval of height levels with a step-width of 100 m for heigths from 16100 m - 36000 m 
%%% (using the height levels and according values for variable hght)

% check if the station height is above the third height level interval (higher than 16000 m)
if href > 16000
    % if true --> set new interval start to station height 
    ht1 = href;
    
    % delete unnecessry levels with according values
    hght1=[];
    pres1=[];
    wvpr1=[];
    temp1=[];
    
    % reset icount
    icount=0;
else
    % if false --> set new interval start to latest entry (=last entry) of the third interval + step width
    ht1 = hght1(icount)+100;
end

for ht = ht1:100:36000
    % raise counter
    icount = icount + 1;
    
    % set new refined height level to variable hght1 (according to loop)
    hght1(icount) = ht;
        
    % get index of value from old height levels (hght) where the difference between the new refined
    % layer (ht) and the old levels is a minimum --> nearest level to new interpolation point
    % --> used to get according values needed for interpolation
    [~,index]  = min(abs(ht - hght));    
    
    % interpolate for refined values of total pressure
    % see scriptum Atmospheric Effects in Geodesy, equation (1.50) or Nafisi et al. 2012, equation (20)
    pres1(icount) = pres(index)*exp(grav(index)/Rd/vtem(index)*(hght(index)-ht));
       
    % set water vapor pressure to 0 for all height levels above 16 km
    wvpr1(icount) = 0;
    
    % linear extrapolation for temperature values
    temp1(icount) = interp1(hght,temp,ht,'linear','extrap');
end


%%% interpolate values for the fifth interval of height levels with a step-width of 500 m for heigths from 36500 m - 136000 m 
%%% (using the height levels and according values for variable hght)

% check if the station height is above the fourth height level interval (higher than 36000 m)
if href > 36000
    % if true --> set new interval start to station height 
    ht1 = href;
    
    % delete unnecessry levels with according values
    hght1=[];
    pres1=[];
    wvpr1=[];
    temp1=[];
    
    % reset icount
    icount=0;
else
    % if false --> set new interval start to latest entry (=last entry) of the fourth interval + step width
    ht1 = hght1(icount)+500;
end

for ht = ht1:500:136000
    % raise counter
    icount = icount + 1;
    
    % set new refined height level to variable hght1 (according to loop)
    hght1(icount) = ht;
    
    % get index of value from old height levels (hght) where the difference between the new refined
    % layer (ht) and the old levels is a minimum --> nearest level to new interpolation point
    % --> used to get according values needed for interpolation
    [~,index]  = min(abs(ht - hght));
    
    % interpolate for refined values of total pressure
    % see scriptum Atmospheric Effects in Geodesy, equation (1.50) or Nafisi et al. 2012, equation (20)
    pres1(icount) = pres(index)*exp(grav(index)/Rd/vtem(index)*(hght(index)-ht));
       
    % set water vapor pressure to 0 for all height levels above 36 km
    wvpr1(icount) = 0;
    
    % linear extrapolation for temperature values
    temp1(icount) = interp1(hght,temp,ht,'linear','extrap');
end
