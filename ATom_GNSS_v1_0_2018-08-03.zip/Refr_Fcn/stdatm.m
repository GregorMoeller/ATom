function [p,T,e] = stdatm(h)

% Function statm() computes meteo parameter based on standard
% atmospheric conditions:

% Input:
% h   ... station height above m.s.l. [km]

% Output
% p   ... Pressure [hPa] at height h
% T   ... Temperature [K] at height h 
% e   ... Water vapour pressure [hPa] at height h

% Atmosphere parameter at mean sea level, see Berg, 1948
p0  = 1013.25;   % [hPa]
T0  = 18+273.16; % [�K]
rh0 = 50;        % [percent]

% Temperature values from Niell, email 2003 Aug 19 or see scriptum Atmospheric Effects in Geodesy, table 1.3
hext0 = [ 25000, 50000, 80000,100000,130000,150000];
Text0 = [   220,   268,   200,   210,   533,   893];

% Compute meteo parameter for given height h < 25000 m
if h < 25000    
    p  = p0*(1-0.0000226*h)^5.225;
    T  = T0-0.0065*h;
    rh = rh0*exp(-0.0006396*h);
    % Water vapour pressure e [hPa], see script Satellite Geodesy, Eq. 5.25
    e = rh/100*exp(-37.2465+0.213166*T-0.000256908*T^2);    
else
    p  = p0.*(1-0.0000226*h)^5.225;
    T = interp1(hext0,Text0,h,'linear','extrap');
    e = 0;
end

if h > 42000
    p = 0.0001;
end
