function [poi_H] = height_model(hmin,hmax,q,dh0)

% Function height_model(h0,h1,q) computes the height layers based on the
% approch from Perler (2011)

% Copyright (C) 2018 Gregor Moeller
% All rights reserved.
% Email: gregor.moeller@tuwien.ac.at

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.

% Input:
% hmin   ... height of the lowest layer [m]
% hmax   ... height of the upper layer [m]
% q      ... exponent
% dh0    ... height difference between first two layers

% Output
% poi_H  ... List of heigt layers [m]

% Height of lowest layer
poi_H(1) = round(hmin);

% Counter
i = 1;

% Consecutive heights
while poi_H(i) < hmax
    dh(i) = dh0*q^(i-1);
    poi_H(i+1) = round(poi_H(i) + dh(i));
    i = i + 1;
end

% Height of highest layer
poi_H(i) = round(hmax);