function [stdNh,stdNw] = comp_stddev(p1,T1,Q1,H)

% Function comp_stddev() applies variance propagation law to compute
% standard deviations for an priori refractivity field

% Input
% p1  ... pressure [hPa]
% T1  ... temperature [K]
% Q1  ... specific humidity [kg/kg]
% H   ... orthometric reference height [km]

% Output
% dN_h ... Weight of hydrostatic refractivity [mm/km]
% dN_w ... Weight of non-hydrostatic (wet) refractivity [mm/km]

% % Constants / Initial values
R   = 8314.459;      % [kg*m^2/(kmol*K*s^2)] = [J/(kmol*K)]
Md  = 28.9645;       % [kg/kmol]
Mw  = 18.01528;      % [kg/kmol]
Rd  = R/Md;          % [m^2/(K*s^2)]
a1  = 0.622;         % Coefficient 1 for water vapour pressure calculation
a2  = 0.378;         % Coefficient 2 for water vapour pressure calculation
g   = 9.80665;       % Gravity acceleration [m/s�]
T0  = 18+273.16;     % Temperature from standard atmosphere

% % Refractivity coefficients according to (R�eger J.M., 2002, best avarage)
k1  = 77.689;        % [K/hPa]
k2  = 71.295;        % [K/hPa]
k3  = 375463;        % [K^2/hPa]
k2p = k2-k1*(Mw/Md); % [K/hPa] aprox. 22.1

% Define symbolic variables
syms Q p T

%% Standard deviations of p, T and Q
% Standard deviation of pressure dp [hPa] at height H [km];
stdp0 = 2.5; 
stdp  = stdp0*exp(g/Rd/T0*-H*1000); % [hPa]

% Standard deviation of temperature dT [K] at height H [km]
HT0   = [0.0 0.8 1.3 2.0 2.2 2.7 3.0 3.5 5.0 6.1 8.0 9.5 11.2 13.2 14.2 15.2 16.3 17.8 21.8 23.8 31.0 36];
stdT0 = [0.70 0.60 0.70 0.60 0.55 0.52 0.52 0.54 0.50 0.47 0.46 0.46 0.50 0.50 0.51 0.53 0.68 0.78 0.70 0.70 0.91 1.20]; % [K]
stdT  = interp1(HT0,stdT0,H,'linear','extrap');

% Standard deviation of specific humidity dQ [g/kg] at height H [km]
HQ0   = [0.0  0.1  0.3  0.8  1.4  1.7  4.1  6.0  6.7  7.8  9.5 11.0 15.0 35.0];
stdQ0 = [0.66 0.68 0.69 0.80 0.70 0.58 0.40 0.30 0.25 0.15 0.10 0.05 0.01  0.0]./1000; % [kg/kg]
stdQ  = interp1(HQ0,stdQ0,H,'linear','extrap');

% % Standard deviation of water vapour
% e     = Q.*p./(a1+a2*Q);
% de_p  = diff(e,p);
% de_Q  = diff(e,Q);
% % Linear FFG
% stde_l = abs(de_Q)*stdQ + abs(de_p)*stdp;
% % Gaussian FFG
% stde = sqrt(abs(de_Q*stdQ).^2 + abs(de_p*stdp).^2);

%% Partial derivatives
e     = Q.*p./(a1+a2*Q);
Nh    = k1*(p-e)/T;
Nw    = k3*e/T^2+k2p*e/T;
dNh_p = diff(Nh,p);
dNh_T = diff(Nh,T);
dNh_Q = diff(Nh,Q);
dNw_p = diff(Nw,p);
dNw_T = diff(Nw,T);
dNw_Q = diff(Nw,Q);

%% Replace symbolic variables
p = p1; Q = Q1; T = T1;
dNh_p = abs(double(subs(dNh_p)));
dNh_T = abs(double(subs(dNh_T)));
dNh_Q = abs(double(subs(dNh_Q)));
dNw_p = abs(double(subs(dNw_p)));
dNw_T = abs(double(subs(dNw_T)));
dNw_Q = abs(double(subs(dNw_Q)));

%% Standard deviation for Nh and Nw
% Linear FFG
% stdNh_l = abs(dNh_p).*stdp + abs(dNh_T).*stdT + abs(dNh_Q).*stdQ;
% stdNw_l = abs(dNw_p).*stdp + abs(dNw_T).*stdT + abs(dNw_Q).*stdQ;
% Gaussian FFG
stdNh = sqrt((dNh_p.*stdp).^2 + (dNh_T.*stdT).^2 + (dNh_Q.*stdQ).^2);
stdNw = sqrt((dNw_p.*stdp).^2 + (dNw_T.*stdT).^2 + (dNw_Q.*stdQ).^2);

