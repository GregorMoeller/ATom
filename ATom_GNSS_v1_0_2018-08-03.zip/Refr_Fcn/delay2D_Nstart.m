function ray = delay2D_Nstart (ref_h,ref_w,hght,href,e0,phi_st)
% 
% 
%---------------------------------------------------------------------------------------------------
% History:
% 
% jboehm, 2003 Jan 
% 
% Armin Hofmeister
% 22.07.2013: added comments, changes in programming
% 23.07.2013: added comments, change from fixed earth radius to gaussian curvature radius
% 24.07.2013: added comments, changes in programming, added calculation of more output values
% 30.07.2013: change of calculation of gaussian curvature radius
% 27.08.2013: add total zenith delay calculation and total slant delay calculation
% 10.09.2013: add hydrostatic slant path delay + geometric bending effect and total slant delay +
%             geometric bending effect calculation
% 18.09.2013: correct comment
% 06.11.2013: correct comment
% 13.11.2013: correct comment
% 05.08.2015: change input from meteo (p,T,e) to ref_h and ref_w
% 
% 
%---------------------------------------------------------------------------------------------------
% 
% INPUT:
%       All arrays are starting at the lowest height!
% 
%       ref_h....   hydrostatic refractivity [ppm], vector containing all levels
%       ref_w....   wet refractivity [ppm], vector containing all levels
%       hght.....   height in [m], vector containing all levels
%       href.....   station height (orthometric) in [m], scalar
%       e0.......   starting elevation angle in [�]
%       phi_st...   ellipsoidal (WGS84) latitude of station in [�]
% 
% 
% OUTPUT:
%       ray.e0..............   starting elevation angle in [�] 
%       ray.e_out...........   outgoing elevation angle in [�] 
%       ray.dz_h............   hydrostatic zenith delay in [m]
%       ray.dz_w............   wet zenith delay in [m]
%       ray.dz_total........   total zenith delay in [m]
%       ray.ds_h............   hydrostatic slant path delay in [m]
%       ray.ds_w............   wet slant path delay in [m]
%       ray.ds_total........   total slant path delay in [m]
%       ray.geom_bend.......   total geometric bending effect in [m]
%       ray.mf_h_geom.......   value for hydrostatic mapping function (includes treatment of geometric bending effect)
%       ray.mf_w............   value for wet mapping function
%       ray.ds_h_geom.......   hydrostatic slant path delay + geometric bending effect in [m]
%       ray.ds_total_geom...   total slant path delay + geometric bending effect in [m]
%       
% 
% 
%===================================================================================================

%% Define, convert and calculate parameters
%%% calculate radius of the Earth using formula for the gaussian curvature radius

% define axis of reference ellipsoid (WGS84)
a=6378137.0; % equatorial axis of WGS84 reference ellipsoid in [m]
b=6356752.3142; % polar axis of WGS84 reference ellipsoid in [m]

% define transformation coefficient for conversion from [�] to [rad]
deg2rad=pi/180;

% define transformation coefficient for conversion from [rad] to [�]
rad2deg=1/deg2rad;

% transform station latitude from [�] to [rad]
phi_st=phi_st*deg2rad;

% calculate gaussian radius of curvature

% own calculation
% R_g = (a^2*cos(phi_st)^2+b^2*sin(phi_st)^2)/b;

% see scriptum Terrestrische Bezugsrahmen
e2 = (a^2-b^2)/b^2;
cel = a^2/b;

V = sqrt(1 + e2.*cos(phi_st).^2);
dNell = cel./V;
dMell = cel./V.^3;
R_g = sqrt(dMell.*dNell);

% convert elevation from [�] to [rad]
e0 = e0*deg2rad;

% define distance from earth center (Earth radius + height level)
r = R_g + hght;

% calculate total refractivities
ref = ref_h + ref_w;

% in case that the first entry of the height level vector is not the according station height:

% --> the actual height of the station is used to calculate the refractivity there
% refractivities are calculated for this height (linear interpolation)
rref = R_g + href;

% first refractivity
% if the station height is below the first height level in the vector hght
if href < hght(1)
    % set the first refractivity values equal to the values calculated for the first entry in the
    % vector hght (=first height level)
    nref_w = ref_w(1);
    nref_h = ref_h(1);
    nref   = ref(1);
else
    % if the station height is above or equal to the first height level in the vector hght
    % --> do a linear interpolation to get the refractivity at the desired point href
    nref_w = interp1(hght,ref_w,href,'linear');
    nref_h = interp1(hght,ref_h,href,'linear');
    nref   = interp1(hght,ref,  href,'linear');
end

% all pressure levels below href are discarded
k = find (hght < href);
hght(k)   = [];
r(k)      = [];
ref_w(k)  = [];
ref_h(k)  = [];
ref(k)    = [];

% create new arrays with values for all height levels beginning at the station height
hght   = [href; hght];
r      = [rref; r];
ref_w  = [nref_w; ref_w];
ref_h  = [nref_h; ref_h];
ref    = [nref; ref];


%% calculate mean values of refractivity between the levels

% initialize variables
mref = zeros(length(hght)-1,1);
mref_w = zeros(length(hght)-1,1);
mref_h = zeros(length(hght)-1,1);

% calculate mean values  total, hydrostatic and wet refractivities between two levels
for i = 1:length(hght)-1;
    
    mref  (i) = (ref  (i+1) + ref  (i))/2;
    
    mref_w(i) = (ref_w(i+1) + ref_w(i))/2;
    mref_h(i) = (ref_h(i+1) + ref_h(i))/2;
end

% last entry of mean refractivities is set to zero (because of vacuum of space N=0 or n=1)
mref(length(hght)) = 0;

% convert refractivities to refractive indices, because
% refractive indices (about 1.0003..) are needed for bending
% see scriptum Atmospheric Effects in Geodesy, equation (2.1)
mref = mref*1e-6 + 1; 


%% ray-tracing - calculate intersection points of all height levels on the ray

% here the path lengths s between the levels are calucated (with light bending)
% the last value for eps is the elevation angle when the ray leaves the troposphere

% initialize variables for all intersection points on the ray path
s=zeros(length(hght)-1,1);
z=zeros(length(hght),1);
y=zeros(length(hght),1);
eta=zeros(length(hght),1);
delta=zeros(length(hght),1);
theta=zeros(length(hght),1);
eps=zeros(length(hght),1);

% define values for the first point and second point on the ray
% see scriptum Atmospheric Effects in Geodesy, equations (2.61) - (2.66)

% define theta1
theta(1) = e0; % in [rad]
% define the elevation angle at point 1
eps(1) = e0; % in [rad]
% calculate distance s1 from the first to the second point
s(1) = -r(1)*sin(theta(1)) + sqrt(r(2)^2 - r(1)^2*(cos(theta(1)))^2); % in [m]
% define z1
z(1) = r(1); % in [m]
% define y1
y(1) = 0; % in [m]
% define z2
z(2) = z(1) + s(1)*sin(eps(1)); % in [m]
% define y2
y(2) = y(1) + s(1)*cos(eps(1)); % in [m]
% define eta1
eta(1)   = 0; % in [rad]
% define eta2
eta(2)   = atan(y(2)/z(2)); % in [rad]
% define theta2
% only the real part is taken in case that acos delivers a complex number (happens if e0= 0�)
theta(2) = real(acos(mref(1)/mref(2)*cos(theta(1) + eta(2)))); % in [rad]
% calculate elevation angle at point 2
eps(2)   = theta(2) - eta(2); % in [rad]


% loop over all remaining height levels (from 2 to end-1)
% calculate intersection points on the ray
% see scriptum Atmospheric Effects in Geodesy, equations (2.67) - (2.72)
for i = 2:length(hght)-1;
    s(i) = -r(i)*sin(theta(i)) + sqrt(r(i+1)^2 - r(i)^2*(cos(theta(i)))^2); % in [m]
    z(i+1) = z(i) + s(i)*sin(eps(i)); % in [m]
    y(i+1) = y(i) + s(i)*cos(eps(i)); % in [m]
    eta  (i+1) = atan(y(i+1)/z(i+1)); % in [rad]
    delta (i+1) = eta(i+1) - eta(i); % in [rad]
    theta(i+1) = acos(mref(i)/mref(i+1)*cos(theta(i) + delta(i+1))); % in [rad]
    eps  (i+1) = theta(i+1) - eta(i+1); % in [rad]
end

%% ray-tracing - determine the geometric bending effect

% initialize variable for geometric bending effect
dgeo = zeros(length(eps)-1,1); 

% get final (=outgoing) elevation angle
eps_final = eps(length(hght)); % in [rad]

% calculate bending effect for each height level
% see scriptum Atmospheric Effects in Geodesy, equation (2.75)
for i = 1:length(eps)-1
    dgeo(i) = s(i) - cos(eps(i)-eps_final)*s(i); % in [m]
end


%% ray-tracing - determine height differences between levels in zenith direction

% initialize variable for height differences between levels in zenith direction
dh=zeros(length(hght)-1,1);

% calculate height differences between levels in zenith direction
for i = 1:length(hght)-1
    dh(i) = hght(i+1) - hght(i); % in [m]
end


%% ray-tracing - determine final output values

% convert starting elevation angle from [rad] to [�]
ray.e0=e0*rad2deg;

% convert outgoing elevation angle from [rad] to [�]
ray.e_out = eps_final*rad2deg; % in [�]

% calculate hydrostatic zenith delay
% see scriptum Atmospheric Effects in Geodesy, equation (2.74)
ray.dz_h = ((mref_h'*1e-6)*dh); % in [m]

% calculate wet zenith delay
% see scriptum Atmospheric Effects in Geodesy, equation (2.74)
ray.dz_w = ((mref_w'*1e-6)*dh); % in [m]

% calculate total zenith delay
ray.dz_total = ray.dz_h+ray.dz_w; % in [m]

% calculate hydrostatic slant delay
% see scriptum Atmospheric Effects in Geodesy, equation (2.74)
ray.ds_h = ((mref_h'*1e-6)*s); % in [m]

% calculate wet slant delay
% see scriptum Atmospheric Effects in Geodesy, equation (2.74)
ray.ds_w = ((mref_w'*1e-6)*s); % in [m]

% calculate total slant delay
ray.ds_total = ray.ds_h+ray.ds_w; % in [m]

% calculate total geometric bending effect
ray.geom_bend=sum(dgeo); % in [m]

% calculate value for hydrostatic mapping function (includes treatment of geometric bending effect)
% see B�hm and Schuh (2003) "Vienna Mapping Functions" in Working Meeting on European VLBI for Geodesy and Astrometry
% equation (A26)
ray.mf_h_geom = (ray.ds_h + ray.geom_bend)/ray.dz_h;

% calculate value for wet mapping function
% see B�hm and Schuh (2003) "Vienna Mapping Functions" in Working Meeting on European VLBI for Geodesy and Astrometry
% equation (A27)
ray.mf_w = ray.ds_w/ray.dz_w;

% hydrostatic slant delay + geometric bending effect
ray.ds_h_geom = ray.ds_h+ray.geom_bend; % in [m]

% calculate total slant delay + geometric bending effect
ray.ds_total_geom = ray.ds_total+ray.geom_bend; % in [m]




end
