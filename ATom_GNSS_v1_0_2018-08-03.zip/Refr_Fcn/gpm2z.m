function z = gpm2z(gpm,phi)

% This function converts geopotential (=dynamic) heights [m] to geometric (=orthometric) heights [m]
% using the formula by meteorologist (Kraus,2004), which inherits an approximation approach.
% 
% INPUT:
%        gpm...   geopotential (=dynamic) height in [m], vector input supported
%        phi...   latitude value in [rad]
% 
% OUTPUT:
%        z.....   geometric (=orthometric) height in [m], scalar
% 
% 
%---------------------------------------------------------------------------------------------------
% History:
% 
% created by Johannes B�hm
% 
% Armin Hofmeister
% 18.07.2013: added comments
% 18.09.2013: comments corrected
% Gregor M�ller
% 24.07.2015: extented to handle vectors
% 
%===================================================================================================

% conversion of geopotential meters to meters using formula by meteorologists (kraus)
% phi radiant

z = 1/(2*1.57e-7) - ...
    sqrt( (1/(2*1.57e-7))^2 - ...
          gpm./(1 - 0.0026373*cos(2*phi) + 0.0000059*(cos(2*phi)).^2)/1.57e-7);