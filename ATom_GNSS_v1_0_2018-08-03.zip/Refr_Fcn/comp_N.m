function [N_h,N_w] = comp_N(p,T,e)

% Function comp_N() computes refractivity fields

% Input
% p   ... Pressure [hPa] at height h
% T   ... Temperature [K] at height h 
% e   ... Water vapour pressure [hPa] at height h

% Output
% N_h ... hydrostatic refractivity [mm/km]
% N_w ... non-hydrostatic (wet) refractivity [mm/km]

% Constants
R   = 8314.459;      % [kg*m^2/(kmol*K*s^2)] = [J/(kmol*K)]
Md  = 28.9645;       % [kg/kmol]
Mw  = 18.01528;      % [kg/kmol]
Rd  = R/Md;          % [m^2/(K*s^2)]
Rw  = R/Mw;          % [m^2/(K*s^2)]
% Refractivity coefficients according to (R�eger J.M., 2002, best avarage)
k1  = 77.689;        % [K/hPa]
k2  = 71.295;        % [K/hPa]
k3  = 375463;        % [K^2/hPa]
k2p = k2-k1*(Mw/Md); % [K/hPa] aprox. 22.1

% Density, see Askne & Nordius, 1987, Eq. 3
rho_d = (p-e)/Rd/T;  % [hPa*s^2/m^2]=[1000kg/m^3]
rho_w =     e/Rw/T;  % [hPa*s^2/m^2]=[1000kg/m^3]
rho   = rho_d+rho_w;

% Hydrostatic & non-hydrostatic refractivity, see Davis et al. 1985, Eq. A7
N_h = k1*Rd*rho;
N_w = k3*e/T^2+k2p*e/T;
