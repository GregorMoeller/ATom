function [VMF1_h,VMF1_w] = vmf1 (a_h, a_w , mjd, lat, zd)

%   This subroutine determines the VMF1 (Vienna Mapping Functions 1)
%   for specific sites.
%   Reference: Boehm, J., B. Werl, H. Schuh (2006),
%   Troposphere mapping functions for GPS and very long baseline interferometry
%   from European Centre for Medium-Range Weather Forecasts operational analysis data,
%   J. Geoph. Res., Vol. 111, B02406, doi:10.1029/2005JB003629.
%
%   Please mind that the coefficients in this paper are wrong. The corrected version of
%   the paper can be found at:
%   http://ggosatm.hg.tuwien.ac.at/DOCS/PAPERS/2006Boehm_etal_VMF1.pdf
%
%   input data
%   ----------
%   a_h:   hydrostatic coefficient a (http://ggosatm.hg.tuwien.ac.at/DELAY/SITE/)
%   a_w:   wet coefficient a         (http://ggosatm.hg.tuwien.ac.at/DELAY/SITE/)
%   dmjd: modified julian date
%   dlat: ellipsoidal latitude in radians
%   zd:   zenith distance in radians
%
%   output data
%   -----------
%   vmf1h: hydrostatic mapping function
%   vmf1w: wet mapping function
%
%   Johannes Boehm, 2005 October 2
%   rev 2011 July 21: latitude -> ellipsoidal latitude
%
%-------------------------------------------------------------------------- 


% reference day is 28 January (this is taken from Niell (1996) to be consistent)
doy = mjd  - 44239.d0 + 1 - 28;

% convert zenith distance to elevation
el = 90*(pi/180) - zd;

% calculate the empiric coefficients b and c
c0_h = 0.062;
if lat < 0      %   ! southern hemisphere
    psi  = pi;
    c11_h = 0.007;
    c10_h = 0.002;
else             %   ! northern hemisphere
    psi  = 0;
    c11_h = 0.005;
    c10_h = 0.001;
end

b_h = 0.0029;
c_h = c0_h + ((cos(doy/365.25d0*2*pi + psi)+1)*c11_h/2 + c10_h)*(1-cos(lat));   % formula (122), page 104
b_w = 0.00146;
c_w = 0.04391;

% inserting all coefficients into the continued fraction (eq. 121)
VMF1_h = (1+(a_h/(1+b_h/(1+c_h))))   /   (sin(el)+(a_h/(sin(el)+b_h/(sin(el)+c_h))));
VMF1_w = (1+(a_w/(1+b_w/(1+c_w))))   /   (sin(el)+(a_w/(sin(el)+b_w/(sin(el)+c_w))));









% Das verkompliziert alles nur, zeigt aber das selbe Ergebnis wie das oben
% sine   = sin(pi/2-zd);
% beta   = b_h/(sine+c_h);
% gamma  = a_h/( sine + beta);
% topcon = (1 + a_h/(1 + b_h/(1 + c_h)));
% vmf1h   = topcon/(sine+gamma);
% 
% 
% beta   = b_w/(sine + c_w);
% gamma  = a_w/(sine + beta);
% topcon = (1 + a_w/(1.d0 + b_w/(1 + c_w)));
% vmf1w   = topcon/(sine+gamma);


