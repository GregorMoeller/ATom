function [cell_grid] = gpt2_1w_fast_readGrid

% gpt2_1w_fast_readGrid.m
% This routine reads the grid and overgives the respective parameters in a
% cell. It must be placed ahead of the for loop, which runs
% through all observations in order to save a huge tim amount. The related
% function "gpt2_1w_fast.m" must then replace "gpt2_1w.m" at the respective
% location in the text.

% read gridfile
% use the 1 degree grid (GP)
fid = fopen('gpt2_1wA.grd','r');

% read first comment line
line = fgetl(fid);

% initialization
pgrid = zeros([64800, 5]);
Tgrid = zeros([64800, 5]);
Qgrid = zeros([64800, 5]);
dTgrid = zeros([64800, 5]);
u = zeros([64800, 1]);
Hs = zeros([64800, 1]);
ahgrid = zeros([64800, 5]);
awgrid = zeros([64800, 5]);
lagrid = zeros([64800, 5]);
Tmgrid = zeros([64800, 5]);

% loop over grid points
% 64800 for the 1 degree grid (GP)
for n = 1:64800
    
    % read data line
    line = fgetl(fid);
    vec = sscanf(line,'%f');
        
    % read mean values and amplitudes
    pgrid(n,1:5)  = vec(3:7);          % pressure in Pascal
    Tgrid(n,1:5)  = vec(8:12);         % temperature in Kelvin
    Qgrid(n,1:5)  = vec(13:17)./1000;  % specific humidity in kg/kg
    dTgrid(n,1:5) = vec(18:22)./1000;  % temperature lapse rate in Kelvin/m
    u(n)          = vec(23);           % geoid undulation in m
    Hs(n)         = vec(24);           % orthometric grid height in m
    ahgrid(n,1:5) = vec(25:29)./1000;  % hydrostatic mapping function coefficient, dimensionless
    awgrid(n,1:5) = vec(30:34)./1000;  % wet mapping function coefficient, dimensionless
	lagrid(n,1:5) = vec(35:39);    	   % water vapor decrease factor, dimensionless
	Tmgrid(n,1:5) = vec(40:44);        % mean temperature in Kelvin
    
end

cell_grid = {pgrid, Tgrid, Qgrid, dTgrid, u, Hs, ahgrid, awgrid, lagrid, Tmgrid};
fclose (fid);