function [dat,dat_cont] = read_Nw(fullpathname)

% Function read_Nw reads in wet and total refractivities

% Copyright (C) 2018 Gregor Moeller
% All rights reserved.
% Email: gregor.moeller@tuwien.ac.at

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.

% Last update: 15-10-2016

% Input
% fullpathname  ... path/filename

% Output
% dat           ... [Station name, MJD, Data lines]
% dat_cont      ... Content description

%% Read Nw data
fid  = fopen(fullpathname,'r');
dat = textscan(fid,'%f %f %f %f');
fclose(fid);

% dat{1}  ... Longitude [degrees]
% dat{2}  ... Latitude [degrees]
% dat{3}  ... ellipsoidal height [m]
% dat{4}  ... Wet refractivity [mm/km]

% % Delete outer voxel model
% id1 = find(dat{1}==min(dat{1}));
% id2 = find(dat{1}==max(dat{1}));
% id3 = find(dat{2}==min(dat{2}));
% id4 = find(dat{2}==max(dat{2}));
% id  = [id1;id2;id3;id4];
% dat{1}(id) = [];
% dat{2}(id) = [];
% dat{3}(id) = [];
% dat{4}(id) = [];

% % Restore lat and lon
% lon = dat{1};
% dat{1} = dat{2};
% dat{2} = lon;

% Add line for total refractivity
dat{5} = zeros(length(dat{4}),1);

% Description of content
dat_cont = {'Lon [�]','Lat [�]','H [m]','Nw_apr [ppm]','N_apr [ppm]'};

end