function [dat,dat_cont] = read_Napr(fullpathname)

% Reads the user defined Napr files

% Developed by: Gregor M�ller (gregor.moeller@tuwien.ac.at)
% Last update: 07-07-2015

% Input
% fullpathname  ... path/filename

% Output
% dat           ... [Station name, MJD, Data lines]
% dat_cont      ... Content description

%% Read Napr data
fid  = fopen(fullpathname,'r');
dat = textscan(fid,'%f %f %f %f %f %f %f %f %f %f');
fclose(fid);

% dat{1}  ... Latitude [degrees]
% dat{2}  ... Longitude [degrees]
% dat{3}  ... orthometric height [m]
% dat{4}  ... Water vapour pressure [hPa]
% dat{5}  ... Temperature [K]
% dat{6}  ... Pressure [hPa]
% dat{7}  ... Hydrostatic refractivity [mm/km]
% dat{8}  ... Wet refractivity [mm/km]
% dat{9}  ... Standard deviation of hydrostatic refractivity [mm/km]
% dat{10} ... Standard deviation of wet refractivity [mm/km]

% Sort data for height
[~,id] = sort(dat{3});
dat{1} = dat{1}(id);
dat{2} = dat{2}(id);
dat{3} = dat{3}(id);
dat{4} = dat{4}(id);
dat{5} = dat{5}(id);
dat{6} = dat{6}(id);
dat{7} = dat{7}(id)+dat{8}(id);
dat{8} = dat{8}(id);
dat{9} = dat{9}(id);
dat{10} = dat{10}(id);

% Description of content
dat_cont = {'Lat [�]','Lon [�]','H [m]','WV pressure [hPa]','Temperaure [K]','Pressure [hPa]','N_apr [ppm]','Nw_apr [ppm]','sig N hydr','sig N wet'};

end