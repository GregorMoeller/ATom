function [dat,dat_cont] = read_ZWD(fullpathname)

% Function read_ZWD reads the NWM derived ZWD files

% Copyright (C) 2018 Gregor Moeller
% All rights reserved.
% Email: gregor.moeller@tuwien.ac.at

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.

% Last update: 15-06-2015

% Input
% fullpathname  ... path/filename

% Output
% dat           ... [Station name, MJD, Data lines]
% dat_cont      ... Content description

%% Read ZWD data
fid  = fopen(fullpathname,'r');
dat  = textscan(fid,'%f %4s %f %f %f %f %f %f %f %s');
fclose(fid);
% dat{1}  ... MJD
% dat{2}  ... GNSS station name
dat{3} = dat{3}.*1000;
% dat{3}  ... ZTD [mm]
dat{4} = dat{4}.*1000;
% dat{4}  ... ZWD [m]
% dat{5}  ... N-Gradient [mm]
% dat{6}  ... E-Gradient [mm]
% dat{7}  ... Pressure [hPa]
% dat{8}  ... Temperature [�C]
% dat{9}  ... Water vapour pressure [hPa]
% dat{10} ... MeteoID

% Description of content
dat_cont = {'MJD','STAT','ZTD [mm]','ZWD [mm]','N-Gradient [mm]','E-Gradient [mm]','Pressure [hPa]','Temperaure [�C]','WV pressure [hPa]'};

end