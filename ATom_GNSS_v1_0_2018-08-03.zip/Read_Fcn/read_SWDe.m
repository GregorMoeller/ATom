function [dat,dat_cont,sta,sat] = read_SWDe(fullpathname)

% Function read_SWDe reads the slant wet delays as provided in *.SWDe 
% COST format

% Copyright (C) 2018 Gregor Moeller
% All rights reserved.
% Email: gregor.moeller@tuwien.ac.at

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.

%% Read SWDe data COST format
fid  = fopen(fullpathname,'r');
data = textscan(fid,'%s %f %f %f %f %f %f %f %f %f %s %f %f %f %f %f %f');
fclose(fid);
% Get time variables from filename
file = strsplit(fullpathname,'\');
year = str2double(file{end}(1:4));
doy  = str2double(file{end}(6:8));
hh   = data{14};
mn   = data{15};
sec  = data{16};

% Correct date for combined files around midnight
if ~isempty(find(unique(hh) == 0,1)) && ~isempty(find(unique(hh) == 23,1))
    hh(hh>6) = hh(hh>6)-24; % Substract 1 day for all epoch later 6 am.
end

time = cal2jd(year,1,0) + doy + (hh+mn/60+sec/3600)/24 -  2400000.5;
sta  = data{1};
sat  = data{11};
azim = data{12};
elev = data{13};
swd  = data{17};

% Remove NaN values
id = isnan(swd);
swd(id) = [];
sat(id) = [];
sta(id) = [];
azim(id) = [];
elev(id) = [];
time(id) = [];

% Store data in matrix
dat(1,:) = swd;
dat(2,:) = time;
dat(3,:) = elev;
dat(4,:) = azim;

% Description of content
dat_cont = {'SWD [m]';'MJD';'Elevation angle [�]';'Azimuth angle [�]';'Station';'SatID'};

end