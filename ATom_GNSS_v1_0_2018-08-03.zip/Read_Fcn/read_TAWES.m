function [dat,dat_cont,sta] = read_TAWES(fullpathname)

%% Read TAWES data
fid  = fopen(fullpathname,'r');
data = textscan(fid,'%4f%2f%2f %4f %s %f %f %f','CommentStyle','%');
fclose(fid); 
year = data{1};
mm   = data{2};
dd   = data{3};
hh   = fix(data{4}./100);
min  = (data{4}-hh*100);

mjd = zeros(1,length(min));
for i = 1:length(min)
    mjd(i) = date2mjd(year(i),mm(i),dd(i),hh(i),min(i));
    %fprintf('%4.0f %2.0f %2.0f %2.0f %2.0f %11.5f\n',year(i),mm(i),dd(i),hh(i),min(i),mjd(i));
end   

sta  = data{5}; % station id
T    = data{6}/10; % temperature �C
p    = data{7}/10; % pressure hPa
h    = data{8}/100; % relative humidity %

% Remove entries with min == 60
id = find(min == 60);
mjd(id) = []; sta(id) = []; T(id) = []; p(id) = [];  h(id) = [];

% Find bad entries
recT = find(T < -80);
recp = find(p < 0);
rech = find(h < 0);
rec  = unique([recT;recp;rech]);

% Delete entries
mjd(rec) = [];
T(rec)   = [];
p(rec)   = [];
h(rec)   = [];
sta(rec) = [];

% Store data in matrix
dat(1,:) = mjd;
dat(2,:) = T;
dat(3,:) = p;
dat(4,:) = h;

% Description of content
dat_cont = {'MJD';'Temperature [�C]';'Pressure [hPa]';'Rel humidity [ ]'};

end