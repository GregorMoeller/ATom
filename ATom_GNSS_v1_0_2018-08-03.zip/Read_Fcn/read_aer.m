function [dat,dat_cont,sta,sat] = read_aer(fullpathname)

%% Read aer data
fid  = fopen(fullpathname,'r');
data = textscan(fid,'%f %f %f %s %s %f %f %f');
fclose(fid);
year = data{1};
doy  = data{2};
sod  = data{3};
time = cal2jd(year,1,1) + doy - 1 + sod/86400 - 2400000.5; %MJD
sta  = data{4};
sat  = data{5};
azim = data{6};
elev = data{7};
ZDR  = zeros(length(elev),1);

% Store data in matrix
dat(1,:) = ZDR;
dat(2,:) = time;
dat(3,:) = elev;
dat(4,:) = azim;

% Description of content
dat_cont = {'ZDR [mm]';'MJD';'Elevation angle [�]';'Azimuth angle [�]';'Station';'SatID'};

end