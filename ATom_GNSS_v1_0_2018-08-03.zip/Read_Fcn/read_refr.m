function [dat,dat_cont] = read_refr(fullpathname)

% Reads the user defined Napr/N files

% Developed by: Gregor M�ller (gregor.moeller@tuwien.ac.at)
% Last update: 07-07-2015

% Input
% fullpathname  ... path/filename

% Output
% dat           ... [Data lines]
% dat_cont      ... Content description

%% Read Napr data
fid  = fopen(fullpathname,'r');
dat = textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f');
fclose(fid);

% dat{1}  ... Latitude [degrees]
% dat{2}  ... Longitude [degrees]
% dat{3}  ... orthometric height [m]
% dat{4}  ... Water vapour pressure a priori [hPa]
% dat{5}  ... Temperature a priori [K]
% dat{6}  ... Pressure a priori [hPa]
% dat{7}  ... Total refractivity a priori [mm/km]
% dat{8}  ... Wet refractivity a priori [mm/km]
% dat{9}  ... Total refractivity [mm/km]
% dat{10} ... Wet refractivity [mm/km]
% dat{11} ... Standard deviation of total refractivity [mm/km]
% dat{12} ... Standard deviation of wet refractivity [mm/km]

% Description of content
dat_cont = {'Lat [�]','Lon [�]','H [m]','e_apr [hPa]','T_apr [K]','p_apr [hPa]','N_apr [ppm]','Nw_apr [ppm]','N [ppm]','Nw [ppm]','Sig N [ppm]','Sig Nw [ppm]'};

end