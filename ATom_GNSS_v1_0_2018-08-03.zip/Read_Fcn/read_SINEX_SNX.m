function [dat,dat_cont,sta,sat] = read_SINEX_SNX(fullpathname,block,handles)

% Reads the '+TROP/SOLUTION block and the '+SLANT/SOLUTION' block of 
% a SINEX_SNX file

% Developed by: Gregor M�ller (gregor.moeller@tuwien.ac.at)
% Last update: 25-11-2015

% Input
% fullpathname  ... path/filename
% block         ... defines data block of interest (trp:+TROP/SOLUTION or slant:+SLANT/SOLUTION)

% Output
% dat           ... [Station name, MJD, Data lines]
% dat_cont      ... Content description

% Initialise variable
dat = [];
dat_cont = '';
sta = '';
sat = '';

%% Read zenit delays
%-------------------------------------------------------------------------
if isequal(block,'trp') 
    % Open file and find block
    fid = fopen(fullpathname,'r');
    % Initialise variables
    nlin = 0;
    % Search for block 'TROP/SOLUTION'
    while ~feof(fid)
        line = fgetl(fid);
        nlin = nlin + 1;
        % Find start bit
        if length(line) >= 14 && strcmpi(line(1:14),'+TROP/SOLUTION'); 
            slin = nlin;
            % Read line
            line = fgetl(fid);
            % Read content
            %lin_cont = strsplit(line,' '); % only available in R2013a or newer
            lin_cont = textscan(line,'%s'); lin_cont = lin_cont{:};
            % Get number of entries
            ndat = length(lin_cont);
            nlin = nlin + 1;
        % Find end bit  
        elseif length(line) >= 14 && strcmpi(line(1:14),'-TROP/SOLUTION'); 
            elin = nlin;
            break;
        end
    end
    fclose(fid);
    % Stop function if file is empty
    if line == -1
        % file = strsplit(fullpathname,'\'); % only available in R2013a or newer
        file = textscan(fullpathname,'%s','delimiter','\'); file = file{:};
        set(handles.plot_ztd_status_text,'String',['Error, ' file{end} ' contains no data']);
        return;
    end
    % Stop function if block not found
    if exist('slin','var') == 0 || exist('elin','var') == 0
        % file = strsplit(fullpathname,'\'); % only available in R2013a or newer
        file = textscan(fullpathname,'%s','delimiter','\'); file = file{:};
        set(handles.plot_ztd_status_text,'String',['Error, no TROP/SOLUTION block in ' file{end}]);
        return;
    end
    % Load troposphere parameters
    fid = fopen(fullpathname,'r');
    format = ['%4s %2f:%3f:%5f ',repmat('%f ',1,ndat-2)];
    dat = textscan(fid,format,elin-slin-2,'HeaderLines',slin+1);  
    sta = dat{1};
    % Compute year (4 char) from yy (2char)
    if min(dat{2}) < 50; dat{2} = dat{2}+2000;
    else dat{2} = dat{2}+1900; end
    
    % !!!!! Check if more days are available and select 2nd day
    day = unique(dat{3});
    if length(day) > 2
        id = dat{3} ~= day(2);     
        for i = 1:ndat+2
            dat{i}(id) = [];
        end        
    end
    
    % % Find large stddev
    % % fprintf('Outliers with stddev(ZTD) > 10 mm\n');
    % id = find(abs(dat{6}) > 10);
    % if ~isempty(id)
    %     for i = 1:length(id)
    %         sta = dat{1};
    %         fprintf(' %4s %2.0f:%3.0f:%5.5d\n',sta{id(i)},dat{2}(id(i))-2000,dat{3}(id(i)),dat{4}(id(i)))
    %     end
    % end
    
    % Compute MJD
    for i = 1:length(dat{3})
        mjd(i) = date2mjd(dat{2}(i),1,0)+dat{3}(i)+dat{4}(i)./86400;
    end
    dat{2} = mjd';
    % Delete Doy and Sod from cell array
    dat(3:4) = [];
    % Set units to [mm]
    if mean(dat{3}) < 10
        dat{3} = dat{3}.*1000;
        dat{4} = dat{4}.*1000;
    end
    % Define content vector
    id_cont = strcmp(lin_cont,'TROTOT');
    lin_cont(id_cont) = {'ZTD [mm]'};
    id_cont = strcmp(lin_cont,'TROWET');
    lin_cont(id_cont) = {'ZWD [mm]'};
    id_cont = strcmp(lin_cont,'TROHYD');
    lin_cont(id_cont) = {'ZHD [mm]'};    
    id_cont = strcmp(lin_cont,'TGNTOT');
    lin_cont(id_cont) = {'N-Gradient [mm]'};
    id_cont = strcmp(lin_cont,'TGETOT');
    lin_cont(id_cont) = {'E-Gradient [mm]'};
    id_cont = strcmp(lin_cont,'STDDEV');
    lin_cont(id_cont) = {'StdDev [mm]'};
    id_cont = strcmp(lin_cont,'STDEV');
    lin_cont(id_cont) = {'StdDev [mm]'};  
    dat_cont = {'Station','MJD',lin_cont{3:ndat}};
    fclose(fid);
    % Define satellite vector
    sat = 'No';
end

%% Read slant delays
%-------------------------------------------------------------------------
if isequal(block,'slant') 
    % Open file and find block
    fid = fopen(fullpathname,'r');
    % Check if file exist
    if fid ~= -1
        % Initialise variables
        nlin = 0;
        % Search for block 'TROP/SOLUTION'
        while ~feof(fid)
            line = fgetl(fid);
            nlin = nlin + 1;
            % Find start bit
            if length(line) >= 15 && strcmpi(line(1:15),'+SLANT/SOLUTION')
                slin = nlin;
                % Read line
                line = fgetl(fid);
                % Read content
                %lin_cont = strsplit(line,' '); % only available in R2013a or newer
                lin_cont = textscan(line,'%s'); lin_cont = lin_cont{:};
                % Get number of entries
                ndat = length(lin_cont);
                nlin = nlin + 1;
            % Find end bit  
            elseif length(line) >= 15 && strcmpi(line(1:15),'-SLANT/SOLUTION')
                elin = nlin;
                break;
            end
        end
        fclose(fid);
        % Stop function if file is empty
        if line == -1
            % file = strsplit(fullpathname,'\'); % only available in R2013a or newer
            file = textscan(fullpathname,'%s','delimiter','\'); file = file{:};
            set(handles.plot_ztd_status_text,'String',['Error, ' file{end} ' contains no data']);
            return;
        end
        % Stop function if block not found
        if exist('slin','var') == 0 || exist('elin','var') == 0
            % file = strsplit(fullpathname,'\'); % only available in R2013a or newer
            file = textscan(fullpathname,'%s','delimiter','\'); file = file{:};
            set(handles.plot_ztd_status_text,'String',['Error, no SLANT/SOLUTION block in ' file{end}]);
            return;
        end
        % Load troposphere parameters
        fid = fopen(fullpathname,'r');
        format = ' %4s %2f:%3f:%5f %f %f %f %f %f %f %f %f %s %f %f %f';
        dat = textscan(fid,format,elin-slin-2,'HeaderLines',slin+1);   
        sta = dat{1};
        % Compute year (4 char) from yy (2char)
        if min(dat{2}) < 50; dat{2} = dat{2}+2000;
        else dat{2} = dat{2}+1900; end

        % !!!!! Check if more days are available and select 2nd day
        day = unique(dat{3});
        if length(day) > 2
            id = dat{3} ~= day(2);     
            for i = 1:ndat+2
                dat{i}(id) = [];
            end        
        end

        % Find large stddev
        % fprintf('Outliers with stddev(ZTD) > 10 mm\n');
        id = find(dat{6} > 10);
        if ~isempty(id)
            for i = 1:length(id)            
                fprintf('%4s %2.0f:%3.0f:%5.5d\n',sta{id(i)},dat{2}(id(i))-2000,dat{3}(id(i)),dat{4}(id(i)))
            end
        end

        % Compute MJD
        for i = 1:length(dat{3})
            mjd(i) = date2mjd(dat{2}(i),1,0)+dat{3}(i)+dat{4}(i)./86400;
        end
        dat{1} = mjd';
        % Delete Doy and Sod from cell array
        dat(2:4) = [];
        % Set units to [mm]
        if mean(dat{2}) < 10
            dat{3} = dat{3}.*1000;
            dat{4} = dat{4}.*1000;
        end
        % Define content vector
        id_cont = strcmp(lin_cont,'SL_TOT');
        lin_cont(id_cont) = {'STD [m]'};
        id_cont = strcmp(lin_cont,'SL_WET');
        lin_cont(id_cont) = {'SWD [m]'};
        id_cont = strcmp(lin_cont,'SL_HYD');
        lin_cont(id_cont) = {'SHD [m]'};
        id_cont = strcmp(lin_cont,'STDDEV');
        lin_cont(id_cont) = {'StdDev [mm]'};
        id_cont = strcmp(lin_cont,'SL_RES');
        lin_cont(id_cont) = {'Residuals [mm]'};
        id_cont = strcmp(lin_cont,'SL_ELE');
        lin_cont(id_cont) = {'Elevation angle [�]'};
        id_cont = strcmp(lin_cont,'SL_AZI');
        lin_cont(id_cont) = {'Azimuth angle [�]'};
        dat_cont = {'STD [m]','MJD',lin_cont{4:ndat},'Station','PRN'};
        fclose(fid);
        % Sort data
        dat = [dat{2}./1000,dat]; dat(3) = [];
        dat{5} = dat{5}/1000; % SHD mm -> m
        dat{6} = dat{6}/1000; % SWD mm -> m
        % Define sat vector and delete column from dat
        sat = dat{10}; dat(10) = []; dat_cont(10) = [];
    end
end