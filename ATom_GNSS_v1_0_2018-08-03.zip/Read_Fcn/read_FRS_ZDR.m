function [dat,dat_cont,sta,sat] = read_FRS_ZDR(fullpathname)

% The function read_FRS_ZDR reads the Napeos zero-difference residuals
% from file

% Copyright (C) 2018 Gregor Moeller
% All rights reserved.
% Email: gregor.moeller@tuwien.ac.at

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.

%% Read FRS meta data
fid = fopen(fullpathname,'r');
% Skip first 12 lines
for i = 1:13, Zeile = fgets(fid); end
% Read number of baselines
nbas = str2double(Zeile(43:45));
% Skip next 3 lines
for i = 1:3, Zeile = fgets(fid); end    
% Read baselines
for i = 1:nbas
    Zeile = fgets(fid);
    sta_list(i) = {Zeile(6:9)};
    year(i) = str2double(Zeile(42:45));
    mn(i)   = str2double(Zeile(47:48));
    dy(i)   = str2double(Zeile(50:51));
    hh(i)   = str2double(Zeile(53:54));
    mm(i)   = str2double(Zeile(56:57));
    ss(i)   = str2double(Zeile(59:60));
    doy(i)  = str2double(Zeile(64:66));
    dt(i)   = str2double(Zeile(90:94));
end

% Set time parameters
year = min(year);
mn   = min(mn);
dy   = min(dy);
sod  = min(hh.*3600+mm.*60+ss);
dt   = min(dt);
mjd0 = (cal2jd(year,mn,dy) - 2400000.5) + sod/86400;
% redt = Zeile(53:60);
% dt   = str2double(Zeile(90:94));
%year = str2double(Zeile(42:45));
%nepo = 86400/dt;
fclose(fid);
% if ~strcmp(redt,'00:00:00'); % Test begin of data
%     fprintf('Referenzepoche beginnt nicht um Mitternacht\n');
% end
if dt ~= 30  % Test sampling intervall
    fprintf('Epochenabstand ist nicht 30 Sekunden\n');
end
    
%% Read ZDR
fid = fopen(fullpathname,'r');
data = textscan(fid, '%d %f %d %2.2d %s %f %f %f','headerLines',20+nbas);
fclose(fid);
num   = data{1};
epoch = data{2};
sat   = data{4}; sat = cellstr(num2str(sat,'%2.2d\n'));
ZDR   = data{6}*1000;
ele   = data{7};
azi   = data{8};

% Get vector of station names
sta = sta_list(num);

% Store data in matrix
dat(1,:) = ZDR; % [mm]
dat(2,:) = mjd0 + (epoch-1)*dt/86400;
dat(3,:) = ele;
dat(4,:) = azi;

% Description of content
dat_cont = {'ZDR [mm]';'MJD';'Elevation angle [�]';'Azimuth angle [�]';'Station';'SatID'};
end