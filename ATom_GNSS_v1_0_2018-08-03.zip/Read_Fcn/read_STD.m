function [dat,dat_cont,sta,sat] = read_STD(fullpathname)

%% Read STD data
fid  = fopen(fullpathname,'r');
data = textscan(fid,'%f %s %s %f %f %f');
fclose(fid);  
time = data{1}; % MJD
sta  = data{2};
sat  = data{3};
std  = data{4};
elev = data{5};
azim = data{6};

% Store data in matrix
dat(1,:) = std;
dat(2,:) = time;
dat(3,:) = elev;
dat(4,:) = azim;

% Description of content
dat_cont = {'STD [m]';'MJD';'Elevation angle [�]';'Azimuth angle [�]';'Station';'SatID'};

end