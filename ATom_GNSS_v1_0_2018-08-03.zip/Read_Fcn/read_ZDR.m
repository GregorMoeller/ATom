function [dat,dat_cont,sta,sat] = read_ZDR(fullpathname)

%% Read ZDR data
fid  = fopen(fullpathname,'r');
data = textscan(fid,'%f %s %s %f %f %f');
fclose(fid);  
time = data{1}; % MJD
sta  = data{2};
sat  = data{3};
azim = data{4};
elev = data{5};
ZDR  = data{6};

% Store data in matrix
dat(1,:) = ZDR;
dat(2,:) = time;
dat(3,:) = elev;
dat(4,:) = azim;

% Description of content
dat_cont = {'ZDR [mm]';'MJD';'Elevation angle [�]';'Azimuth angle [�]';'Station';'SatID'};

end