function [dat,dat_cont] = read_ZTD(fullpathname)

% Reads the NWM derived ZTD files

% Developed by: Gregor M�ller (gregor.moeller@tuwien.ac.at)
% Last update: 22-07-2015

% Input
% fullpathname  ... path/filename

% Output
% dat           ... [Station name, MJD, Data lines]
% dat_cont      ... Content description

%% Read SWD data
fid  = fopen(fullpathname,'r');
data = textscan(fid,'%4s %f %f %f %f %f');
fclose(fid);

% data{1} ... GNSS station name
% data{2} ... Latitude [�]
% data{3} ... Longitude[�]
% data{4} ... orthometric Height [m]
% data{5} ... ZHD [m]
% data{6} ... ZWD [m]

% Get file name
id    = findstr(fullpathname,'\');
fname = fullpathname(id(end)+1:end);

% Get date (Year,Month,Day,Hour) of data
yr  = str2double(fname(1:4));
mn  = str2double(fname(5:6));
day = str2double(fname(7:8));
hr  = str2double(fname(9:10));
%hr  = str2double(fname(end-5:end-3))
% Convert date to MJD
mjd = zeros(length(data{1}),1) + cal2jd(yr,mn,day)+hr/24 - 2400000.5;

dat{1} = data{1};
dat{2} = mjd;
dat{3} = (data{5}+data{6})*1000; % [mm]
dat{4} = data{6}*1000; % [mm]

% Description of content
dat_cont = {'Station','MJD','ZTD [mm]','ZWD [mm]'};

end