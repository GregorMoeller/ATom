function [dat,string] = read_NEU(fullpathname,statlist,handles)

%% Read NEU data
fid  = fopen(fullpathname,'r');
data = textscan(fid,'%s %f %f %f');
fclose(fid);  
stat = data{1};
N    = data{2};
E    = data{3};
U    = data{4};

% Extract NEU only for stations in statlist
dat = zeros(length(statlist),3);
string = [];
for i = 1:length(statlist)
    id = find(strcmp(stat,statlist{i}));
    if ~isempty(id)
        dat(i,:) = [N(id),E(id),U(id)];
        string{i} = sprintf('%s %8.4f �  %8.4f � %8.2f m',statlist{i},dat(i,1),dat(i,2),dat(i,3));
    else
        dat(i,:) = [0,0,0];    
    end
    
end

% Description of content
%  dat_cont = {'N [degree]';'E [degree]';'U [m]'};

end