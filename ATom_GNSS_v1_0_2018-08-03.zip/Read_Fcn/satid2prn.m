function [satBi] = satid2prn(satNi)

% Function satid2prn converts GPS and GLONASS satellite IDs into PRN

% Copyright (C) 2018 Gregor Moeller
% All rights reserved.
% Email: gregor.moeller@tuwien.ac.at

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.

if strcmp(satNi,'GPS-23')      || strcmp(satNi,'32')  || strcmp(satNi,'G32'); satBi = 'G32';
elseif strcmp(satNi,'GPS-26')  || strcmp(satNi,'26')  || strcmp(satNi,'G26'); satBi = 'G26';
elseif strcmp(satNi,'GPS-33')  || strcmp(satNi,'03')  || strcmp(satNi,'G03'); satBi = 'G03';
elseif strcmp(satNi,'GPS-34')  || strcmp(satNi,'04')  || strcmp(satNi,'G04'); satBi = 'G04';
elseif strcmp(satNi,'GPS-35')  || strcmp(satNi,'30')  || strcmp(satNi,'G30'); satBi = 'G30';
elseif strcmp(satNi,'GPS-36')  || strcmp(satNi,'06')  || strcmp(satNi,'G06'); satBi = 'G06';
elseif strcmp(satNi,'GPS-38')  || strcmp(satNi,'08')  || strcmp(satNi,'G08'); satBi = 'G08';
elseif strcmp(satNi,'GPS-39')  || strcmp(satNi,'09')  || strcmp(satNi,'G09'); satBi = 'G09';
elseif strcmp(satNi,'GPS-40')  || strcmp(satNi,'10')  || strcmp(satNi,'G10'); satBi = 'G10';
elseif strcmp(satNi,'GPS-41')  || strcmp(satNi,'14')  || strcmp(satNi,'G14'); satBi = 'G14';
elseif strcmp(satNi,'GPS-43')  || strcmp(satNi,'13')  || strcmp(satNi,'G13'); satBi = 'G13';
elseif strcmp(satNi,'GPS-44')  || strcmp(satNi,'28')  || strcmp(satNi,'G28'); satBi = 'G28';
elseif strcmp(satNi,'GPS-45')  || strcmp(satNi,'21')  || strcmp(satNi,'G21'); satBi = 'G21';
elseif strcmp(satNi,'GPS-46')  || strcmp(satNi,'11')  || strcmp(satNi,'G11'); satBi = 'G11';
elseif strcmp(satNi,'GPS-47')  || strcmp(satNi,'22')  || strcmp(satNi,'G22'); satBi = 'G22';
elseif strcmp(satNi,'GPS-51')  || strcmp(satNi,'20')  || strcmp(satNi,'G20'); satBi = 'G20';
elseif strcmp(satNi,'GPS-54')  || strcmp(satNi,'18')  || strcmp(satNi,'G18'); satBi = 'G18';
elseif strcmp(satNi,'GPS-56')  || strcmp(satNi,'16')  || strcmp(satNi,'G16'); satBi = 'G16';
elseif strcmp(satNi,'GPS-59')  || strcmp(satNi,'19')  || strcmp(satNi,'G19'); satBi = 'G19';
elseif strcmp(satNi,'GPS-60')  || strcmp(satNi,'23')  || strcmp(satNi,'G23'); satBi = 'G23';
elseif strcmp(satNi,'GPS-61')  || strcmp(satNi,'02')  || strcmp(satNi,'G02'); satBi = 'G02';
elseif strcmp(satNi,'GPS-52')  || strcmp(satNi,'31')  || strcmp(satNi,'G31'); satBi = 'G31';
elseif strcmp(satNi,'GPS-53')  || strcmp(satNi,'17')  || strcmp(satNi,'G17'); satBi = 'G17';
elseif strcmp(satNi,'GPS-58')  || strcmp(satNi,'12')  || strcmp(satNi,'G12'); satBi = 'G12';
elseif strcmp(satNi,'GPS-55')  || strcmp(satNi,'15')  || strcmp(satNi,'G15'); satBi = 'G15';
elseif strcmp(satNi,'GPS-57')  || strcmp(satNi,'29')  || strcmp(satNi,'G29'); satBi = 'G29';
elseif strcmp(satNi,'GPS-48')  || strcmp(satNi,'07')  || strcmp(satNi,'G07'); satBi = 'G07';
elseif strcmp(satNi,'GPS-50')  || strcmp(satNi,'05')  || strcmp(satNi,'G05'); satBi = 'G05';
elseif strcmp(satNi,'GPS-62')  || strcmp(satNi,'25')  || strcmp(satNi,'G25'); satBi = 'G25';
elseif strcmp(satNi,'GPS-63')  || strcmp(satNi,'01')  || strcmp(satNi,'G01'); satBi = 'G01';
elseif strcmp(satNi,'GPS-65')  || strcmp(satNi,'24')  || strcmp(satNi,'G24'); satBi = 'G24';
elseif strcmp(satNi,'GPS-66')  || strcmp(satNi,'27')  || strcmp(satNi,'G27'); satBi = 'G27';
elseif strcmp(satNi,'GLO-712') || strcmp(satNi,'95')  || strcmp(satNi,'R08'); satBi = 'R08';
elseif strcmp(satNi,'GLO-715') || strcmp(satNi,'101') || strcmp(satNi,'R14'); satBi = 'R14';
elseif strcmp(satNi,'GLO-716') || strcmp(satNi,'102') || strcmp(satNi,'R15'); satBi = 'R15';
elseif strcmp(satNi,'GLO-717') || strcmp(satNi,'103') || strcmp(satNi,'R10'); satBi = 'R10';
elseif strcmp(satNi,'GLO-719') || strcmp(satNi,'105') || strcmp(satNi,'R20'); satBi = 'R20';
elseif strcmp(satNi,'GLO-720') || strcmp(satNi,'106') || strcmp(satNi,'R19'); satBi = 'R19';
elseif strcmp(satNi,'GLO-721') || strcmp(satNi,'107') || strcmp(satNi,'R13'); satBi = 'R13';
elseif strcmp(satNi,'GLO-723') || strcmp(satNi,'109') || strcmp(satNi,'R11'); satBi = 'R11';
elseif strcmp(satNi,'GLO-724') || strcmp(satNi,'110') || strcmp(satNi,'R18'); satBi = 'R18';
elseif strcmp(satNi,'GLO-725') || strcmp(satNi,'111') || strcmp(satNi,'R21'); satBi = 'R21';
elseif strcmp(satNi,'GLO-728') || strcmp(satNi,'114') || strcmp(satNi,'R02'); satBi = 'R02';
elseif strcmp(satNi,'GLO-730') || strcmp(satNi,'116') || strcmp(satNi,'R01'); satBi = 'R01';
elseif strcmp(satNi,'GLO-733') || strcmp(satNi,'117') || strcmp(satNi,'R06'); satBi = 'R06';
elseif strcmp(satNi,'GLO-734') || strcmp(satNi,'118') || strcmp(satNi,'R05'); satBi = 'R05';
elseif strcmp(satNi,'GLO-731') || strcmp(satNi,'119') || strcmp(satNi,'R22'); satBi = 'R22';
elseif strcmp(satNi,'GLO-732') || strcmp(satNi,'120') || strcmp(satNi,'R23'); satBi = 'R23';
elseif strcmp(satNi,'GLO-735') || strcmp(satNi,'121') || strcmp(satNi,'R24'); satBi = 'R24';
elseif strcmp(satNi,'GLO-736') || strcmp(satNi,'122') || strcmp(satNi,'R09'); satBi = 'R09';
elseif strcmp(satNi,'GLO-737') || strcmp(satNi,'123') || strcmp(satNi,'R12'); satBi = 'R12';
elseif strcmp(satNi,'GLO-738') || strcmp(satNi,'124') || strcmp(satNi,'R16'); satBi = 'R16';
elseif strcmp(satNi,'GLO-742') || strcmp(satNi,'126') || strcmp(satNi,'R04'); satBi = 'R04';
elseif strcmp(satNi,'GLO-743') || strcmp(satNi,'127') || strcmp(satNi,'R08'); satBi = 'R08';
elseif strcmp(satNi,'GLO-744') || strcmp(satNi,'128') || strcmp(satNi,'R03'); satBi = 'R03';
elseif strcmp(satNi,'GLO-745') || strcmp(satNi,'129') || strcmp(satNi,'R07'); satBi = 'R07';
elseif strcmp(satNi,'GLO-746') || strcmp(satNi,'130') || strcmp(satNi,'R17'); satBi = 'R17';
elseif strcmp(satNi,'GLO-747') || strcmp(satNi,'131') || strcmp(satNi,'R02'); satBi = 'R02';
elseif strcmp(satNi,'GLO-754') || strcmp(satNi,'132') || strcmp(satNi,'R18'); satBi = 'R18';
elseif strcmp(satNi,'GLO-755') || strcmp(satNi,'133') || strcmp(satNi,'R21'); satBi = 'R21';
elseif strcmp(satNi,'GLO-714') || strcmp(satNi,'134') || strcmp(satNi,'R18'); satBi = 'R18';
elseif strcmp(satNi,'GLO-801') || strcmp(satNi,'135') || strcmp(satNi,'R26'); satBi = 'R26';
else
        fprintf('PRN %s not defined in satid2prn.m\n',satNi); 
        satBi = 'error';
end

