function [dat,dat_cont,sta,sat] = read_SWD(fullpathname)

% Function read_SWD reads the slant wet delays as provided in *.SWD format

% Copyright (C) 2018 Gregor Moeller
% All rights reserved.
% Email: gregor.moeller@tuwien.ac.at

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.

%% Read SWD data
fid  = fopen(fullpathname,'r');
data = textscan(fid,'%f %s %s %f %f %f');
fclose(fid);  
time = data{1}; % MJD
sta  = data{2};
sat  = data{3};
swd  = data{4};
elev = data{5};
azim = data{6};

% Store data in matrix
dat(1,:) = swd;
dat(2,:) = time;
dat(3,:) = elev;
dat(4,:) = azim;

% Description of content
dat_cont = {'SWD [m]';'MJD';'Elevation angle [�]';'Azimuth angle [�]';'Station';'SatID'};

end