function [brdc] = read_brdc (file)

% Input
% file   ... file name(s)

% Counter
count1 = 1;

% Number of files
[n_files,~] = size(file);

% Loop for each file
for i = 1:n_files
    % Check file type (GPS or GLONASS broadcast message)
    if strcmp(file(i,end),'n')
        id_sat = 'G';
    elseif strcmp(file(i,end),'g')
        id_sat = 'R';
    end
    % Year (from file name)
    yy = file(i,end-2:end-1);

    %% GPS navigation message (*.yyn)
    if strcmp(id_sat,'G')
        % Open navigation message
        fid = fopen(file(i,:),'r');
        while ~feof(fid)
            line = fgets(fid);
            if strcmp(line(4:5),yy) % find year
                line = regexprep(line,'D','E');
                % line 1
                brdc.sat(count1)  = {sprintf('%1s%2.2d',id_sat,str2double(line(1:2)))};
                brdc.yy(count1)   = str2double(line(4:5))+2000;
                brdc.mm(count1)   = str2double(line(7:8));
                brdc.dd(count1)   = str2double(line(10:11));
                brdc.hh(count1)   = str2double(line(13:14));
                brdc.min(count1)  = str2double(line(16:17));
                brdc.sec(count1)  = str2double(line(19:22));
                brdc.mjd(count1)  = date2mjd(brdc.yy(count1),brdc.mm(count1),brdc.dd(count1),brdc.hh(count1),brdc.min(count1),brdc.sec(count1));
                [~,brdc.doy(count1),brdc.sod(count1)] = mjd2doy(brdc.mjd(count1));
                % line 2
                line = fgets(fid); line = regexprep(line,'D','E');
                brdc.Crs(count1)  = str2double(line(23:41));
                brdc.dn(count1)   = str2double(line(42:60));
                brdc.Mo(count1)   = str2double(line(61:79));
                % line 3
                line = fgets(fid); line = regexprep(line,'D','E');
                brdc.Cuc(count1)  = str2double(line(4:22));
                brdc.e(count1)    = str2double(line(23:41));
                brdc.Cus(count1)  = str2double(line(42:60));
                brdc.a(count1)    = str2double(line(61:79)).^2;
                % line 4
                line = fgets(fid); line = regexprep(line,'D','E');
                brdc.toe(count1)  = str2double(line(4:22));
                brdc.Cic(count1)  = str2double(line(23:41));
                brdc.OM(count1)   = str2double(line(42:60));
                brdc.Cis(count1)  = str2double(line(61:79));
                % line 5
                line = fgets(fid); line = regexprep(line,'D','E');
                brdc.io(count1)   = str2double(line(4:22));
                brdc.Crc(count1)  = str2double(line(23:41));
                brdc.om(count1)   = str2double(line(42:60));
                brdc.OMd(count1)  = str2double(line(61:79));
                % line 6
                line = fgets(fid); line = regexprep(line,'D','E');
                brdc.idot(count1) = str2double(line(4:22));
                brdc.week(count1) = str2double(line(42:60));
                count1 = count1 + 1;
            end
        end
        fclose(fid);
        
    %% GLONASS navigation message (*.yyg)    
    elseif strcmp(id_sat,'R')
        fid = fopen(file(i,:),'r');
        while ~feof(fid)
            line = fgets(fid);
            if strcmp(line(61:64),'LEAP')
                brdc.lsec = str2double(line(5:7));
            end
            if strcmp(line(4:5),yy) % find year
                line = regexprep(line,'D','E');
                % line 1
                brdc.sat(count1)  = {sprintf('%1s%2.2d',id_sat,str2double(line(1:2)))};
                brdc.yy(count1)   = str2double(line(4:5))+2000;
                brdc.mm(count1)   = str2double(line(7:8));
                brdc.dd(count1)   = str2double(line(10:11));
                brdc.hh(count1)   = str2double(line(13:14));
                brdc.min(count1)  = str2double(line(16:17));
                brdc.sec(count1)  = str2double(line(19:22));
                brdc.mjd(count1)  = date2mjd(brdc.yy(count1),brdc.mm(count1),brdc.dd(count1),brdc.hh(count1),brdc.min(count1),brdc.sec(count1));
                [~,brdc.doy(count1),brdc.sod(count1)] = mjd2doy(brdc.mjd(count1));
                % line 2
                line = fgets(fid); line = regexprep(line,'D','E');
                brdc.x(count1)    = str2double(line(4:22))*1e3;
                brdc.vx(count1)   = str2double(line(23:41))*1e3;
                brdc.ax(count1)   = str2double(line(42:60))*1e3;
                % line 3
                line = fgets(fid); line = regexprep(line,'D','E');
                brdc.y(count1)    = str2double(line(4:22))*1e3;
                brdc.vy(count1)   = str2double(line(23:41))*1e3;
                brdc.ay(count1)   = str2double(line(42:60))*1e3;            
                % line 4
                line = fgets(fid); line = regexprep(line,'D','E');
                brdc.z(count1)    = str2double(line(4:22))*1e3;
                brdc.vz(count1)   = str2double(line(23:41))*1e3;
                brdc.az(count1)   = str2double(line(42:60))*1e3;            
                count1 = count1 + 1;
            end
        end
        fclose(fid);
    end
end