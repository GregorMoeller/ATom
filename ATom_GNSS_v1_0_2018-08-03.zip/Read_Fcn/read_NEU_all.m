function [dat,string] = read_NEU_all(fullpathname,handles)

% Function read_NEU_all reads all available station coordinates 
% (lat,lon,height) as provided in *.NEU format

% Copyright (C) 2018 Gregor Moeller
% All rights reserved.
% Email: gregor.moeller@tuwien.ac.at

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.

%% Read NEU data
fid  = fopen(fullpathname,'r');
data = textscan(fid,'%s %f %f %f');
fclose(fid);  
stat = data{1};
N    = data{2};
E    = data{3};
U    = data{4};

% Extract NEU for all stations
dat = zeros(length(stat),3);
string = [];
for i = 1:length(stat)
        dat(i,:) = [N(i),E(i),U(i)];
        string{i} = sprintf('%4s %8.4f �  %8.4f � %8.2f m',stat{i},dat(i,1),dat(i,2),dat(i,3));    
end

% Description of content
%  dat_cont = {'N [degree]';'E [degree]';'U [m]'};

end