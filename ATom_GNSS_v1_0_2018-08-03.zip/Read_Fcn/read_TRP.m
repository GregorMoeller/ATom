function [dat,dat_cont] = read_TRP(fullpathname)

% Function read_TRP reads the Bernese troposphere file

% Copyright (C) 2018 Gregor Moeller
% All rights reserved.
% Email: gregor.moeller@tuwien.ac.at

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.

% Last update: 08-04-2016

% Input
% fullpathname  ... path/filename

% Output
% dat           ... [Station name, MJD, Data lines]
% dat_cont      ... Content description

%% Read troposphere estimates
%-------------------------------------------------------------------------
% Open file
fid = fopen(fullpathname,'r');
line = fgetl(fid);
line = fgetl(fid);
line = fgetl(fid);
%zhd_id  = str2double(line(17:24))
% Gradients available 0 == No, else == Yes
grad_id = str2double(line(65:72));
% Read data block
if grad_id == 0
    dat = textscan(fid,'%15c %s %f %f %f %f %f %f %f %f %f %f','Headerlines',2);
else
    dat = textscan(fid,'%15c %s %f %f %f %f %f %f %f %f %f %f %f %f %f %f','Headerlines',2);
end
fclose(fid);

% Compute MJD
for i = 1:length(dat{3})
    mjd(i) = date2mjd(dat{3}(i),dat{4}(i),dat{5}(i),dat{6}(i),dat{7}(i),dat{8}(i));
end

% Restore data
dat{1} = cellstr((dat{1}(:,1:4)));
dat{2} = mjd';
dat{3} = dat{12}*1000;
dat{4} = dat{10}*1000;
dat{5} = dat{11}*1000;
if grad_id == 0
    dat{6} = zeros(length(dat{4}),1);
    dat{7} = zeros(length(dat{4}),1);
    dat{8} = zeros(length(dat{4}),1);
    dat{9} = zeros(length(dat{4}),1);
else
    dat{6} = dat{13}*1000;
    dat{7} = dat{14}*1000;
    dat{8} = dat{15}*1000;
    dat{9} = dat{16}*1000;
end

% Define content vector  
dat_cont = {'Station','MJD','ZTD [mm]','ZWD [mm]','StdDev [mm]','N-Gradient [mm]','StdDev [mm]','E-Gradient [mm]','StdDev [mm]'};

end
