function [dat,dat_cont,sta] = read_SYNOP(fullpathname)

%% Read SYNOP data
fid  = fopen(fullpathname,'r');
data = textscan(fid,'%4f-%2f-%2f %2f:%2f %f %f %f %f %f','HeaderLines',1);
fclose(fid); 
year = data{1};
mm   = data{2};
dd   = data{3};
hh   = data{4};
min  = data{5};

mjd = zeros(1,length(min));
for i = 1:length(min)
    mjd(i) = date2mjd(year(i),mm(i),dd(i),hh(i),min(i));
    %fprintf('%4.0f %2.0f %2.0f %2.0f %2.0f %11.5f\n',year(i),mm(i),dd(i),hh(i),min(i),mjd(i));
end   
file = strsplit(fullpathname,'\');
sta  = {file{end}(1:5)};
sta  = repmat(sta,length(min),1); % station id
p    = data{6}; % pressure hPa
T    = data{7}; % temperature �C
h    = data{9}/100; % relative humidity %

% Find bad entries
recT = find(T < -80);
recp = find(p < 0);
rech = find(h < 0);
rec  = unique([recT;recp;rech]);

% Delete entries
mjd(rec) = [];
T(rec)   = [];
p(rec)   = [];
h(rec)   = [];
sta(rec) = [];

% Remove double entries
[~,id,~] = unique(mjd);
mjd = mjd(id);
T   = T(id);
p   = p(id);
h   = h(id);
sta = sta(id);

% Store data in matrix
dat(1,:) = mjd;
dat(2,:) = T;
dat(3,:) = p;
dat(4,:) = h;

% Description of content
dat_cont = {'MJD';'Temperature [�C]';'Pressure [hPa]';'Rel humidity [ ]'};

end