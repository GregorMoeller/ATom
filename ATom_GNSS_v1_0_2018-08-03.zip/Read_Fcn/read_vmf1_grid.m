function [ah_vec,aw_vec] = read_vmf1_grid(mjd,ell)

% Function read_vmf1_grid searches for grid file close in time and computes
% mapping coefficients ah, aw for selected station

% Copyright (C) 2018 Gregor Moeller
% All rights reserved.
% Email: gregor.moeller@tuwien.ac.at

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.

% mjd   ... Modified Julian Date
% ell   ... ellipsoidal station coordinates lat [degrees], lon [degrees] ,hell [m]

% Closest 6 hour period
mjd_6h = round(mjd*4)./4;
% List of relevant 6 hour intervals
mjd_6h_list = unique(mjd_6h);

% Read vmf1 grid of period before and after current date 
% (needed for temporal interpolation)

if length(mjd_6h_list) == 1
    mjd_6h_list = [mjd_6h_list-0.25,mjd_6h_list,mjd_6h_list+0.25];
end

% Initialise variable
ah_ell = zeros(length(mjd_6h_list),1);
aw_ell = zeros(length(mjd_6h_list),1);

for i = 1:length(mjd_6h_list)
    % Convert mjd to date
    [yr,mn,dy] = jd2cal(fix(min(mjd_6h_list(i)))+2400000.5);
    % Hour of the day
    hh = (mjd_6h_list(i)-fix(mjd_6h_list(i)))*24;
    % Open grid file with mapping coefficients
    %sprintf('VMFG_%4.4d%2.2d%2.2d.H%2.2d',yr,mn,dy,hh)
    file = fopen([pwd '\Mapping_Fcn\vmf1\' sprintf('VMFG_%4.4d%2.2d%2.2d.H%2.2d',yr,mn,dy,hh)],'r');
    dat  = textscan(file,'%f %f %f %f %f %f','CommentStyle','!');
    fclose(file);
    % Restore grid data
    lat = dat{1}; lat = reshape(lat,144,[]);
    lon = dat{2}; lon = reshape(lon,144,[]);
    ah  = dat{3}; ah  = reshape(ah,144,[]);
    aw  = dat{4}; aw  = reshape(aw,144,[]); 
    % Interpolate data to station coordinates
    ah_ell(i) = interp2(lat,lon,ah,ell(1),ell(2));
    aw_ell(i) = interp2(lat,lon,aw,ell(1),ell(2));
end

% Interpolate and store final coefficients to return
ah_vec = interp1(mjd_6h_list,ah_ell,mjd');
aw_vec = interp1(mjd_6h_list,aw_ell,mjd');