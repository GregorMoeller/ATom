function mjd = date2mjd(year,month,day,hour,minute,second)

% function to convert date to modified julian date
% input parameters:
% year   years, e.g. 2007
% month   months
% day   days
% hour   hours
% minute  minutes
% second   seconds
% 
% Johannes Boehm, 2001-03-27
% mod. 2009-02-03 Johannes Boehm 
% mod. 2009-09-30 Lucia Plank
% mod. 2015-02-05 Daniel Landskron

if (nargin < 6)
    second = zeros(length(year),1);
    if (nargin < 5)
        minute = zeros(length(year),1);
        if (nargin < 4)
            hour = zeros(length(year),1);
            if (nargin < 3)
                day = zeros(length(year),1);
                if (nargin < 2)
                    month = zeros(length(year),1);
                end
            end
        end
    end
end

if (month<=2)
    month = month+12;
    year = year-1;
end

for i=1:length(year)
    
    % if date is before Oct 4, 1582
    if (year(i)<=1582)&&(month(i)<=10)&&(day(i)<=4)
        b = -2;
        % if date is after Oct 4, 1582
    else
        b = floor(year(i)/400)-floor(year(i)/100);
    end
    
    jd = floor(365.25*year(i))-2400000.5;
    
    mjd(i,1) = jd+floor(30.6001*(month(i)+1))+b+1720996.5+day(i)+hour(i)/24+minute(i)/1440+second(i)/86400;
    
end



