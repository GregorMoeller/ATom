function [satpos] = cal_satpos_kepler(toe,tk,a,dn,Mo,e,om,Cuc,Cus,Crc,Crs,Cic,Cis,io,OM,OMd,id)

% The function cal_satpos_kepler reads Keplerian elements to calcuate the
% position of satellites

% Copyright (C) 2018 Gregor Moeller
% All rights reserved.
% Email: gregor.moeller@tuwien.ac.at

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.

% Input:
%  toe:  time of ephemeris
%   tk:  time difference to toe
%    a:  semi major axis [m]
%   dn:  correction for mean motion
%   Mo:  mean anomalie [rad]
%    e:  excentricity
%   om:  argument of perigee
%  Cuc:
%  Cus:
%  Crc:
%  Crs:
%  Cic:
%  Cis:
%   io:  inclination [rad]
%   OM:  RA [rad]
%  OMd:  
% idot:

% Output:
%   satpos: satellite position vector

%clear all; close all; clc; format long;

% Constants
GM  = 3.986005e14; % m^3/s^2 gravity acceleration
ome = 7.2921151467e-5; % rad/seconds angle velocity of the earth

%% Calculate Satellite positions
%Mean motion n
no = sqrt(GM./a.^3);
n = no + dn;

% Mean anomalie Mk for tk [rad]
Mk = Mo + n*tk;
if Mk<0
    Mk=Mk+pi*2;
end

% Excentric anomalie Ek
diff = 1;
numit = 0;
E_alt = Mk + e.*sin(Mk);
while (abs(diff)>0.00000001)
    numit = numit+1;
    E_neu = Mk + e.*sin(E_alt);
    diff = E_alt - E_neu;
    E_alt = E_neu;
end
Ek = E_neu;

% True anomalie
nuek = 2.*atan(sqrt((1+e)./(1-e)).*tan(Ek/2));
% Argument der Breite
phik = nuek + om;
% Korrektur des Arguments der Breite
duk = Cuc.*cos(2.*phik) + Cus.*sin(2.*phik);
% Korrektur des Radiuses
drk = Crc.*cos(2.*phik) + Crs.*sin(2.*phik);
% Korrektur des Inklinationswinkels
dik = Cic.*cos(2.*phik) + Cis.*sin(2.*phik);
% Korrigiertes Argument des Breite
uk = phik + duk;
% Korrigierter Radius
rk(1) = a(1)*(1-e(1)*cos(Ek(1))) + drk(1);
% Korrigierter Inklinationswinkel
ik = io + id*tk + dik;
% Position X in der Orbitebene
Xkp = rk.*cos(uk);
% Position Y in der Orbitebene
Ykp = rk.*sin(uk);
% Korrigierte RA
OMk = OM + (OMd - ome)*tk - ome.*toe;
% Mod Korrigierte RA
OMk = mod(OMk,2*pi);
% Erdfeste geozentrische Koordinaten
Xk = Xkp.*cos(OMk) - Ykp.*sin(OMk).*cos(ik);
Yk = Xkp.*sin(OMk) + Ykp.*cos(OMk).*cos(ik);
Zk = Ykp.*sin(ik);
satpos = [Xk, Yk, Zk];
