function [yr,doy,sod]=mjd2doy(mjd)
% JD2DOY  Converts Julian date to year and day of year.
% . Non-vectorized version. See also CAL2JD, DOY2JD,
%   GPS2JD, JD2CAL, JD2DOW, JD2GPS, JD2YR, YR2JD.
% Version: 24 Apr 99
% Usage:   [doy,yr]=jd2doy(jd)
% Input:   mjd - Modified Julian date
% Output:  doy - day of year
%          yr  - year

% Copyright (c) 2011, Michael R. Craymer
% All rights reserved.
% Email: mike@craymer.com

% Modified by Gregor M�ller, 13 Feb 2015
% jd -> mjd
% add sod

if nargin ~= 1
  warning('Incorrect number of arguments');
  return;
end
if mjd < 0
  warning('Julian date must be greater than or equal to zero');
  return;
end
jd = mjd + 2400000.5;
[yr,mn,dy] = jd2cal(jd);
doy = jd - cal2jd(yr,1,0);
sod = round((doy-floor(doy))*86400);
doy = floor(doy);

