function [satpos] = cal_satpos_numer(tk,x,vx,ax,y,vy,ay,z,vz,az)

%clear all; close all; clc;
format long;

% Reads satellite position, velocity and acceleration to calcuate the 
% position for any other time period (numerical integration using
% Runge-Kutta)

% Input:
%   tk:  time difference to toe [s]
%    x:  positon [m]
%   vx:  velocity [m/s]
%   ax:  acceleration [m/s^2]
%    y:  positon [m]
%   vy:  velocity [m/s]
%   ay:  acceleration [m/s^2]
%    z:  positon [m]
%   vz:  velocity [m/s]
%   az:  acceleration [m/s^2]

% Output:
%   satpos: satellite position vector

% Constants
GM  = 3.9860044e14; % m^3/s^2 gravity acceleration
ome = 7.292115e-5;   % rad/seconds angle velocity of the earth
C20 = -1082.63e-6;    % second zonal coefficient
ae  = 6378136;        % m radius earth at equator

%% Nummerical integration (from GTBRDG.f, ORBINT.f and GLDVDT.f in BERN50/LIB/FOR)
H = 0.25; % Interval for each iteration step (0.25 second)
if tk < 0 % Check if epoch is in the past, then H = -1
    H = -H;
end

for i = 1:abs(H):abs(tk) % Number of iteration steps   
       
    % Radius vector [m]
    r = sqrt(x^2+y^2+z^2); 
    
    % Derivates for velocities
    dvx = -GM/r^3*x+3/2*C20*GM*ae^2/r^5*x*(1-5*z^2/r^2)+ome^2*x+2*ome*vy;
    dvy = -GM/r^3*y+3/2*C20*GM*ae^2/r^5*y*(1-5*z^2/r^2)+ome^2*y-2*ome*vx;
    dvz = -GM/r^3*z+3/2*C20*GM*ae^2/r^5*z*(3-5*z^2/r^2);

    % Compute new velocity
    XK1=dvx+ax; YK1=dvy+ay; ZK1=dvz+az;
    XVII=vx+XK1*H/2; YVII=vy+YK1*H/2; ZVII=vz+ZK1*H/2;
    XII=x+XVII*H/2; YII=y+YVII*H/2; ZII=z+ZVII*H/2;
    
    dvx = -GM/r^3*XII+3/2*C20*GM*ae^2/r^5*XII*(1-5*ZII^2/r^2)+ome^2*XII+2*ome*YVII;
    dvy = -GM/r^3*YII+3/2*C20*GM*ae^2/r^5*YII*(1-5*ZII^2/r^2)+ome^2*YII-2*ome*XVII;
    dvz = -GM/r^3*ZII+3/2*C20*GM*ae^2/r^5*ZII*(3-5*ZII^2/r^2);
    
    XK2=dvx+ax; YK2=dvy+ay; ZK2=dvz+az;
    XVIII=vx+XK2*H/2; YVIII=vy+YK2*H/2; ZVIII=vz+ZK2*H/2;
    XIII=x+XVIII*H/2; YIII=y+YVIII*H/2; ZIII=z+ZVIII*H/2;
    
    dvx = -GM/r^3*XIII+3/2*C20*GM*ae^2/r^5*XIII*(1-5*ZIII^2/r^2)+ome^2*XIII+2*ome*YVIII;
    dvy = -GM/r^3*YIII+3/2*C20*GM*ae^2/r^5*YIII*(1-5*ZIII^2/r^2)+ome^2*YIII-2*ome*XVIII;
    dvz = -GM/r^3*ZIII+3/2*C20*GM*ae^2/r^5*ZIII*(3-5*ZIII^2/r^2);
    
    XK3=dvx+ax; YK3=dvy+ay; ZK3=dvz+az;
    XVIIII=vx+XK3*H; YVIIII=vy+YK3*H; ZVIIII=vz+ZK3*H;
    XIIII=x+XVIIII*H; YIIII=y+YVIIII*H; ZIIII=z+ZVIIII*H;
    
    dvx = -GM/r^3*XIIII+3/2*C20*GM*ae^2/r^5*XIIII*(1-5*ZIIII^2/r^2)+ome^2*XIIII+2*ome*YVIIII;
    dvy = -GM/r^3*YIIII+3/2*C20*GM*ae^2/r^5*YIIII*(1-5*ZIIII^2/r^2)+ome^2*YIIII-2*ome*XVIIII;
    dvz = -GM/r^3*ZIIII+3/2*C20*GM*ae^2/r^5*ZIIII*(3-5*ZIIII^2/r^2);
    
    XK4=dvx+ax; YK4=dvy+ay; ZK4=dvz+az;
    XKK=(XK1+2*XK2+2*XK3+XK4)/6;
    YKK=(YK1+2*YK2+2*YK3+YK4)/6;
    ZKK=(ZK1+2*ZK2+2*ZK3+ZK4)/6;
    XVIH=vx+XKK*H; YVIH=vy+YKK*H; ZVIH=vz+ZKK*H;
    
    % Compute new position
    XK1=vx; YK1=vy; ZK1=vz;
    XK2=XVII; YK2=YVII; ZK2=ZVII;
    XK3=XVIII; YK3=YVIII; ZK3=ZVIII;
    XK4=XVIIII; YK4=YVIIII; ZK4=ZVIIII;
    
    XKK=(XK1+2*XK2+2*XK3+XK4)/6;
    YKK=(YK1+2*YK2+2*YK3+YK4)/6;
    ZKK=(ZK1+2*ZK2+2*ZK3+ZK4)/6;
    XIH=x+XKK*H;
    YIH=y+YKK*H;
    ZIH=z+ZKK*H;
    
    % Initialisation of new integration step
    vx=XVIH; vy=YVIH; vz=ZVIH;
    x=XIH; y=YIH; z=ZIH;
end

satpos = [x, y, z];
