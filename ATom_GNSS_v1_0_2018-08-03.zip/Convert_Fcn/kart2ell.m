function [phi,lam,H] = kart2ell(X,Y,Z)

% The function kart2ell converts cartesian coordinates into ellipsoidal
% coordinates (WGS84)

% Copyright (C) 2018 Gregor Moeller
% All rights reserved.
% Email: gregor.moeller@tuwien.ac.at

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.

% format long g

% WGS84 parameter
a     = 6378137.0;
alpha = 1.0/298.257222101;
b     = a*(1-alpha);
ee = (a^2-b^2)/a^2;

% Entfernung des Punktes von der z-Achse;
r1 = sqrt(X.^2+Y.^2);

% N�herungswert f�r beta;
beta = atan(Z./r1);

% Berechnung der Hilfsgr��en;
m = b*Z./(a*r1);
n = (a^2-b^2)./(a*r1);

% Bestimmung der reduzierten Breite beta;
for i=1:5
    beta = atan(m+n.*sin(beta));
end

% Bestimmung der geod�tischen Breite phi;
phi = atan(a/b*tan(beta));

% Bestimmung der L�nge lam;
lam = atan2(Y,X);

% Querkr�mmungsradius N;
N = a./sqrt(1-ee*sin(phi).^2);

% ellipsoidische H�he H;
H = Z./sin(phi)-(1-ee)*N;

% ellipsoidische Breite und L�nge
phi = phi*180/pi;
lam = lam*180/pi;
