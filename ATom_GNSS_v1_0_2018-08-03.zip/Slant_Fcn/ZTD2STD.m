function [shd,swd,mfh,mfw,maz] = ZTD2STD(mjd,ztd,zwd,gn,ge,res,ele,azi,ell,e,T,std_i,map_i)

% Function ZTD2STD computes Slant Tropospheric Delays

% Input:
% mjd   ... Modified Julian Date
% ztd   ... Zenith Tropospheric Delay vector [mm]
% zwd   ... Zenith Wet Delay vector [mm]
% gn    ... Gradient vector in North-South direction [mm]
% ge    ... Gradient vector in East-West direction [mm]
% res   ... Zero-difference observation residuals [mm]
% ele   ... Elevation angle vector [degrees]
% azi   ... Azimuth angle [degrees]
% ell   ... Ellipsoidal station coordinates lat [degrees], lon [degrees] ,hell [m]    
% e     ... Water vapour pressure vector [hPa] for GPT2w_mod
% T     ... Temperature vector [�C] for GPT2w_mod
% std_i ... Output option
            % 1 ... isotropic STD
            % 2 ... non-isotropic STD (+Gradients)
            % 3 ... non-isotropic STD (+Gradients, +Res)
% map_i ... Mapping function id
            % 1 ... GMF
            % 2 ... GPT2w
            % 3 ... VMF1            

% Output:
% shd   ... Slant Hydrostatic Delay vector [mm]
% swd   ... Slant Wet Delay vector [mm]
% mfh   ... Hydrostatic mapping function vector [mm]
% mfw   ... Wet mapping function vector [mm]
% maz   ... Gradient mapping function vector [mm]

format long g

% Initialise variable
shd = zeros(length(ztd),1);
swd = zeros(length(ztd),1); swd0 = zeros(length(ztd),1);
mfh = zeros(length(ztd),1);
mfw = zeros(length(ztd),1);
maz = zeros(length(ztd),1);

% Load GPT2w grid
grid = 0;
if map_i == 2; grid = gpt2_1w_fast_readGrid; end

% Load VMF1 coefficients
a = zeros(length(ztd),2);
if map_i == 3    
    [ah,aw] = read_vmf1_grid(mjd,ell);
    a = [ah,aw];
end

% Check zwd vector
if unique(zwd) == 0, no_zwd = 1; else no_zwd = 0; end
        
switch std_i
    case 1
        % Zenith distance [rad]
        zd = (90 - ele(1))/180*pi;  
        % Start loop
        for j = 1:length(ztd)
            % Mapping factors [mfh,mfw]
            [mfh(j),mfw(j)] = cal_mf(mjd(j),ell,zd,grid,a(j,:),e(j),T(j),map_i);
            % Hydrostatic delay (ZHD) using gpt
            if no_zwd == 1
                [pres,~,~]  = gpt(mjd(j),ell(1)/180*pi,ell(2)/180*pi,ell(3));
                [zhd]       = saasthyd(pres,ell(1)/180*pi,ell(3))*1000;
            else
                zhd = ztd(j)-zwd(j);
            end
            % isotropic slant tropospheric delays (shd,swd)
            shd(j) = zhd*mfh(j);
            swd(j) = (ztd(j)-zhd)*mfw(j);
        end            
    case 2
        % Zenith distance
        zd = (90 - ele(1))/180*pi;  
        % Start loop
        for j = 1:length(ztd)
            % Mapping factors [mfh,mfw]
            [mfh(j),mfw(j)] = cal_mf(mjd(j),ell,zd,grid,a(j,:),e(j),T(j),map_i);
            % Hydrostatic delay (ZHD) using gpt           
            if no_zwd == 1
                [pres,~,~]  = gpt(mjd(j),ell(1)/180*pi,ell(2)/180*pi,ell(3));
                [zhd]       = saasthyd(pres,ell(1)/180*pi,ell(3))*1000;
            else
                zhd = ztd(j)-zwd(j);
            end
            % isotropic slant tropospheric delays (shd,swd)
            shd(j)  = zhd*mfh(j);
            swd0(j) = (ztd(j)-zhd)*mfw(j);
            % Compute Slant delays with gradients (Chen & Herring 1997) [mm]
            maz(j)  = 1/(sin(pi/2-zd)*tan(pi/2-zd)+0.0032);
            swd(j)  = swd0(j) + ge(j)*maz(j)*sind(azi) + gn(j)*maz(j)*cosd(azi);
        end
    case 3       
        % Start loop
        for i = 1:length(ztd)
            % Zenith distance
            zd = (90 - ele(i))/180*pi;
            % Mapping factors [mfh,mfw]
            [mfh(i),mfw(i)] = cal_mf(mjd(i),ell,zd,grid,a(i,:),e(i),T(i),map_i);
            % Hydrostatic delay (ZHD) using gpt            
            if no_zwd == 1
                [pres,~,~]  = gpt(mjd(i),ell(1)/180*pi,ell(2)/180*pi,ell(3));
                [zhd]       = saasthyd(pres,ell(1)/180*pi,ell(3))*1000;
            else
                zhd = ztd(i)-zwd(i);
            end
            % isotropic slant delays (shd,swd0)
            shd(i)  = zhd*mfh(i);
            swd0(i) = (ztd(i)-zhd)*mfw(i);
            %shd(i)  = ztd(i)*mfh(i);
            %swd0(i) = 0;
            % Compute SWD with gradients (Chen & Herring 1997) [mm] and residuals [mm]
            maz(i)  = 1/(sin(pi/2-zd)*tan(pi/2-zd)+0.0032);
            swd(i)  = swd0(i) + ge(i)*maz(i)*sind(azi(i)) + gn(i)*maz(i)*cosd(azi(i)) + res(i);
        end
end