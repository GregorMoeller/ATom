function [shd,swd,mfh,mfw,maz] = ZWD2SWD(mjd,zwd,gn,ge,res,ele,azi,ell,e,T,swd_i,map_i)

% Function ZWD2SWD computes Slant Wet Delays

% Copyright (C) 2018 Gregor Moeller
% All rights reserved.
% Email: gregor.moeller@tuwien.ac.at

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.

% Input:
% mjd   ... Modified Julian Date
% zwd   ... Zenith Wet Delay vector [mm]
% gn    ... Gradient vector in North-South direction [mm]
% ge    ... Gradient vector in East-West direction [mm]
% res   ... Zero-difference observation residuals [mm]
% ele   ... Elevation angle vector [degrees]
% azi   ... Azimuth angle [degrees]
% ell   ... ellipsoidal station coordinates lat [degrees], lon [degrees] ,hell [m]      
% e     ... Water vapour pressure [hPa] for GPT2w_mod
% T     ... Temperature [�C] for GPT2w_mod
% swd_i ... Output option
            % 1 ... isotropic SWD
            % 2 ... non-isotropic SWD (+Gradients)
            % 3 ... non-isotropic SWD (+Gradients, +Res)
% map_i ... Mapping function id
            % 1 ... GMF
            % 2 ... GPT2w
            % 3 ... VMF1            

% Output:
% shd   ... Slant Hydrostatic Delay vector [mm]
% swd   ... Slant Wet Delay vector [mm]
% mfh   ... Hydrostatic mapping function vector [mm]
% mfw   ... Wet mapping function vector [mm]
% maz   ... Gradient mapping function vector [mm]

format long g

% Initialise variable
shd = zeros(length(zwd),1);
swd = zeros(length(zwd),1); swd0 = zeros(length(zwd),1);
mfh = zeros(length(zwd),1);
mfw = zeros(length(zwd),1);
maz = zeros(length(zwd),1);

% Load GPT2w grid
grid = 0;
if map_i == 2; grid = gpt2_1w_fast_readGrid; end

% Load VMF1 coefficients
a = zeros(length(zwd),2);
if map_i == 3    
    [ah,aw] = read_vmf1_grid(mjd,ell);
    a = [ah,aw];
end
   
switch swd_i
    case 1
        % Zenith distance [rad]
        zd = (90 - ele(1))/180*pi;  
        % Initialise variable
        swd = zeros(length(zwd),1);
        % Start loop
        for j = 1:length(zwd)
            % Mapping factor mfw
            [~,mfw(j)] = cal_mf(mjd(j),ell,zd,grid,a(j,:),e(j),T(j),map_i);
            % isotropic slant wet delay (swd)
            swd(j) = zwd(j)*mfw(j);
        end            
    case 2
        % Zenith distance
        zd = (90 - ele(1))/180*pi;  
        % Initialise variable
        swd0 = zeros(length(zwd),1); swd = zeros(length(zwd),1);
        % Start loop
        for j = 1:length(zwd)
            % Mapping factor mfw
            [~,mfw(j)] = cal_mf(mjd(j),ell,zd,grid,a(j,:),e(j),T(j),map_i);
            % isotropic slant wet delay (swd)
            swd0(j) = zwd(j)*mfw(j);
            % Compute SWD with gradients (Chen & Herring 1997) [mm]
            maz(j) = 1/(sin(pi/2-zd)*tan(pi/2-zd)+0.0032);
            swd(j) = (swd0(j) + ge(j)*maz(j)*sind(azi) + gn(j)*maz(j)*cosd(azi));
        end
    case 3      
        % Start loop
        for i = 1:length(zwd)
            % Zenith distance
            zd = (90 - ele(i))/180*pi;
            % Mapping factor gmfw
            [~,mfw(i)] = cal_mf(mjd(i),ell,zd,grid,a(i,:),e(i),T(i),map_i);
            % isotropic slant wet delay (swd)
            swd0(i) = zwd(i)*mfw(i);
            % Compute SWD with gradients (Chen & Herring 1997) [mm] and residuals [mm]
            maz(i) = 1/(sin(pi/2-zd)*tan(pi/2-zd)+0.0032);
            swd(i) = swd0(i) + ge(i)*maz(i)*sind(azi(i)) + gn(i)*maz(i)*cosd(azi(i)) + res(i);
        end
end