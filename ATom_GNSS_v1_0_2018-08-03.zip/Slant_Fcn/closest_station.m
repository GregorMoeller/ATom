function [name,dh,dist] = closest_station(ell1,sta2,ell2,hmax,dmax)

% Function closest_station() computes the coordinate differences between 
% two stations and returns the name of the closest + the distances

% Copyright (C) 2018 Gregor Moeller
% All rights reserved.
% Email: gregor.moeller@tuwien.ac.at

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.

% Input:
% sta1  ... station name (reference)
% ell1  ... ellipsoidal coordinates of the reference station (vector of lat,lon,h)
% sta2  ... list of station names (slave)
% ell2  ... ellipsoidal coordinates of slave stations (matrix of lat,lon,h)

% Output:
% name  ... station name of the closest station
% dh    ... height difference [m]
% dist  ... 2D distance [km]

% Compute distances
for i = 1:length(sta2)
    % 2D distance dist
    dist0(i) = sqrt((abs(ell1(1)-ell2(i,1))*111.195)^2+...
        (abs(ell1(2)-ell2(i,2))*111.195*cosd((ell1(1)+ell2(i,1))/2))^2);
    % Height difference dh
    dh0(i) = ell1(3) - ell2(i,3);
    %fprintf('%s %s %6.1f %6.1f %6.1f %6.1f\n',sta1{:},sta2{i},dist0(i),dh0(i),ell1(3),ell2(i,3))
end

% Find stations within the range and select station with smallest station
% distance (if more than one)
id_h = find(abs(dh0) < hmax);
if ~isempty(id_h)
    id_dist = find(dist0(id_h) < dmax);
    [~,id] = min(dist0(id_h(id_dist)));
    if ~isempty(id)
        dh   = dh0(id_h(id_dist(id)));
        dist = dist0(id_h(id_dist(id)));
        name = sta2{id_h(id_dist(id))};
    else
        name = 'xxxxx';
        dh   = 999.9;
        dist = 999.9;                
    end    
else
    name = 'xxxxx';
    dh   = 999.9;
    dist = 999.9;     
end

% % Find stations within the range and select station with smallest height
% % difference (if more than one)
% id_dist = find(dist0 < dmax);
% if ~isempty(id_dist)
%     id_h   = find(abs(dh0(id_dist)) < hmax);
%     [~,id] = min(abs(dh0(id_dist(id_h))));
%     if ~isempty(id)
%         dh   = dh0(id_dist(id_h(id)));
%         dist = dist0(id_dist(id_h(id)));
%         name = sta2{id_dist(id_h(id))};
%     else
%         name = 'xxxxx';
%         dh   = 999.9;
%         dist = 999.9;                
%     end    
% else
%     name = 'xxxxx';
%     dh   = 999.9;
%     dist = 999.9;     
% end

%fprintf('%s %s %6.1f %6.1f\n',sta1{:},name,dist,dh)