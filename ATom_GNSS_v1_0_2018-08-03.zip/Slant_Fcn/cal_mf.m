function [mfh,mfw] = cal_mf(mjd,ell,zd,grid,a,e,T,map_i)

% Function cal_mf computes hydrostatic and wet mapping factors

% Copyright (C) 2018 Gregor Moeller
% All rights reserved.
% Email: gregor.moeller@tuwien.ac.at

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.

% Input:
% mjd   ... Modified Julian Date
% ell   ... ellipsoidal station coordinates lat [degrees], lon [degrees] ,hell [m] 
% zd    ... zenith distance [rad]
% grid  ... climatological grid for GPT2w
% a     ... hydrostatic and wet coefficient [ah,aw] for VMF1
% e     ... water vapour pressure [hPa] for GPT2w_mod
% T     ... temperature [�C] for GPT2w_mod
% map_i ... mapping function
            % 1 ... GMF
            % 2 ... GPT2w
            % 3 ... VMF1
            % 4 ... GPT2w_mod

% Output:
% mfh  ... hydrostatic mapping factors
% mfw  ... wet mapping factors

format long g

switch map_i
    case 1
        [mfh,mfw] = gmf(mjd,ell(1)/180*pi,ell(2)/180*pi,ell(3),zd);
    case 2
        [~,~,~,~,~,ah,aw,~,~] = gpt2_1w_fast(mjd,ell(1)/180*pi,ell(2)/180*pi,ell(3),1,0,grid);                    
        [mfh,mfw] = vmf1_ht(ah,aw,mjd,ell(1)/180*pi,ell(3),zd);                     
    case 3        
        [mfh,mfw] = vmf1_ht(a(1),a(2),mjd,ell(1)/180*pi,ell(3),zd);
%     case 4
%         [~,T_GPT2w,~,~,~,ah,aw,~,~] = gpt2_1w_fast(mjd,ell(1)/180*pi,ell(2)/180*pi,ell(3),1,0,grid);
%         ah_MOD = ah + 1.3*10^(-6)*(T-T_GPT2w);
%         [mfh,mfw] = vmf1_ht(ah_MOD,aw,mjd,ell(1)/180*pi,ell(3),zd);          
end