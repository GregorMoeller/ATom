function varargout = ATom(varargin)

% Last Modified by GUIDE v2.5 02-Aug-2018 12:00:52

%% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ATom_OpeningFcn, ...
                   'gui_OutputFcn',  @ATom_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

% Remove warnings
warning('off','MATLAB:hg:uicontrol:ParameterValuesMustBeValid')

% Add folder to MATLAB search path:
% folder = which('ATom.m');
% addpath(genpath(folder(1:end-6)));

% End initialization code - DO NOT EDIT

%% ---------------------------- ATOM program settings ---------------------
% -------------------------------------------------------------------------
function ATom_OpeningFcn(hObject, ~, handles, varargin)
% Choose default command line output for ATom
handles.output = hObject;

% Set all panels invisible except atom_start
set(handles.uipanel_atom_start,'Visible','on');
set(handles.uipanel_zhd,'Visible','off');
set(handles.uipanel_convert_brdc,'Visible','off');
set(handles.uipanel_std,'Visible','off');
set(handles.uipanel_N_apr,'Visible','off');
set(handles.uipanel_N_new,'Visible','off');

% Plot start image
axes(handles.atom_start_axes1);
x = imread('atom_start.jpg');
imshow(x);

% UIWAIT makes ATom wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% Initialise path variables
handles.atom_start_input  = pwd;
handles.atom_start_output = [pwd '\Data'];
set(handles.atom_start_input_com ,'String',handles.atom_start_input);
set(handles.atom_start_output_com,'String',handles.atom_start_output);

% Update handles structure
guidata(hObject, handles);

% --- Outputs from this function are returned to the command line.
function varargout = ATom_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;

% Function to delete entries in listbox
function [] = key_check(varargin)
if strcmp(varargin{2}.Key,'delete')
    var = get(varargin{1},'Value');
    str = get(varargin{1},'String');
    if length(str) > 1
        str(var) = [];
        if isempty(str) == 1
            str = {'No file'};
        end
        set(varargin{1},'String',str,'Value',1);
    elseif length(str) == 1
        set(varargin{1},'String',{'No file'});
    end
end


%% ---------------------------- Menu settings -----------------------------
% -------------------------------------------------------------------------
function start_menu_Callback(hObject, eventdata, handles)
% Set all panels invisible
atom_panels_invisible(hObject, eventdata, handles)
% Make only uipanel_convert_res visible
set(handles.uipanel_atom_start,'Visible','on');

function convert_menu_Callback(hObject, eventdata, handles)
function convert_zhd_Callback(hObject, eventdata, handles)
% Set all panels invisible
atom_panels_invisible(hObject, eventdata, handles)
% Make only uipanel_convert_res visible
set(handles.uipanel_zhd,'Visible','on');

function convert_brdc_Callback(hObject, eventdata, handles)
% Set all panels invisible
atom_panels_invisible(hObject, eventdata, handles)
% Make only uipanel_convert_brdc visible
set(handles.uipanel_convert_brdc,'Visible','on');

function slant_menu_Callback(hObject, eventdata, handles)
function std_Callback(hObject, eventdata, handles)
% Set all panels invisible
atom_panels_invisible(hObject, eventdata, handles)
% Make only uipanel_std visible
set(handles.uipanel_std,'Visible','on');

function N_menu_Callback(hObject, eventdata, handles)
function N_apr_Callback(hObject, eventdata, handles)
% Set all panels invisible
atom_panels_invisible(hObject, eventdata, handles)
% Make only uipanel_convert_res visible
set(handles.uipanel_N_apr,'Visible','on');  

function N_new_Callback(hObject, eventdata, handles)
% Set all panels invisible
atom_panels_invisible(hObject, eventdata, handles)
% Make only uipanel_convert_res visible
set(handles.uipanel_N_new,'Visible','on');

function atom_panels_invisible(hObject, eventdata, handles)
set(handles.uipanel_atom_start,'Visible','off');
set(handles.uipanel_zhd,'Visible','off');
set(handles.uipanel_convert_brdc,'Visible','off');
set(handles.uipanel_std,'Visible','off');
set(handles.uipanel_N_apr,'Visible','off');
set(handles.uipanel_N_new,'Visible','off');


%% ----------------------- Panel Start ------------------------------------
% -------------------------------------------------------------------------
function uipanel_atom_start_CreateFcn(hObject, eventdata, handles)

function atom_start_axes1_CreateFcn(hObject, eventdata, handles)

% ---------------------------- Input folder -------------------------------
function atom_start_input_com_Callback(hObject, eventdata, handles)
handles.atom_start_input = get(hObject,'String');
guidata(hObject, handles);

function atom_start_input_com_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(handles.convert_brdc_output_com)
guidata(hObject, handles);

function atom_start_input_com_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ----------------------------Output folder -------------------------------
function atom_start_output_com_Callback(hObject, eventdata, handles)
handles.atom_start_output = get(hObject,'String');
guidata(hObject, handles);

function atom_start_output_com_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(handles.convert_brdc_output_com)
guidata(hObject, handles);

function atom_start_output_com_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ---------------------------- Load settings ------------------------------
function atom_start_load_settings_Callback(hObject, eventdata, handles)
% Read file names
[filename, pathname] = uigetfile({...
    '*.atom','ATom program settings'},...
    'Select File',handles.atom_start_input,'MultiSelect','on');
% Load settings
if ~isequal(filename,0)
    loadATomParamFile([pathname filename],handles)
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor','red');
end

% ---------------------------- Save settings ------------------------------
function atom_start_save_settings_Callback(hObject, eventdata, handles)
% Read file names
[filename, pathname] = uiputfile('.atom','Save ATom program settings');
% Save settings
if ~isequal(filename,0)
    saveATomParamFile([pathname filename],handles)
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor','red');
end


%% ---------------------------- Panel Convert -----------------------------
% ----------------------------- Sub-panel ZTD to ZWD ----------------------
% -------------------------------------------------------------------------
function uipanel_zhd_CreateFcn(hObject, eventdata, handles)

% ------------------------------ ZTDs (Input 1) --------------------------
function zhd_input1_open_Callback(hObject, eventdata, handles)
% Read file names
[filename1, handles.zhd_input1_pathname1] = uigetfile({...
    '*zpd','IGS SINEX Tropo files';...
    '*TRP','Bernese Tropo files';...
    '*SNX','SINEX Tropo New files';...
    '*TRO','NAPEOS SINEX Tropo files'},...
    'Select File',handles.atom_start_input,'MultiSelect','on');
% Pass file names to listbox
if isequal(filename1,0)
    set(handles.zhd_input1_list,'String',{'No file'});
    set(handles.zhd_input1_list,'Value',1)
else    
    set(handles.zhd_input1_list,'String',cellstr(filename1));
    set(handles.zhd_input1_list,'Value',1)
end
guidata(hObject, handles);

function zhd_input1_list_Callback(hObject, eventdata, handles)
% Set the limit of files which can be selected
set(hObject,'min',0,'max',1000);
% Use 'Entf to delete entries in listbox
set(hObject,'keypressfcn',@key_check)
guidata(hObject, handles);

function zhd_input1_list_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function zhd_input1_load_Callback(hObject, eventdata, handles)
% Read file names in listbox
str = get(handles.zhd_input1_list,'String');
val = get(handles.zhd_input1_list,'Value');
% Check if files exist
if strcmp(str,'No file') ~= 1
    % Initialise variables
    handles.zhd_input1_data = [];
    handles.zhd_input1_cont = [];
    handles.zhd_input1_sta_full = {};
    % Create waitbar
    h = waitbar(0,'Please wait...','WindowStyle','modal');
    % Loop to read each input file
    for i = 1:length(val)
        % Fill wait bar
        waitbar(i/length(val),h);
        % Path name
        fullpathname = strcat(handles.zhd_input1_pathname1,str{val(i)});
        if strcmp(fullpathname(end-3:end),'.TRP')
            % Read troposphere estimates (Bernese files)
            [dat1,dat2] = read_TRP(fullpathname);
            % Concatinate cell arrays
            handles.zhd_input1_data = [handles.zhd_input1_data;dat1{2:end}];        
            handles.zhd_input1_cont = dat2(2:end); 
            handles.zhd_input1_sta_full = [handles.zhd_input1_sta_full;dat1{1}];
        elseif strcmp(fullpathname(end-3:end),'.SNX')
            % Read troposphere estimates (New SINEX)
            [dat1,dat2] = read_SINEX_SNX(fullpathname,'trp',handles);  
            % Concatinate cell arrays
            handles.zhd_input1_data = [handles.zhd_input1_data;dat1{2:end}];        
            handles.zhd_input1_cont = dat2(2:end); 
            handles.zhd_input1_sta_full = [handles.zhd_input1_sta_full;dat1{1}];            
        else
            % Read troposphere estimates (SINEX)
            [dat1,dat2] = read_SINEX_TRO(fullpathname,'trp',handles);  
            % Concatinate cell arrays
            handles.zhd_input1_data = [handles.zhd_input1_data;dat1{2:end}];        
            handles.zhd_input1_cont = dat2(2:end); 
            handles.zhd_input1_sta_full = [handles.zhd_input1_sta_full;dat1{1}];
        end
    end
    % Comput start/end epoch of dataset and set panels
    [yr1,doy1,sod1] = mjd2doy(min(handles.zhd_input1_data(:,1)));
    [yr2,doy2,sod2] = mjd2doy(max(handles.zhd_input1_data(:,1)));
    set(handles.zhd_epoch1_year,'String',sprintf('%4.4d',yr1));
    set(handles.zhd_epoch1_doy,'String',sprintf('%3.3d',doy1));
    set(handles.zhd_epoch1_sod,'String',sprintf('%d',sod1));
    set(handles.zhd_epoch2_year,'String',sprintf('%4.4d',yr2));
    set(handles.zhd_epoch2_doy,'String',sprintf('%3.3d',doy2));
    set(handles.zhd_epoch2_sod,'String',sprintf('%d',sod2));    
    % Set sampling rate
    dt = round((handles.zhd_input1_data(2,1)-handles.zhd_input1_data(1,1))*86400);
    set(handles.zhd_rate_edit,'String',dt)    
    % List of stations
    set(handles.zhd_station_list1,'Value',1);
    set(handles.zhd_station_list1,'String',unique(handles.zhd_input1_sta_full));
    % Output file name
    set(handles.zhd_output_com,'String',[handles.atom_start_output '\' strtok(str{val(1)},'.') '.ZWD']);    
    % Clear crd list
    set(handles.zhd_input3_list,'String','');    
    % Status text
    set(handles.zhd_status_text,'String','ZTD loaded, select station(s)');  
    % Close watibar
    close(h);
end
guidata(hObject, handles);  

% ---------------------- Select GNSS station -----------------------------
function zhd_station_list1_Callback(hObject, eventdata, handles)
% Set the limit of files which can be selected
set(hObject,'min',0,'max',300);
guidata(hObject, handles);

function zhd_station_list1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --------------------------- Site crd (Input 3) -------------------------
function zhd_input3_open_Callback(hObject, eventdata, handles)
% Read file names
[filename1, handles.zhd_input3_pathname1] = uigetfile({...
    '*.NEU','NEU coordinate file'},...   
    'Select File',handles.atom_start_input,'MultiSelect','on');
% Pass file names to listbox
if isequal(filename1,0)
    set(handles.zhd_input3_filename,'String',{'No file'});
else
    set(handles.zhd_input3_filename,'String',cellstr(filename1));
    set(handles.zhd_status_text,'String','Load CRD file');
end
guidata(hObject, handles);

function zhd_input3_load_Callback(hObject, eventdata, handles)
% Read filename
str = get(handles.zhd_input3_filename,'String');
if strcmp(str,'No file') ~= 1
    % Read stations
    str1 = get(handles.zhd_station_list1,'String');
    val1 = get(handles.zhd_station_list1,'Value');
    % If at least 1 file exist and at leas 1 baseline is selected
    if isequal(str,'No file') ~= 1 && isequal(str1,'No station') ~= 1
        % Clear list
        set(handles.zhd_input3_list,'String','');
        % Set path name of coordinate file   
        fullpathname = strcat(handles.zhd_input3_pathname1,str{1});
        % Create statlist
        statlist = cellstr(str1(val1));
        % Read coordinates from file
        [dat1,dat2] = read_NEU(fullpathname,statlist,handles);
        handles.zhd_input3_crd = dat1;
        id = find(dat1 == 0,1);
        if ~isempty(id)
            set(handles.zhd_status_text,'String',[statlist{id},' not found! Please select CRD file with coordinates for all stations'])
        else
            set(handles.zhd_input3_list,'String',dat2);
            set(handles.zhd_status_text,'String','CRD loaded for selected GNSS stations');
            set(handles.zhd_input3_list,'Value',[]);
        end 
    else
       set(handles.zhd_status_text,'String','No file or no station selected')
    end
    guidata(hObject, handles);
end

function zhd_input3_list_Callback(hObject, eventdata, handles)
% Set the limit of files which can be selected
set(hObject,'min',0,'max',1);
% Use 'Entf to delete entries in listbox
set(hObject,'keypressfcn',@key_check)
guidata(hObject, handles);

function zhd_input3_list_CreateFcn(hObject, eventdata, handles)
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end

% ---------------------------- Epoch panel -------------------------------
% ---------------------------- Start epoch -------------------------------
function zhd_epoch1_year_Callback(hObject, eventdata, handles)

function zhd_epoch1_year_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function zhd_epoch1_doy_Callback(hObject, eventdata, handles)

function zhd_epoch1_doy_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function zhd_epoch1_sod_Callback(hObject, eventdata, handles)

function zhd_epoch1_sod_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ---------------------------- Last epoch --------------------------------
function zhd_epoch2_year_Callback(hObject, eventdata, handles)

function zhd_epoch2_year_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function zhd_epoch2_doy_Callback(hObject, eventdata, handles)

function zhd_epoch2_doy_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function zhd_epoch2_sod_Callback(hObject, eventdata, handles)

function zhd_epoch2_sod_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --------------------------- Data rate ----------------------------------
function zhd_rate_edit_Callback(hObject, eventdata, handles)

function zhd_rate_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function zhd_rate_edit_ButtonDownFcn(hObject, eventdata, handles)
val = get(handles.zhd_thinout_check,'Value');
if val == 0
    set(hObject,'Enable','On')
    uicontrol(handles.zhd_rate_edit)
    set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
    guidata(hObject, handles);
end

% ------------------------ Output file name ------------------------------
function zhd_output_com_Callback(hObject, eventdata, handles)

function zhd_output_com_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function zhd_output_com_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(handles.zhd_output_com)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

% --------------------------- Meteo data source --------------------------
function zhd_meteo_popup_Callback(hObject, eventdata, handles)
val = get(handles.zhd_meteo_popup,'Value');
if val == 1
    set(handles.zhd_dmax_edit,'Enable','Off');
    set(handles.zhd_hmax_edit,'Enable','Off');
    set(handles.zhd_extrap_popup,'Enable','Off');
    set(handles.zhd_input2_open,'Enable','Off');
    set(handles.zhd_input2_load,'Enable','Off');
    set(handles.zhd_input2_list,'Enable','Off');
    set(handles.zhd_station_list2,'Enable','Off');
    set(handles.zhd_input4_open,'Enable','Off');
    set(handles.zhd_input4_load,'Enable','Off');
    set(handles.zhd_input4_list,'Enable','Off');
elseif val == 2
    set(handles.zhd_dmax_edit,'Enable','Off');
    set(handles.zhd_hmax_edit,'Enable','Off');
    set(handles.zhd_extrap_popup,'Enable','Off');
    set(handles.zhd_input2_open,'Enable','Off');
    set(handles.zhd_input2_load,'Enable','Off');
    set(handles.zhd_input2_list,'Enable','Off');
    set(handles.zhd_station_list2,'Enable','Off');
    set(handles.zhd_input4_open,'Enable','Off');
    set(handles.zhd_input4_load,'Enable','Off');
    set(handles.zhd_input4_list,'Enable','Off');
elseif val == 3
    set(handles.zhd_dmax_edit,'Enable','Inactive');
    set(handles.zhd_hmax_edit,'Enable','Inactive');
    set(handles.zhd_extrap_popup,'Enable','On');
    set(handles.zhd_input2_open,'Enable','On');
    set(handles.zhd_input2_load,'Enable','On');
    set(handles.zhd_input2_list,'Enable','On');
    set(handles.zhd_station_list2,'Enable','On');
    set(handles.zhd_input4_open,'Enable','On');
    set(handles.zhd_input4_load,'Enable','On');
    set(handles.zhd_input4_list,'Enable','Inactive');
end

function zhd_meteo_popup_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --------------------------- In-situ data (Input 2) ----------------------
function zhd_input2_open_Callback(hObject, eventdata, handles)
% Read file names
[filename1, handles.zhd_input2_pathname1] = uigetfile({...
    '*dat','TAWES files';...
    '*syn','COST files'},...
    'Select File',handles.atom_start_input,'MultiSelect','on');
% Pass file names to listbox
if isequal(filename1,0)
    set(handles.zhd_input2_list,'String',{'No file'});
    set(handles.zhd_input2_list,'Value',1)
else    
    set(handles.zhd_input2_list,'String',cellstr(filename1));
    set(handles.zhd_input2_list,'Value',1)
end
guidata(hObject, handles);

function zhd_input2_list_Callback(hObject, eventdata, handles)
% Set the limit of files which can be selected
set(hObject,'min',0,'max',1000);
% Use 'Entf to delete entries in listbox
set(hObject,'keypressfcn',@key_check)
guidata(hObject, handles);

function zhd_input2_list_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function zhd_input2_load_Callback(hObject, eventdata, handles)
% Read file names in listbox
str = get(handles.zhd_input2_list,'String');
val = get(handles.zhd_input2_list,'Value');
% Check if files exist
if strcmp(str,'No file') ~= 1
    % Initialise variables
    handles.zhd_input2_data = [];
    handles.zhd_input2_cont = [];
    handles.zhd_input2_sta_full = {};
    % Create waitbar
    h = waitbar(0,'Please wait...','WindowStyle','modal');
    % Loop to read each input file
    for i = 1:length(val)
        % Fill wait bar
        waitbar(i/length(val),h);
        % Path name
        fullpathname = strcat(handles.zhd_input2_pathname1,str{val(i)});
        if strcmp(fullpathname(end-3:end),'.dat')
            % Read TAWES data
            [dat1,dat2,dat3] = read_TAWES(fullpathname);
        else
            % Read COST data
            [dat1,dat2,dat3] = read_SYNOP(fullpathname);            
        end
        % Concatinate cell arrays
        handles.zhd_input2_data = [handles.zhd_input2_data;dat1'];        
        handles.zhd_input2_cont = dat2; 
        handles.zhd_input2_sta_full = [handles.zhd_input2_sta_full;dat3];
    end
    close(h);
%     % Compute start/end epoch of dataset and set panels
%     [yr1,doy1,sod1] = mjd2doy(min(handles.zhd.input1_data(:,1)));
%     [yr2,doy2,sod2] = mjd2doy(max(handles.zhd.input1_data(:,1)));
    % List of stations
    set(handles.zhd_station_list2,'Value',1);
    set(handles.zhd_station_list2,'String',unique(handles.zhd_input2_sta_full));
    % Clear crd list
    set(handles.zhd_input4_list,'String','');
    % Status text
    set(handles.zhd_status_text,'String','In-situ loaded, select station coordinates');
end
guidata(hObject, handles);

% ---------------------- Select In-situ station --------------------------
function zhd_station_list2_Callback(hObject, eventdata, handles)
% Set the limit of files which can be selected
set(hObject,'min',0,'max',300);
guidata(hObject, handles);

function zhd_station_list2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --------------------------- In-situ site crd (Input 4) ------------------
function zhd_input4_open_Callback(hObject, eventdata, handles)
% Read file names
[filename1, handles.zhd_input4_pathname1] = uigetfile({...
    '*.NEU','NEU coordinate file';...    
    '*.CRD','XYZ coordinate file'},...
    'Select File',handles.atom_start_input,'MultiSelect','on');
% Pass file names to listbox
if isequal(filename1,0)
    set(handles.zhd_input4_filename,'String',{'No file'});
else
    set(handles.zhd_input4_filename,'String',cellstr(filename1));
    set(handles.zhd_status_text,'String','Load CRD file');
end
guidata(hObject, handles);

function zhd_input4_load_Callback(hObject, eventdata, handles)
% Read filename
str = get(handles.zhd_input4_filename,'String');
if strcmp(str,'No file') ~= 1
    % Read stations
    str1 = get(handles.zhd_station_list2,'String');
    val1 = get(handles.zhd_station_list2,'Value');
    % If at least 1 file exist and at leas 1 baseline is selected
    if isequal(str,'No file') ~= 1 && isequal(str1,'No station') ~= 1
        % Clear list
        set(handles.zhd_input4_list,'String','');
        % Set path name of coordinate file   
        fullpathname = strcat(handles.zhd_input4_pathname1,str{1});
        % Create statlist
        statlist = cellstr(str1(val1));
        % Read coordinates from file
        [dat1,dat2] = read_NEU(fullpathname,statlist,handles);
        handles.zhd_input4_crd = dat1;
        id = find(dat1(:,2) == 0,1);
        if ~isempty(id)
            set(handles.zhd_status_text,'String',[statlist{id},' not found! Please select CRD file with coordinates for all stations'])
        else
            set(handles.zhd_input4_list,'String',dat2);
            set(handles.zhd_status_text,'String','CRD loaded for selected in-situ stations');
            set(handles.zhd_input4_list,'Value',[]);
        end 
    else
       set(handles.zhd_status_text,'String','No file or no station selected')
    end
    guidata(hObject, handles);
end

function zhd_input4_list_Callback(hObject, eventdata, handles)
% Set the limit of files which can be selected
set(hObject,'min',0,'max',1000);
% Use 'Entf to delete entries in listbox
set(hObject,'keypressfcn',@key_check)
guidata(hObject, handles);

function zhd_input4_list_CreateFcn(hObject, eventdata, handles)
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end

% ---------------------------- Height correction -------------------------
function zhd_extrap_popup_Callback(hObject, eventdata, handles)

function zhd_extrap_popup_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ---------------------------- dmax (in-situ/GNSS) ------------------------
function zhd_dmax_edit_Callback(hObject, eventdata, handles)

function zhd_dmax_edit_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function zhd_hmax_edit_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(handles.zhd_dmax_edit)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

% ---------------------------- Hmax (in-situ/GNSS) ------------------------
function zhd_hmax_edit_Callback(hObject, eventdata, handles)

function zhd_hmax_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function zhd_dmax_edit_ButtonDownFcn(hObject, eventdata, handles)
%set(hObject,'Enable','On')
uicontrol(handles.zhd_dmax_edit)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

% ---------------------------- Thin out option ---------------------------
function zhd_thinout_check_Callback(hObject, eventdata, handles)
val = get(handles.zhd_thinout_check,'Value');
if val == 0
    set(handles.zhd_rate_edit,'Enable','Inactive');
else
    set(handles.zhd_rate_edit,'Enable','Off');
end

% ---------------------------- Outlier option ---------------------------
function zhd_outliers_check_Callback(hObject, eventdata, handles)

% --------------------------- Compute ZHD --------------------------------
function zhd_start_Callback(hObject, eventdata, handles)
check_in = 1;
error_id = 0;
% GNSS station selected?
sta  = get(handles.zhd_station_list1,'String');
nsta = get(handles.zhd_station_list1,'Value');
if isequal(sta,'No station'); check_in = 0; end
if check_in == 0; set(handles.zhd_status_text,'String','Error, no GNSS station selected!'); return; end 
% Coordinates available?
str = get(handles.zhd_input3_list,'String');
if isequal(str,''); check_in = 0; end
if check_in == 0; set(handles.zhd_status_text,'String','Error, load GNSS coordinates!'); return; end 
% Create waitbar
h = waitbar(0,'Please wait...','WindowStyle','modal');
% Read output file name    
fout = get(handles.zhd_output_com,'String');  
out  = fopen(fout,'w');
set(handles.zhd_output_com,'BackgroundColor',[1 1 1],'Enable','Inactive');
% Check meteo data source (GPT, GPT2w, in-situ)
meteo_opt = get(handles.zhd_meteo_popup,'String');
var = get(handles.zhd_meteo_popup,'Value');
% Read data rate
rate = str2double(get(handles.zhd_rate_edit,'String'));
if ~isnan(rate); set(handles.zhd_rate_edit,'BackgroundColor',[1 1 1]); end
% Define output epochs (mjd) according to rate
mjd_all = round(handles.zhd_input1_data(:,1).*86400./rate);
mjd = min(mjd_all)./86400*rate:rate/86400:max(mjd_all)./86400*rate;
% Clear list of pairs
set(handles.zhd_pair_headline,'String','');
set(handles.zhd_pair_list,'String','');
% GNSS outlier test
if get(handles.zhd_outliers_check,'Value') == 1
    % Find entries
    id = find(strcmp(handles.zhd_input1_cont,'StdDev [mm]'),1);
    % Find ZTD formal errors > 10 mm
    rec_ztdo = find(handles.zhd_input1_data(:,id) > 10);
    % Combine all records
    rec_outl = unique(rec_ztdo);
    % Delete GNSS outliers
    handles.zhd_input1_data(rec_outl,:) = [];
    handles.zhd_input1_sta_full(rec_outl,:) = [];
end
% Compute time series
switch meteo_opt{var}
    case 'GPT'
        for i = 1:length(nsta)
            waitbar(i/length(nsta),h);
            % Station coordinates (lat,lon,h)
            ell  = handles.zhd_input3_crd(i,:);
            % Get station record (from SINEX_TRO)
            stat = handles.zhd_input1_sta_full;
            % Select records for the station of interest
            rec  = strcmp(stat,sta(nsta(i)));
            % Get data from SINEX_TRO (mjd, ztd)
            mjd0 = handles.zhd_input1_data(rec,1);               
            ztd0 = handles.zhd_input1_data(rec,2);
            % Check number of entries > 1
            if isempty(ztd0); continue; end     
            % Remove double entries
            [~,ind] = unique(mjd0); mjd0 = mjd0(ind); ztd0 = ztd0(ind);
            % Get north-gradients
            gn_i = strcmp(handles.zhd_input1_cont,'N-Gradient [mm]');
            if any(gn_i) == 1
                gn0 = handles.zhd_input1_data(rec,gn_i);
                gn0 = gn0(ind);
            else
                gn0 = zeros(length(ztd0),1);
            end
            % Get east-gradients
            ge_i = strcmp(handles.zhd_input1_cont,'E-Gradient [mm]');
            if any(ge_i) == 1
                ge0 = handles.zhd_input1_data(rec,ge_i);
                ge0 = ge0(ind);
            else
                ge0 = zeros(length(ztd0),1);
            end            
            % Meteo data from GPT
            [pres0,temp0,~] = gpt(mjd0,ell(1)/180*pi,ell(2)/180*pi,ell(3));
            % ZHD 
            [zhd0] = saasthyd(pres0,ell(1)/180*pi,ell(3));
            % Check if option "Take only available epochs" is active
            if get(handles.zhd_thinout_check,'Value') == 1
                for j = 1:length(ztd0)
                    % Store only existing epochs
                    fprintf(out,'%11.5f %4s %8.4f %8.4f %7.3f %7.3f %7.2f %6.1f %7.2f   %s\n',mjd0(j),sta{nsta(i)},ztd0(j)/1000,ztd0(j)/1000-zhd0(j),gn0(j),ge0(j),pres0(j),temp0(j),0,meteo_opt{var});
                end
            else
                % Interpolate (thinout) time series
                ztd  = interp1(mjd0,ztd0,mjd,'linear','extrap');
                zhd  = interp1(mjd0,zhd0,mjd,'linear','extrap');
                gn   = interp1(mjd0,gn0,mjd,'linear','extrap');
                ge   = interp1(mjd0,ge0,mjd,'linear','extrap');
                pres = interp1(mjd0,pres0,mjd,'linear','extrap');
                temp = interp1(mjd0,temp0,mjd,'linear','extrap');
                % Store all epochs
                for j = 1:length(zhd)
                    fprintf(out,'%11.5f %4s %8.4f %8.4f %7.3f %7.3f %7.2f %6.1f %7.2f   %s\n',mjd(j),sta{nsta(i)},ztd(j)/1000,ztd(j)/1000-zhd(j),gn(j),ge(j),pres(j),temp(j),0,meteo_opt{var});
                end
            end
            clear ztd0 mjd0 ge0 gn0
        end
    case 'GPT2w'
        % Open gpt2w global grid
        gpt2w_grid = gpt2_1w_fast_readGrid;
        % Compute time series
        for i = 1:length(nsta)
            waitbar(i/length(nsta),h);
            % Station coordinates (lat,lon,h)
            ell  = handles.zhd_input3_crd(i,:);
            % Get station record (from SINEX_TRO)
            stat = handles.zhd_input1_sta_full;
            % Select records for the station of interest
            rec  = strcmp(stat,sta(nsta(i)));
            % Get data from SINEX_TRO (mjd, ztd)
            mjd0 = handles.zhd_input1_data(rec,1);
            ztd0 = handles.zhd_input1_data(rec,2);
            % Check number of entries > 1
            if isempty(ztd0); continue; end
            % Remove double entries
            [~,ind] = unique(mjd0); mjd0 = mjd0(ind); ztd0 = ztd0(ind);            
            % Get north-gradients
            gn_i = strcmp(handles.zhd_input1_cont,'N-Gradient [mm]');
            if any(gn_i) == 1
                gn0 = handles.zhd_input1_data(rec,gn_i);
                gn0 = gn0(ind);
            else
                gn0 = zeros(length(ztd0),1);
            end
            % Get east-gradients
            ge_i = strcmp(handles.zhd_input1_cont,'E-Gradient [mm]'); 
            if any(ge_i) == 1
                ge0 = handles.zhd_input1_data(rec,ge_i);
                ge0 = ge0(ind);
            else
                ge0 = zeros(length(ztd0),1);
            end             
            % Initialise variables
            pres0 = zeros(length(mjd0),1); temp0 = zeros(length(mjd0),1);
            wvp0  = zeros(length(mjd0),1);
            % Meteo data from GPT2w
            for j = 1:length(mjd0)
                [pres0(j),temp0(j),~,~,wvp0(j),~,~,~,~] = gpt2_1w_fast(mjd0(j),ell(1)/180*pi,ell(2)/180*pi,ell(3),1,0,gpt2w_grid);
            end
            % ZHD 
            [zhd0] = saasthyd(pres0,ell(1)/180*pi,ell(3));
           % Check if option "Take only available epochs" is active
            if get(handles.zhd_thinout_check,'Value') == 1
                for j = 1:length(ztd0)
                    % Store only existing epochs
                    fprintf(out,'%11.5f %4s %8.4f %8.4f %7.3f %7.3f %7.2f %6.1f %7.2f   %s\n',mjd0(j),sta{nsta(i)},ztd0(j)/1000,ztd0(j)/1000-zhd0(j),gn0(j),ge0(j),pres0(j),temp0(j),wvp0(j),meteo_opt{var});
                end
            else            
                % Interpolate (thinout) time series
                ztd  = interp1(mjd0,ztd0,mjd,'linear','extrap');
                zhd  = interp1(mjd0,zhd0,mjd,'linear','extrap');
                gn   = interp1(mjd0,gn0,mjd,'linear','extrap');
                ge   = interp1(mjd0,ge0,mjd,'linear','extrap');
                pres = interp1(mjd0,pres0,mjd,'linear','extrap');
                temp = interp1(mjd0,temp0,mjd,'linear','extrap');
                wvp  = interp1(mjd0,wvp0,mjd,'linear','extrap');
                % Store all epochs
                for j = 1:length(zhd)
                    fprintf(out,'%11.5f %4s %8.4f %8.4f %7.3f %7.3f %7.2f %6.1f %7.2f   %s\n',mjd(j),sta{nsta(i)},ztd(j)/1000,ztd(j)/1000-zhd(j),gn(j),ge(j),pres(j),temp(j),wvp(j),meteo_opt{var});
                end
            end
            clear ztd0 mjd0 ge0 gn0
        end        
    case 'In-situ'
        % In-situ station selected?
        sta2  = get(handles.zhd_station_list2,'String');
        nsta2 = get(handles.zhd_station_list2,'Value');
        if isequal(sta2,'No station'); check_in = 0; end
        if check_in == 0; set(handles.zhd_status_text,'String','Error, no in-situ station selected!'); close(h); return; end 
        % Coordinates available?
        str2 = get(handles.zhd_input4_list,'String');
        if isequal(str2,''); check_in = 0; end
        if check_in == 0; set(handles.zhd_status_text,'String','Error, load in-situ coordinates!'); close(h); return; end         
        % Read height correction option (NONE, Karabatic et al (2011), Exponential)
        hextrap_opt = get(handles.zhd_extrap_popup,'String');   
        var2 = get(handles.zhd_extrap_popup,'Value');
        % Read max height difference [m]
        hmax = str2double(get(handles.zhd_hmax_edit,'String'));
        if ~isnan(hmax); set(handles.zhd_hmax_edit,'BackgroundColor',[1 1 1],'Enable','Inactive'); end
        % Read max position difference [km]
        dmax = str2double(get(handles.zhd_dmax_edit,'String'));  
        if ~isnan(dmax); set(handles.zhd_dmax_edit,'BackgroundColor',[1 1 1],'Enable','Inactive'); end
        % Meteo outlier test
        if get(handles.zhd_outliers_check,'Value') == 1
            % Find lines with NaN
            rec_NaN = find(isnan(handles.zhd_input2_data(:,4)));
            % Find lines with T < -80
            rec_To  = find(handles.zhd_input2_data(:,2) < -80);
            % Find lines with p < 0 
            rec_po  = find(handles.zhd_input2_data(:,3) < 0);
            % Find outliers p > 3*standard deviation
            p       = handles.zhd_input2_data(:,3);
            rec_p1  = find(abs(p-mean(p))>std(p)*3);
            % Find lines with 0 < rH > 1
            rec_rho = find(handles.zhd_input2_data(:,4) < 0);
            rec_rh1 = find(handles.zhd_input2_data(:,4) > 1); % > 100 f�r GPT2w_mod
            % Combine all records
            rec_outl = unique([rec_NaN;rec_To;rec_po;rec_p1;rec_rho;rec_rh1]);
            % Delete GNSS outliers
            handles.zhd_input2_data(rec_outl,:) = [];
            handles.zhd_input2_sta_full(rec_outl,:) = [];
        end   
        % Compute time series
        for i = 1:length(nsta)
            waitbar(i/length(nsta),h);
            % GNSS station coordinates (lat,lon,h)
            ell1 = handles.zhd_input3_crd(i,:);
            % In-situ station coordinates (lat,lon,h)
            ell2 = handles.zhd_input4_crd;
            % Find closest stations       
            [name,dh,dist] = closest_station(ell1,sta2(nsta2),ell2,hmax,dmax);
            % Define output string
            string{i} = sprintf('%4s   %5s %8.1f %8.1f',sta{nsta(i)},name,dh,dist);
            % Compute time series
            if ~strcmp(name,'xxxxx')                                            
                % Get epochs (mjd0) for selected GNSS site   
                rec0 = strcmp(handles.zhd_input1_sta_full,sta(nsta(i)));
                mjd0 = handles.zhd_input1_data(rec0,1);    
                % Get epochs (mjd2) for selected in-situ site    
                rec2 = strcmp(handles.zhd_input2_sta_full,name);
                mjd2 = handles.zhd_input2_data(rec2,1);
                % Check number of entries > 1
                if isempty(mjd0) || isempty(mjd2); continue; end                 
                % Check overlapp of time periods
                if mjd2(end) >= mjd0(1) && mjd2(1) <= mjd0(end)  
                    % Get in-situ data (temperature, pressure, relative humidity)
                    temp2 = handles.zhd_input2_data(rec2,2); % �C
                    pres2 = handles.zhd_input2_data(rec2,3); % hPa
                    rhum2 = handles.zhd_input2_data(rec2,4); % [ ] between 0 and 1
                    % Water vapour pressure e2 at TAWES site
                    e2    = rhum2.*6.112.*exp((17.62.*temp2./(243.12+temp2))); % [hPa]  
                    %e2    = rhum2*10 % > 100 f�r GPT2w_mod
                    % Extrapolate pressure to GNSS height
                    switch hextrap_opt{var2}
                        case 'NONE'
                            pres0 = pres2;
                            temp0 = temp2;
                            wvp0  = e2;
                        case 'Karabatic et al. (2011)'
                            % specific gas constant Rd
                            Rg = 8314.459; % g*m^2/s^2/K/mol
                            Md = 28.9645; % g/mol
                            Rd = Rg/Md;  % m^2/s^2/K  
                            % temperature lapse rate (standard atmosphere)
                            dT = 0.0065; % [K/m]
                            % Tawes crd
                            h2_id = strcmp(sta2(nsta2),name);
                            % Mean latitude
                            latm = (ell1(1)+ell2(h2_id,1))/2;
                            % Mean height
                            hm = ell1(3) - dh/2;
                            % Earth radius wrt WGS84
                            RE = 6378137./(1.0068026-0.006705622*sind(latm).^2);
                            % Effective radius
                            Rcorr = (1./(1+hm./RE)).^2;
                            % gravity acceleration g at TAWES site (by Hitsch 2004)                            
                            g = 9.80665.*(1-0.00263724*cosd(2*latm)...
                                +5.82*10^-6*cosd(2*latm).^2).*Rcorr; % m/s^2  
                            % pressure pres0 at GNSS site                                     
                            pres0 = pres2.*(((temp2+273.15)-dT*dh)./(temp2+273.15)).^(g/(Rd*dT));
                            % temperature temp0 at GNSS site
                            temp0 = temp2; %- dT*dh;
                            % water vapour decrease factor
                            % lam = 5.4; % Mean value from GPT2w for h = 500m
                            % water vapour pressure e0 at GNSS site
                            wvp0 = e2; %.*(pres0./pres2).^(lam+1);
                        case 'Exponential'
                            % specific gas constant Rd
                            Rg = 8314.459; % g*m^2/s^2/K/mol
                            Md = 28.9645; % g/mol
                            Rd = Rg/Md;  % m^2/s^2/K   
                            % temperature lapse rate (standard atmosphere)
                            dT = 0.0065; % [K/m] 
                            % Tawes crd
                            h2_id = strcmp(sta2(nsta2),name);  
                            % Mean latitude
                            latm = (ell1(1)+ell2(h2_id,1))/2;
                            % Mean height
                            hm = ell1(3) - dh/2;
                            % Earth radius wrt WGS84
                            RE = 6378137./(1.0068026-0.006705622*sind(latm).^2);
                            % Effective radius
                            Rcorr = (1./(1+hm./RE)).^2;
                            % virtual temperature Tv at TAWES site
                            Tv = (temp2+273.15).*(1+0.378*e2./pres2); % K 
                            % virtual temperature Tvm at mean height
                            Tvm = Tv - dT*dh/2;
                            % gravity acceleration g at TAWES site (by Hitsch 2004)                            
                            g = 9.80665.*(1-0.00263724*cosd(2*latm)...
                                +5.82*10^-6*cosd(2*latm).^2).*Rcorr; % m/s^2                          
                            % pressure pres0 at GNSS site                            
                            pres0 = pres2.*exp(-g./Rd./Tvm.*dh);
                            % temperature temp0 at GNSS site
                            temp0 = temp2; %- dT*dh;
                            % water vapour decrease factor
                            % lam = 5.4; % Mean value from GPT2w for h = 500m
                            % water vapour pressure e0 at GNSS site
                            wvp0 = e2; % .*(pres0./pres2).^(lam+1);
                    end               
                    % Get ZTD from SINEX_TRO
                    ztd0 = handles.zhd_input1_data(rec0,2);
                    % Check number of entries > 1
                    if isempty(ztd0); continue; end
                    % Remove double entries
                    [~,ind] = unique(mjd0); mjd0 = mjd0(ind); ztd0 = ztd0(ind);                     
                    % Get north-gradients
                    gn_i = strcmp(handles.zhd_input1_cont,'N-Gradient [mm]');
                    if any(gn_i) == 1
                        gn0 = handles.zhd_input1_data(rec0,gn_i);
                        gn0 = gn0(ind);
                    else
                        gn0 = zeros(length(ztd0),1);
                    end
                    % Get east-gradients
                    ge_i = strcmp(handles.zhd_input1_cont,'E-Gradient [mm]'); 
                    if any(ge_i) == 1
                        ge0 = handles.zhd_input1_data(rec0,ge_i);
                        ge0 = ge0(ind);
                    else
                        ge0 = zeros(length(ztd0),1);
                    end
                    % Check if option "Take only available epochs" is active
                    if get(handles.zhd_thinout_check,'Value') == 1
                        % Interpolate in-situ time series to mjd0
                        pres = interp1(mjd2,pres0,mjd0,'linear','extrap');
                        temp = interp1(mjd2,temp0,mjd0,'linear','extrap');
                        wvp  = interp1(mjd2,wvp0,mjd0,'linear','extrap');
                        % Compute ZHD
                        zhd0 = saasthyd(pres,ell1(1)/180*pi,ell1(3));
                        % Loop over available epochs
                        for j = 1:length(ztd0)
                            fprintf(out,'%11.5f %4s %8.4f %8.4f %7.3f %7.3f %7.2f %6.1f %7.2f   %s\n',mjd0(j),sta{nsta(i)},ztd0(j)/1000,ztd0(j)/1000-zhd0(j),gn0(j),ge0(j),pres(j),temp(j),wvp(j),name);
                        end
                    else
                        % Interpolate in-situ time series to mjd
                        pres = interp1(mjd2,pres0,mjd,'linear','extrap');
                        temp = interp1(mjd2,temp0,mjd,'linear','extrap');
                        wvp  = interp1(mjd2,wvp0,mjd,'linear','extrap');
                        % Compute ZHD
                        zhd = saasthyd(pres,ell1(1)/180*pi,ell1(3));
                        % Interpolate GNSS time series to mjd
                        ztd  = interp1(mjd0,ztd0,mjd,'linear','extrap');                   
                        gn   = interp1(mjd0,gn0,mjd,'linear','extrap');
                        ge   = interp1(mjd0,ge0,mjd,'linear','extrap');
                        % Loop over available epochs
                        for j = 1:length(ztd)
                            fprintf(out,'%11.5f %4s %8.4f %8.4f %7.3f %7.3f %7.2f %5.1f %6.2f  %s\n',mjd(j),sta{nsta(i)},ztd(j)/1000,ztd(j)/1000-zhd(j),gn(j),ge(j),pres(j),temp(j),wvp(j),name);
                        end    
                    end                    
                else
                    % Modify output string (add * flag) if out of time
                    string{i} = sprintf('%4s   %5s %8.1f %8.1f         T',sta{nsta(i)},name,dh,dist);
                    error_id = 1;
                end
            end
            % Display string
            set(handles.zhd_pair_headline,'String','GNSS    in-situ   dh [m]   d [km]  Flag')
            set(handles.zhd_pair_list,'String',string);
            clear ztd0 mjd0 ge0 gn0 pres0 temp0 wvp0
        end
end
fclose(out);
close(h);
if error_id == 0
    set(handles.zhd_status_text,'String','Done! Please check results in the output file')
elseif error_id == 1
    set(handles.zhd_status_text,'String','Done! No common epochs found for entries with flag T')
end

% --------------------------- Co-located site list -----------------------
function zhd_pair_list_Callback(hObject, eventdata, handles)

function zhd_pair_list_CreateFcn(hObject, eventdata, handles)

% --------------------------- Show data ----------------------------------
function zhd_show_data_Callback(hObject, eventdata, handles)
% File name
fname = get(handles.zhd_output_com,'String');
% Read and store data
fid = fopen(fname,'r');
if fid > 0
    if strcmp(fname(end-2:end),'ZWD')
        dat = textscan(fid,'%f %4c %f %f %f %f %f %f %f %s');
        handles.zhd_show_data = [cellstr(num2str(dat{1},'%11.5f')),cellstr(dat{2}),...
            cellstr(num2str(dat{3},'%8.4f')),cellstr(num2str(dat{4},'%8.4f')),...
            cellstr(num2str(dat{5},'%7.3f')),cellstr(num2str(dat{6},'%7.3f')),...
            cellstr(num2str(dat{7},'%7.2f')),cellstr(num2str(dat{8},'%5.1f')),...
            cellstr(num2str(dat{9},'%6.2f')),cellstr(dat{10})];
        handles.zhd_show_cont = {'MJD';'Station';'ZTD [m]';'ZWD [m]';'GN [mm]';'GE [mm]';'p [hPa]';'T [�C]';'e [hPa]';'MeteoID'};
    end
    set(handles.zhd_show_table,'Data',handles.zhd_show_data);
    set(handles.zhd_show_table,'ColumnName',handles.zhd_show_cont);
    fclose(fid);
else
    set(handles.zhd_status_text,'String','Output file does not exist');
end
set(handles.zhd_status_text,'String',sprintf('Data loaded from %s',fname));

% --------------------------- Clear all ----------------------------------
function zhd_clear_all_Callback(hObject, eventdata, handles)
% Reset
set(handles.zhd_epoch1_year,'String','year');
set(handles.zhd_epoch1_doy,'String','doy');
set(handles.zhd_epoch1_sod,'String','sod');
set(handles.zhd_epoch2_year,'String','year')
set(handles.zhd_epoch2_doy,'String','doy'); 
set(handles.zhd_epoch2_sod,'String','sod');

set(handles.zhd_rate_edit,'String','sec');
set(handles.zhd_rate_edit,'BackgroundColor',[1 1 1]);

set(handles.zhd_hmax_edit,'String','200');
set(handles.zhd_hmax_edit,'BackgroundColor',[1 1 1]);

set(handles.zhd_dmax_edit,'String','30');
set(handles.zhd_dmax_edit,'BackgroundColor',[1 1 1]);

set(handles.zhd_input1_list,'String','No file');
set(handles.zhd_input1_list,'Value',1);

set(handles.zhd_station_list1,'String','No station');
set(handles.zhd_station_list1,'Value',1);

set(handles.zhd_input2_list,'String','No file');
set(handles.zhd_input2_list,'Value',1);

set(handles.zhd_station_list2,'String','No station');
set(handles.zhd_station_list2,'Value',1);

set(handles.zhd_input3_filename,'String','No file');
set(handles.zhd_input3_list,'String','');
set(handles.zhd_input3_list,'Value',1);

set(handles.zhd_input4_filename,'String','No file');
set(handles.zhd_input4_list,'String','');
set(handles.zhd_input4_list,'Value',1);

set(handles.zhd_show_table,'Data',[]);
set(handles.zhd_show_table,'ColumnName','');

set(handles.zhd_pair_headline,'String','');
set(handles.zhd_pair_list,'String','');

% Initialise variables
handles.zhd_input3_data = [];
handles.zhd_input3_stat = [];
handles.zhd_input3_sat  = [];
guidata(hObject, handles);


%% ------------------------- Panel Convert_brdc ---------------------------
function uipanel_convert_brdc_CreateFcn(hObject, eventdata, handles)

% -------------------------- Open brdc files ------------------------------
function convert_brdc_input1_open_Callback(hObject, eventdata, handles)
% Read file names
[filename1, handles.convert_brdc_input1_pathname1] = uigetfile({...
    'brdc*','GPS/GLONASS Navigation data';...
    '*n','GPS Navigation data';...
    '*g','GLONASS Navigation data'},...    
    'Select File',handles.atom_start_input,'MultiSelect','on');
% Pass file names to listbox
if isequal(filename1,0)
    set(handles.convert_brdc_input1_list,'String',{'No file'});
    set(handles.convert_brdc_input1_list,'Value',1)
    set(handles.convert_brdc_status_text,'String','No file selected');    
else
    set(handles.convert_brdc_input1_list,'String',cellstr(filename1));
    set(handles.convert_brdc_input1_list,'Value',1)
    set(handles.convert_brdc_sat_list,'String','No satellite');
    set(handles.convert_brdc_sat_list,'Value',1);
    set(handles.convert_brdc_status_text,'String','Load file(s)');
end
guidata(hObject, handles);

function convert_brdc_input1_list_Callback(hObject, eventdata, handles)
% Set the limit of files which can be selected
set(hObject,'min',0,'max',10);
% Use 'Entf to delete entries in listbox
set(hObject,'keypressfcn',@key_check)
guidata(hObject, handles);

function convert_brdc_input1_list_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function convert_brdc_input1_load_Callback(hObject, eventdata, handles)
% Read file names in listbox
str = get(handles.convert_brdc_input1_list,'String');
val = get(handles.convert_brdc_input1_list,'Value');
% If files exist (check if str == 'No file')
if strcmp(str,'No file') ~= 1
    % Create waitbar
    h = waitbar(0,'Please wait...','WindowStyle','modal');
    % Initialise variables
    handles.convert_brdc_input1_data = [];
    % Loop to create list with filenames
    for i = 1:length(val)
        % Fill wait bar
        waitbar(i/length(val),h);        
        % Check input file type (*n, *g, ...)
        fullpathname(i,:) = strcat(handles.convert_brdc_input1_pathname1,str{val(i)});
    end
    % Read in data
    handles.convert_brdc_input1_data = read_brdc(fullpathname);
    % Set time variables
    set(handles.convert_brdc_sat_list,'String',unique(handles.convert_brdc_input1_data.sat))
    set(handles.convert_brdc_sat_list,'Value',1)
    set(handles.convert_brdc_epoch1_year,'String',sprintf('%4d',min(handles.convert_brdc_input1_data.yy)));
    set(handles.convert_brdc_epoch2_year,'String',sprintf('%4d',max(handles.convert_brdc_input1_data.yy)));
    set(handles.convert_brdc_epoch1_doy,'String',sprintf('%3d',min(handles.convert_brdc_input1_data.doy)));
    set(handles.convert_brdc_epoch2_doy,'String',sprintf('%3d',max(handles.convert_brdc_input1_data.doy)));
    set(handles.convert_brdc_epoch1_sod,'String',sprintf('%5d',min(handles.convert_brdc_input1_data.sod)));
    set(handles.convert_brdc_epoch2_sod,'String',sprintf('%5d',max(handles.convert_brdc_input1_data.sod)));
    set(handles.convert_brdc_sat_headline,'String','Satellites: 1');
    if get(handles.convert_brdc_aer2xyz,'Value') == 1
        set(handles.convert_brdc_output_com,'String',[handles.atom_start_output '\' str{val(i)}(1:end-4) '.xyz']);
    else
        set(handles.convert_brdc_output_com,'String',[handles.atom_start_output '\' str{val(i)}(1:end-4) '.aer']);
    end
    close(h);
end
guidata(hObject, handles);

% ---------------------------- Select satellites --------------------------
function convert_brdc_sat_list_Callback(hObject, eventdata, handles)
% Set the limit of files which can be selected
set(hObject,'min',0,'max',300);
guidata(hObject, handles);
% Use 'Entf to delete entries in listbox
set(hObject,'keypressfcn',@key_check)
% Count number of selected stations
set(handles.convert_brdc_sat_headline,'String',['Satellites: ' num2str(length(get(hObject,'Value')))]);
guidata(hObject,handles);

function convert_brdc_sat_list_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ---------------------------- Select stations ----------------------------
function convert_brdc_stat_list_Callback(hObject, eventdata, handles)
% Set the limit of files which can be selected
set(hObject,'min',0,'max',300);
guidata(hObject, handles);
% Use 'Entf to delete entries in listbox
set(hObject,'keypressfcn',@key_check)
% Count number of selected stations
set(handles.convert_brdc_stat_headline,'String',['Stations: ' num2str(length(get(hObject,'Value')))]);
guidata(hObject,handles);

function convert_brdc_stat_list_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% -------------------------------- Epochs ---------------------------------
function convert_brdc_epoch1_year_Callback(hObject, eventdata, handles)

function convert_brdc_epoch1_year_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function convert_brdc_epoch1_year_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function convert_brdc_epoch2_year_Callback(hObject, eventdata, handles)

function convert_brdc_epoch2_year_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function convert_brdc_epoch2_year_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function convert_brdc_epoch1_doy_Callback(hObject, eventdata, handles)

function convert_brdc_epoch1_doy_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function convert_brdc_epoch1_doy_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function convert_brdc_epoch1_sod_Callback(hObject, eventdata, handles)

function convert_brdc_epoch1_sod_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function convert_brdc_epoch1_sod_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function convert_brdc_epoch2_doy_Callback(hObject, eventdata, handles)

function convert_brdc_epoch2_doy_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function convert_brdc_epoch2_doy_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function convert_brdc_epoch2_sod_Callback(hObject, eventdata, handles)

function convert_brdc_epoch2_sod_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function convert_brdc_epoch2_sod_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ---------------------------- Sampling rate -----------------------------
function convert_brdc_rate_edit_Callback(hObject, eventdata, handles)

function convert_brdc_rate_edit_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function convert_brdc_rate_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ---------------------------- Elevation angle ----------------------------
function convert_brdc_elev_edit_Callback(hObject, eventdata, handles)

function convert_brdc_elev_edit_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function convert_brdc_elev_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ---------------------------- aer2xyz ------------------------------------
function convert_brdc_aer2xyz_Callback(hObject, eventdata, handles)
if get(handles.convert_brdc_aer2xyz,'Value') == 1
    out = get(handles.convert_brdc_output_com,'String');
    if length(out) > 3
        set(handles.convert_brdc_output_com,'String',[out(1:end-3) 'xyz']);
    end
else
    out = get(handles.convert_brdc_output_com,'String');
    if length(out) > 3
        set(handles.convert_brdc_output_com,'String',[out(1:end-3) 'aer']);
    end
end

% --------------------------- Output filename -----------------------------
function convert_brdc_output_com_Callback(hObject, eventdata, handles)

function convert_brdc_output_com_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function convert_brdc_output_com_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% -------------------------- Open station crd -----------------------------
function convert_brdc_input2_open_Callback(hObject, eventdata, handles)
% Read file names
[filename1, handles.convert_brdc_input2_pathname1] = uigetfile({...
    '*.NEU','NEU coordinate file'},...
    'Select File',handles.atom_start_input,'MultiSelect','on');
% Pass file names to listbox
if isequal(filename1,0)
    set(handles.convert_brdc_input2_filename,'String',{'No file'});
else
    set(handles.convert_brdc_input2_filename,'String',cellstr(filename1));
    set(handles.convert_brdc_status_text,'String','Load CRD file');
end
guidata(hObject, handles);

function convert_brdc_input2_load_Callback(hObject, eventdata, handles)
% Read filename
str = get(handles.convert_brdc_input2_filename,'String');
if strcmp(str,'No file') ~= 1
    % Clear list
    set(handles.convert_brdc_input2_list,'String','');
    % Set path name of coordinate file   
    fullpathname = strcat(handles.convert_brdc_input2_pathname1,str{1});
    % Read coordinates from file
    [dat1,dat2] = read_NEU_all(fullpathname,handles);
    handles.convert_brdc_input2_crd = dat1;
    handles.convert_brdc_input2_sta = dat2;
    id = find(dat1 == 0,1);
    if ~isempty(id)
        set(handles.convert_brdc_status_text,'String','No coordinates found! Please select CRD file with coordinates for all stations');
    else
        set(handles.convert_brdc_input2_list,'String',dat2);
        set(handles.convert_brdc_status_text,'String','CRD loaded for all stations in file, select station(s) and Start! processing');
        set(handles.convert_brdc_input2_list,'Value',[]);
        set(handles.convert_brdc_stat_list,'Value',1)
        set(handles.convert_brdc_stat_list,'String',cellfun(@(x) x(1:5),dat2,'UniformOutput',false))
        set(handles.convert_brdc_stat_headline,'String','Stations: 1');        
    end
    guidata(hObject, handles);
end

function convert_brdc_input2_list_Callback(hObject, eventdata, handles)
% Set the limit of files which can be selected
set(hObject,'min',0,'max',100);
% Use 'Entf to delete entries in listbox
set(hObject,'keypressfcn',@key_check)
guidata(hObject, handles);

function convert_brdc_input2_list_CreateFcn(hObject, eventdata, handles)
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end

% ---------------------------- Compute positions --------------------------
function convert_brdc_output_save_Callback(hObject, eventdata, handles)
% Check data and settings * not fully implemented yet *
check = 1;
% brdc data available?
% satellites selected?
% station crd available?
% stations selected?
% sampling rate set?
% epochs (begin, end) reasonable?
% elevation angle set?

% Start processing
if check == 1    
    % Read satellites
    sat  = get(handles.convert_brdc_sat_list,'String');
    val  = get(handles.convert_brdc_sat_list,'Value');
    % Read station names and coordinates
    stat = get(handles.convert_brdc_stat_list,'String');
    vals = get(handles.convert_brdc_stat_list,'Value');
    crd  = handles.convert_brdc_input2_crd(vals,:);
    % Get start and end epoch
    y1 = str2double(get(handles.convert_brdc_epoch1_year,'String'));
    y2 = str2double(get(handles.convert_brdc_epoch2_year,'String'));
    d1 = str2double(get(handles.convert_brdc_epoch1_doy,'String'));
    d2 = str2double(get(handles.convert_brdc_epoch2_doy,'String'));
    s1 = str2double(get(handles.convert_brdc_epoch1_sod,'String'));
    s2 = str2double(get(handles.convert_brdc_epoch2_sod,'String'));
    % Get sampling rate
    dt = str2double(get(handles.convert_brdc_rate_edit,'String'))/86400;
    % Compute mjd
    mjd1 = date2mjd(y1,1,1)+d1-1+s1/86400;
    mjd2 = date2mjd(y2,1,1)+d2-1+s2/86400;
    % Output filename
    outfile = get(handles.convert_brdc_output_com,'String');
    out = fopen(outfile,'w');
    % Elevation angle
    elev_min = str2double(get(handles.convert_brdc_elev_edit,'String'));
    % Create waitbar
    h = waitbar(0,'Please wait...','WindowStyle','modal');    
    % Loop satellites
    for n = 1:length(val)
        % Fill wait bar
        waitbar(n/length(val),h);
        % Get entries for selected satellite
        ixs = strcmp(handles.convert_brdc_input1_data.sat,sat{val(n)});
        if strcmp(sat{val(n)}(1),'G')
            Crs = handles.convert_brdc_input1_data.Crs(ixs);
            dn  = handles.convert_brdc_input1_data.dn(ixs);
            Mo  = handles.convert_brdc_input1_data.Mo(ixs);
            Cuc = handles.convert_brdc_input1_data.Cuc(ixs);
            e   = handles.convert_brdc_input1_data.e(ixs);
            Cus = handles.convert_brdc_input1_data.Cus(ixs);
            a   = handles.convert_brdc_input1_data.a(ixs);
            toe = handles.convert_brdc_input1_data.toe(ixs);
            Cic = handles.convert_brdc_input1_data.Cic(ixs);
            OM  = handles.convert_brdc_input1_data.OM(ixs);
            Cis = handles.convert_brdc_input1_data.Cis(ixs);
            io  = handles.convert_brdc_input1_data.io(ixs);
            Crc = handles.convert_brdc_input1_data.Crc(ixs);
            om  = handles.convert_brdc_input1_data.om(ixs);
            OMd = handles.convert_brdc_input1_data.OMd(ixs);
            idot= handles.convert_brdc_input1_data.idot(ixs);
            week= handles.convert_brdc_input1_data.week(ixs);
            mjd = gps2mjd(week,toe);
        elseif strcmp(sat{val(n)}(1),'R')
            x   = handles.convert_brdc_input1_data.x(ixs);
            vx  = handles.convert_brdc_input1_data.vx(ixs);
            ax  = handles.convert_brdc_input1_data.ax(ixs);
            y   = handles.convert_brdc_input1_data.y(ixs);
            vy  = handles.convert_brdc_input1_data.vy(ixs);
            ay  = handles.convert_brdc_input1_data.ay(ixs);
            z   = handles.convert_brdc_input1_data.z(ixs);
            vz  = handles.convert_brdc_input1_data.vz(ixs);
            az  = handles.convert_brdc_input1_data.az(ixs);
            ls  = handles.convert_brdc_input1_data.lsec;
            mjd = handles.convert_brdc_input1_data.mjd(ixs)+ls/86400;           
        end
        % Loop time
        for mjd0 = mjd1:dt:mjd2        
            % Get closest set of parameters
            [~, ixt] = min(abs(mjd-mjd0));
            % Compute time difference tk
            tk = round((mjd0 - mjd(ixt))*86400);
            % Compute satellite positions
            if strcmp(sat{val(n)}(1),'G')
                satpos = cal_satpos_kepler(toe(ixt),tk,a(ixt),dn(ixt),Mo(ixt),...
                    e(ixt),om(ixt),Cuc(ixt),Cus(ixt),Crc(ixt),Crs(ixt),Cic(ixt),...
                    Cis(ixt),io(ixt),OM(ixt),OMd(ixt),idot(ixt));
            elseif strcmp(sat{val(n)}(1),'R')
                satpos = cal_satpos_numer(tk,x(ixt),vx(ixt),ax(ixt),...
                    y(ixt),vy(ixt),ay(ixt),z(ixt),vz(ixt),az(ixt));
            end
            % Ellipsoidal coordinates
            [Bn,Ln,Hn] = kart2ell(satpos(1),satpos(2),satpos(3));    
            % Azimuth and elevation angles
            [azi,ele,range] = geodetic2aer(Bn,Ln,Hn,crd(:,1),crd(:,2),crd(:,3),referenceEllipsoid('WGS84'));
            [yr,doy,sod] = mjd2doy(mjd0);
            % Station Loop 
            for s = 1:length(vals)                
                if ele(s) >= elev_min && get(handles.convert_brdc_aer2xyz,'Value') == 0
                    fprintf(out,'%4.4d %3.3d %5.0f %4s%s     %8.4f %7.4f %10.4f\n',yr,doy,sod,stat{vals(s)},sat{val(n)},azi(s),ele(s),range(s));                                                            
                end
            end
            if get(handles.convert_brdc_aer2xyz,'Value') == 1
                fprintf(out,'%4.4d %3.3d %5.0f %s %13.3f %13.3f %13.3f\n',yr,doy,sod,sat{val(n)},satpos(1),satpos(2),satpos(3));
            end
        end
        clear ixs Crs dn Mo Cuc e Cus a toe Cic OM Cis io Crc om MDd idot week mjd satpos x vx ax y vy ay z vz az
    end 
    close(h);
    set(handles.convert_brdc_status_text,'String','Finished, check output file!')
    fclose(out);
end

% ---------------------------- Show data ----------------------------------
function convert_brdc_data_show_Callback(hObject, eventdata, handles)
% File name
fname = get(handles.convert_brdc_output_com,'String');
% Read and store data
fid = fopen(fname,'r');
if fid > 0
    if strcmp(fname(end-2:end),'aer')
        dat = textscan(fid,'%f %f %f %4c %3c %f %f %f');
        handles.brdc_show_data = [cellstr(num2str(dat{1},'%4.0f')),....
            cellstr(num2str(dat{2},'%3.0f')),cellstr(num2str(dat{3},'%5.0f')),...
            cellstr(dat{4}),cellstr(dat{5}) ,cellstr(num2str(dat{6},'%8.4f')),...
            cellstr(num2str(dat{7},'%7.4f')),cellstr(num2str(dat{8},'%13.4f'))];
        handles.brdc_show_cont = {'Year';'DoY';'SoD';'Station';'Sat';'Azimuth';'Elevation';'Range'};
    end
    if strcmp(fname(end-2:end),'xyz')
        dat = textscan(fid,'%f %f %f %3c %f %f %f');
        handles.brdc_show_data = [cellstr(num2str(dat{1},'%4.0f')),....
            cellstr(num2str(dat{2},'%3.0f')),cellstr(num2str(dat{3},'%5.0f')),...
            cellstr(dat{4}),cellstr(num2str(dat{5},'%8.4f')),...
            cellstr(num2str(dat{6},'%7.4f')),cellstr(num2str(dat{7},'%13.4f'))];
        handles.brdc_show_cont = {'Year';'DoY';'SoD';'Sat';'X [m]';'Y [m]';'Z [m]'};
    end    
    set(handles.convert_brdc_data_table,'Data',handles.brdc_show_data);
    set(handles.convert_brdc_data_table,'ColumnName',handles.brdc_show_cont);
    fclose(fid);
else
    set(handles.convert_brdc_status_text,'String','Output file does not exist');
end
set(handles.convert_brdc_status_text,'String',sprintf('Data loaded from %s',fname));

% ---------------------------- Clear all ----------------------------------
function convert_brdc_clear_all_Callback(hObject, eventdata, handles)
% Reset
set(handles.convert_brdc_input1_list,'String','No file');
set(handles.convert_brdc_input1_list,'Value',1);

set(handles.convert_brdc_sat_list,'String','No satellite');
set(handles.convert_brdc_sat_list,'Value',1);

set(handles.convert_brdc_stat_list,'String','No station');
set(handles.convert_brdc_stat_list,'Value',1);

set(handles.convert_brdc_input2_filename,'String','No file');
set(handles.convert_brdc_input2_list,'String','');
set(handles.convert_brdc_input2_list,'Value',1);

set(handles.convert_brdc_epoch1_year,'String','year');
set(handles.convert_brdc_epoch1_doy,'String','doy');
set(handles.convert_brdc_epoch1_sod,'String','sod');
set(handles.convert_brdc_epoch2_year,'String','year')
set(handles.convert_brdc_epoch2_doy,'String','doy'); 
set(handles.convert_brdc_epoch2_sod,'String','sod');

set(handles.convert_brdc_rate_edit,'String','30');
set(handles.convert_brdc_rate_edit,'BackgroundColor',[1 1 1]);

set(handles.convert_brdc_data_table,'Data',[]);
set(handles.convert_brdc_data_table,'ColumnName','');

set(handles.convert_brdc_elev_edit,'String','5');
set(handles.convert_brdc_elev_edit,'BackgroundColor',[1 1 1]);

set(handles.convert_brdc_output_com,'String','');
set(handles.convert_brdc_output_com,'BackgroundColor',[1 1 1]);

set(handles.convert_brdc_status_text,'String','');

% Initialise variables
handles.brdc_show_data = [];
handles.brdc_show_cont = [];
handles.convert_brdc_input1_data = [];
handles.convert_brdc_input2_crd = [];
handles.convert_brdc_input2_sta = [];
guidata(hObject, handles);


%% ---------------------------- Panel std --------------------------------
% ------------------------------------------------------------------------
function uipanel_std_CreateFcn(hObject, eventdata, handles)

% ------------------------- ZTD/ZWD/Gradients (Input 1) ------------------
function std_input1_open_Callback(hObject, eventdata, handles)
% Read file names
[filename1, handles.std_input1_pathname1] = uigetfile({...
    '*ZWD','Zenith Wet Delays';...
    '*zpd','IGS SINEX Tropo files';...    
    '*TRO','NAPEOS SINEX Tropo files'},...
    'Select File',handles.atom_start_input,'MultiSelect','on');
% Pass file names to listbox
if isequal(filename1,0)
    set(handles.std_input1_list,'String',{'No file'});
    set(handles.std_input1_list,'Value',1)
else    
    set(handles.std_input1_list,'String',cellstr(filename1));
    set(handles.std_input1_list,'Value',1)
end
guidata(hObject, handles);

function std_input1_list_Callback(hObject, eventdata, handles)
% Set the limit of files which can be selected
set(hObject,'min',0,'max',1000);
% Use 'Entf to delete entries in listbox
set(hObject,'keypressfcn',@key_check)
guidata(hObject, handles);

function std_input1_list_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function std_input1_load_Callback(hObject, eventdata, handles)
% Read file names in listbox
str = get(handles.std_input1_list,'String');
val = get(handles.std_input1_list,'Value');
% Check if files exist
if strcmp(str,'No file') ~= 1
    % Initialise variables
    handles.std_input1_data = [];
    handles.std_input1_cont = [];
    handles.std_input1_sta_full = {};
    % Create waitbar
    h = waitbar(0,'Please wait...','WindowStyle','modal');
    % Loop to read each input file
    for i = 1:length(val)  
        % Fill wait bar
        waitbar(i/length(val),h);   
        % Path name
        fullpathname = strcat(handles.std_input1_pathname1,str{val(i)});             
        if strcmp(str{val(i)}(end-2:end),'TRO') || strcmp(str{val(i)}(end-2:end),'zpd')
            % Read troposphere estimates
            [dat1,dat2] = read_SINEX_TRO(fullpathname,'trp',handles);  
            % Concatinate cell arrays
            handles.std_input1_data = [handles.std_input1_data;dat1{2:end}];        
            handles.std_input1_cont = dat2(2:end); 
            handles.std_input1_sta_full = [handles.std_input1_sta_full;dat1{1}];
        elseif strcmp(str{val(i)}(end-2:end),'ZWD')
            % Read troposphere estimates
            [dat1,dat2] = read_ZWD(fullpathname); 
            % Concatinate cell arrays (station names)
            handles.std_input1_sta_full = [handles.std_input1_sta_full;dat1{2}];  
            % Remove stations and meteoid from cell array / content
            dat1(2) = []; dat1(end) = []; dat2(2) = [];
            % Concatinate cell arrays
            handles.std_input1_data = [handles.std_input1_data;dat1{:}];
            handles.std_input1_cont = dat2;
        end
    end
    close(h);
    % Comput start/end epoch of dataset and set panels
    [yr1,doy1,sod1] = mjd2doy(min(handles.std_input1_data(:,1)));
    [yr2,doy2,sod2] = mjd2doy(max(handles.std_input1_data(:,1)));
    set(handles.std_epoch1_year,'String',sprintf('%4.4d',yr1));
    set(handles.std_epoch1_doy,'String',sprintf('%3.3d',doy1));
    set(handles.std_epoch1_sod,'String',sprintf('%d',sod1));
    set(handles.std_epoch2_year,'String',sprintf('%4.4d',yr2));
    set(handles.std_epoch2_doy,'String',sprintf('%3.3d',doy2));
    set(handles.std_epoch2_sod,'String',sprintf('%d',sod2));
    % Set sampling rate
    dt = round((handles.std_input1_data(2,1)-handles.std_input1_data(1,1))*86400);
    set(handles.std_rate_edit,'String',dt)
    % List of stations
    set(handles.std_station_list,'Value',1);
    set(handles.std_station_list,'String',unique(handles.std_input1_sta_full));
    % Output file name
    if get(handles.std_output_switch,'Value') == 0
        if get(handles.std_delay_switch,'Value') == 0
            set(handles.std_output_com,'String',[handles.atom_start_output '\' str{val(1)}(1:end-4) '.STD']);
        else
            set(handles.std_output_com,'String',[handles.atom_start_output '\' str{val(1)}(1:end-4) '.SWD']);
        end
    else
        set(handles.std_output_com,'String',[handles.atom_start_output '\' str{val(1)}(1:end-4) '.SNX']);
    end
    % Status text
    set(handles.std_status_text,'String','ZTD/ZWD data loaded, select station(s)');    
    % Settings
    switch get(get(handles.std_output_buttongroup,'SelectedObject'),'Tag')
        case 'std_output_button1'
            set(handles.std_gradn_edit,'String','0')
            set(handles.std_grade_edit,'String','0') 
            set(handles.std_res_edit,'String','0') 
            set(handles.std_elev_edit,'String','5')
            set(handles.std_azi_edit,'String','0')
        case 'std_output_button2'
            set(handles.std_gradn_edit,'String','file')
            set(handles.std_grade_edit,'String','file')
            set(handles.std_res_edit,'String','0') 
            set(handles.std_elev_edit,'String','5')
            set(handles.std_azi_edit,'String','0')            
        case 'std_output_button3'
            set(handles.std_gradn_edit,'String','file')
            set(handles.std_grade_edit,'String','file')
            set(handles.std_rate_edit,'String','30')  
            set(handles.std_res_edit,'String','file') 
            set(handles.std_elev_edit,'String','file')
            set(handles.std_azi_edit,'String','file')            
    end
end
guidata(hObject, handles);

% ---------------------- GNSS station coordinates (Input 2) --------------
function std_input2_headline_CreateFcn(hObject, eventdata, handles)

function std_input2_open_Callback(hObject, eventdata, handles)
% Read file names
[filename1, handles.std_input2_pathname1] = uigetfile({...
    '*.NEU','NEU coordinate file'},...
    'Select File',handles.atom_start_input,'MultiSelect','on');
% Pass file names to listbox
if isequal(filename1,0)
    set(handles.std_input2_filename,'String',{'No file'});
else
    set(handles.std_input2_filename,'String',cellstr(filename1));
    set(handles.std_status_text,'String','Load CRD file');
end
guidata(hObject, handles);

function std_input2_load_Callback(hObject, eventdata, handles)
% Read filename
str = get(handles.std_input2_filename,'String');
if strcmp(str,'No file') ~= 1
    % Read stations
    str1 = get(handles.std_station_list,'String');
    val1 = get(handles.std_station_list,'Value');
    % If at least 1 file exist and at least 1 baseline is selected
    if isequal(str,'No file') ~= 1 && isequal(str1,'No baseline') ~= 1
        % Clear list
        set(handles.std_input2_list,'String','');
        % Set path name of coordinate file   
        fullpathname = strcat(handles.std_input2_pathname1,str{1});
        % Create statlist
        statlist = cellstr(str1(val1));
        % Read coordinates from file
        [dat1,dat2] = read_NEU(fullpathname,statlist,handles);
        handles.std_input2_crd = dat1;
        id = find(dat1 == 0,1);
        if ~isempty(id)
            set(handles.std_status_text,'String',[statlist{id},' not found! Please select CRD file with coordinates for all stations'])
        else
            set(handles.std_input2_list,'String',dat2);
            set(handles.std_status_text,'String','CRD loaded for selected baseline(s), check parameters and Start! conversion');
            set(handles.std_input2_list,'Value',[]);
        end 
    end    
end
guidata(hObject, handles);

function std_input2_filename_CreateFcn(hObject, eventdata, handles)

function std_input2_list_Callback(hObject, eventdata, handles)
% Set the limit of files which can be selected
set(hObject,'min',0,'max',1);
% Use 'Entf to delete entries in listbox
set(hObject,'keypressfcn',@key_check)
guidata(hObject, handles);

function std_input2_list_CreateFcn(hObject, eventdata, handles)
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end

% ---------------------- Observation residuals (Input 3) -----------------
function std_input3_headline_CreateFcn(hObject, eventdata, handles)

function std_input3_open_Callback(hObject, eventdata, handles)
% Read file names
[filename1, handles.std_input3_pathname1] = uigetfile({...
    '*.aer','Satellite positions';...
    '*.ZDR','ZDR in Napeos format';...
    '*.FRS','ZDR in Bernese format'},...
    'Select File',handles.atom_start_input,'MultiSelect','on');
% Pass file names to listbox
if isequal(filename1,0)
    set(handles.std_input3_list,'String',{'No file'});
    set(handles.std_input3_list,'Value',1)
else
    set(handles.std_input3_list,'String',cellstr(filename1));
    set(handles.std_input3_list,'Value',1)
end
guidata(hObject, handles);

function std_input3_list_Callback(hObject, eventdata, handles)
% Set the limit of files which can be selected
set(hObject,'min',0,'max',300);
% Use 'Entf to delete entries in listbox
set(hObject,'keypressfcn',@key_check)
guidata(hObject, handles);

function std_input3_list_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function std_input3_load_Callback(hObject, eventdata, handles)
% Read file names in listbox
str = get(handles.std_input3_list,'String');
val = get(handles.std_input3_list,'Value');
% If files exist (check if str == 'No file')
if strcmp(str,'No file') ~= 1
    % Initialise variables
    handles.std_input3_data = [];
    handles.std_input3_stat = [];
    handles.std_input3_sat  = [];
    % Create waitbar
    h = waitbar(0,'Please wait...','WindowStyle','modal');
    % Loop to read each input file
    for i = 1:length(val)
        % Fill wait bar
        waitbar(i/length(val),h);
        % Check input file type (*.ZDR, *.FRS, ...)
        fullpathname = strcat(handles.std_input3_pathname1,str{val(i)});  
        % Read and store data
        if strcmp(fullpathname(end-2:end),'aer')            
            [dat1,~,dat3,dat4] = read_aer(fullpathname);
        elseif strcmp(fullpathname(end-2:end),'ZDR')
            [dat1,~,dat3,dat4] = read_ZDR(fullpathname);
        elseif strcmp(fullpathname(end-2:end),'FRS')
            [dat1,~,dat3,dat4] = read_FRS_ZDR(fullpathname);
        end        
        handles.std_input3_data = [handles.std_input3_data,dat1];
        handles.std_input3_stat = [handles.std_input3_stat;dat3];
        handles.std_input3_sat  = [handles.std_input3_sat;dat4];
    end
    % Get time period of residuals
    mjd1 = min(handles.std_input3_data(2,:));
    mjde = max(handles.std_input3_data(2,:));
    % Check if ZTD/ZWD data available
    if strcmp(get(handles.std_epoch1_year,'String'),'year')
        close(h)
        set(handles.std_status_text,'String','Error: Load ZTD/ZWD/Gradients first')
        return
    end
    % Get old time parameters
    yr1o  = str2double(get(handles.std_epoch1_year,'String'));
    doy1o = str2double(get(handles.std_epoch1_doy,'String'));
    sod1o = str2double(get(handles.std_epoch1_sod,'String'));
    mjd1o = cal2jd(yr1o,1,0) - 2400000.5 + doy1o + sod1o/86400;
    yreo  = str2double(get(handles.std_epoch2_year,'String'));
    doyeo = str2double(get(handles.std_epoch2_doy,'String'));
    sodeo = str2double(get(handles.std_epoch2_sod,'String')); 
    mjdeo = cal2jd(yreo,1,0) - 2400000.5 + doyeo + sodeo/86400;
    % Check common periods
    if mjd1 > mjdeo || mjde < mjd1o
        close(h)
        set(handles.std_status_text,'String','Error: No common data period found with ZTD/ZWD/Gradients data');
        return
    end
    % Set new time parameters
    if mjd1 > mjd1o
        [yr1,doy1,sod1] = mjd2doy(mjd1);
        set(handles.std_epoch1_year,'String',sprintf('%4.4d',yr1));
        set(handles.std_epoch1_doy,'String',sprintf('%3.3d',doy1));
        set(handles.std_epoch1_sod,'String',sprintf('%d',sod1));
    end
    if mjde < mjdeo
        [yr2,doy2,sod2] = mjd2doy(mjde);
        set(handles.std_epoch2_year,'String',sprintf('%4.4d',yr2));
        set(handles.std_epoch2_doy,'String',sprintf('%3.3d',doy2));
        set(handles.std_epoch2_sod,'String',sprintf('%d',sod2));
    end
    % Compute temporal resolution
    epochs = unique(handles.std_input3_data(2,:));
    handles.std_res_rate = round(median(epochs(2:end)-epochs(1:end-1))*86400);
    % Set further parameter
    set(handles.std_status_text,'String','Observation residuals loaded! Elevation, azimuth and sampling rate are read from file.')
    set(handles.std_output_button3,'Enable','on','Value',1);
    set(handles.std_rate_edit,'String',sprintf('%d',handles.std_res_rate),'BackgroundColor',[1 1 1],'Enable','Inactive');
    set(handles.std_res_edit,'String','file');
    set(handles.std_gradn_edit,'String','file');
    set(handles.std_grade_edit,'String','file');
    set(handles.std_elev_edit,'String','file');
    set(handles.std_azi_edit,'String','file');
    close(h);
end
guidata(hObject, handles);

% ---------------------------- ZWD switch --------------------------------
function std_delay_switch_Callback(hObject, eventdata, handles)
out = get(handles.std_output_com,'String');
%set(handles.std_output_com,'String',[handles.out_path_swd str{1}(1:end-4) '.SWD']);
if get(hObject,'Value') == 1
    set(handles.std_output_button1,'String','isotropic SWD');
    set(handles.std_output_button2,'String','non-isotropic SWD (+Gradients)');
    set(handles.std_output_button3,'String','non-isotropic SWD (+Gradients, +Res)');
    set(handles.std_output_switch,'Enable','off');
    out = [out(1:end-3) 'SWD']; %out = strrep(out,'STD','SWD');
    set(handles.std_output_com,'String',out);     
else
    set(handles.std_output_button1,'String','isotropic STD');
    set(handles.std_output_button2,'String','non-isotropic STD (+Gradients)');
    set(handles.std_output_button3,'String','non-isotropic STD (+Gradients, +Res)');
    set(handles.std_output_switch,'Enable','on');
    out = [out(1:end-3) 'STD']; %out = strrep(out,'SWD','STD');
    set(handles.std_output_com,'String',out);  
end
guidata(hObject, handles);

% ---------------------- Output format switch ----------------------------
function std_output_switch_Callback(hObject, eventdata, handles)
out = get(handles.std_output_com,'String');
if get(hObject,'Value') == 0
    if get(handles.std_delay_switch,'Value') == 0
        out = [out(1:end-3) 'STD'];        
    else
        out = [out(1:end-3) 'SWD']; 
    end
    set(handles.std_delay_switch,'Enable','on');
else
    out = [out(1:end-3) 'SNX']; 
    set(handles.std_delay_switch,'Enable','off');
end
set(handles.std_output_com,'String',out);
    
% ---------------------------- Output buttongroup switch -----------------
function std_output_buttongroup_SelectionChangeFcn(hObject, eventdata, handles)
switch get(get(handles.std_output_buttongroup,'SelectedObject'),'Tag')
    case 'std_output_button1'
        set(handles.std_gradn_edit,'String','0')
        set(handles.std_grade_edit,'String','0') 
        set(handles.std_rate_edit,'String','0')  
        set(handles.std_res_edit,'String','0') 
        set(handles.std_elev_edit,'String','5')
        set(handles.std_azi_edit,'String','0')
    case 'std_output_button2'
        set(handles.std_gradn_edit,'String','file')
        set(handles.std_grade_edit,'String','file')
        set(handles.std_rate_edit,'String','0')  
        set(handles.std_res_edit,'String','0') 
        set(handles.std_elev_edit,'String','5')
        set(handles.std_azi_edit,'String','0')            
    case 'std_output_button3'
        set(handles.std_gradn_edit,'String','file')
        set(handles.std_grade_edit,'String','file')
        set(handles.std_rate_edit,'String',sprintf('%d',handles.std_res_rate))  
        set(handles.std_res_edit,'String','file') 
        set(handles.std_elev_edit,'String','file')
        set(handles.std_azi_edit,'String','file')            
end

% ---------------------------- Select Stations ---------------------------
function std_station_headline_CreateFcn(hObject, eventdata, handles)

function std_station_list_Callback(hObject, eventdata, handles)
% Set the limit of files which can be selected
set(hObject,'min',0,'max',300);
guidata(hObject, handles);

function std_station_list_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ---------------------- Mapping function --------------------------------
function std_mapping_popup_Callback(hObject, eventdata, handles)

function std_mapping_popup_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ---------------------- Elevation angle ---------------------------------
function std_elev_edit_Callback(hObject, eventdata, handles)

function std_elev_edit_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(handles.std_elev_edit)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function std_elev_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ---------------------- Azimuth angle -----------------------------------
function std_azi_edit_Callback(hObject, eventdata, handles)

function std_azi_edit_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(handles.std_azi_edit)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function std_azi_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ------------------------- Residuals ------------------------------------
function std_res_edit_Callback(hObject, eventdata, handles)

function std_res_edit_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(handles.std_res_edit)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function std_res_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ------------------------- N-Gradient -----------------------------------
function std_gradn_edit_Callback(hObject, eventdata, handles)

function std_gradn_edit_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(handles.std_gradn_edit)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function std_gradn_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ------------------------- E-Gradient -----------------------------------
function std_grade_edit_Callback(hObject, eventdata, handles)

function std_grade_edit_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(handles.std_grade_edit)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function std_grade_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ---------------------- Sampling rate -----------------------------------
function std_rate_edit_Callback(hObject, eventdata, handles)

function std_rate_edit_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(handles.std_rate_edit)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function std_rate_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ---------------------------- Epoch panel -------------------------------
% ---------------------------- Start epoch -------------------------------
function std_epoch1_year_Callback(hObject, eventdata, handles)

function std_epoch1_year_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(handles.std_epoch1_year)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function std_epoch1_year_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function std_epoch1_doy_Callback(hObject, eventdata, handles)

function std_epoch1_doy_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(handles.std_epoch1_doy)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function std_epoch1_doy_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function std_epoch1_sod_Callback(hObject, eventdata, handles)

function std_epoch1_sod_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(handles.std_epoch1_sod)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function std_epoch1_sod_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ---------------------------- Last epoch --------------------------------
function std_epoch2_year_Callback(hObject, eventdata, handles)

function std_epoch2_year_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(handles.std_epoch2_year)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function std_epoch2_year_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function std_epoch2_doy_Callback(hObject, eventdata, handles)

function std_epoch2_doy_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(handles.std_epoch2_doy)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function std_epoch2_doy_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function std_epoch2_sod_Callback(hObject, eventdata, handles)

function std_epoch2_sod_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(handles.std_epoch2_sod)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function std_epoch2_sod_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ------------------------ Allow extrapolation ---------------------------
function std_extrap_switch_Callback(hObject, eventdata, handles)

% ------------------------ Output file name ------------------------------
function std_output_com_Callback(hObject, eventdata, handles)

function std_output_com_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function std_output_com_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(handles.std_output_com)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

% --------------------------- Check Input --------------------------------
function check_nan(str,fct)
global check_in
if ~isnan(str2double(str))
    set(fct,'BackgroundColor',[1 1 1],'Enable','Inactive');
elseif strcmp(str,'file')
    set(fct,'BackgroundColor',[1 1 1],'Enable','Inactive');
else
    check_in = 0;
    set(fct,'BackgroundColor',[0.94 0.87 0.87],'Enable','On');
end

% --------------------------- Compute STD/SWD -----------------------------
function std_output_save_Callback(hObject, eventdata, handles)
% Check data and settings
global check_in
check_in = 1;
% Station selected?
sta  = get(handles.std_station_list,'String');
nsta = get(handles.std_station_list,'Value');
if isequal(sta,'No station'); check_in = 0; end
% Coordinates available?
str = get(handles.std_input2_list,'String');
if length(str) ~= length(nsta); check_in = 0; end
if isequal(str,''); check_in = 0; end
if check_in == 0; set(handles.std_status_text,'String','Error, load coordinate file!'); return; end    
% Sampling rate set?
str = get(handles.std_rate_edit,'String');
check_nan(str,handles.std_rate_edit);
if strcmp(str,'0'), check_in = 0; end
if get(handles.std_output_button3,'Value') == 0 && strcmp(str,'file'); check_in = 0; end
if check_in == 0; set(handles.std_status_text,'String','Error, set correct sampling rate!'); return; end  
% Year1 ?
str = get(handles.std_epoch1_year,'String');
check_nan(str,handles.std_epoch1_year);
% Year2 ?
str = get(handles.std_epoch2_year,'String');
check_nan(str,handles.std_epoch2_year);
% DoY1 ?
str = get(handles.std_epoch1_doy,'String');
check_nan(str,handles.std_epoch1_doy);
% DoY2 ?
str = get(handles.std_epoch2_doy,'String');
check_nan(str,handles.std_epoch2_doy);
% SoD1 ?
str = get(handles.std_epoch1_sod,'String');
check_nan(str,handles.std_epoch1_sod);
% SoD2 ?
str = get(handles.std_epoch2_sod,'String');
check_nan(str,handles.std_epoch2_sod);
% Elevation ?
str = get(handles.std_elev_edit,'String');
check_nan(str,handles.std_elev_edit);
if check_in == 0; set(handles.std_status_text,'String','Error, set correct elevation angle!'); return; end 
% Azimuth ?
str = get(handles.std_azi_edit,'String');
check_nan(str,handles.std_azi_edit);
if check_in == 0; set(handles.std_status_text,'String','Error, set correct azimuth angle!'); return; end 
% Get time parameters
yra  = str2double(get(handles.std_epoch1_year,'String'));
doya = str2double(get(handles.std_epoch1_doy,'String'));
soda = str2double(get(handles.std_epoch1_sod,'String'));
mjda = cal2jd(yra,1,0) - 2400000.5 + doya + soda/86400;
yre  = str2double(get(handles.std_epoch2_year,'String'));
doye = str2double(get(handles.std_epoch2_doy,'String'));
sode = str2double(get(handles.std_epoch2_sod,'String')); 
mjde = cal2jd(yre,1,0) - 2400000.5 + doye + sode/86400;
% Tolerance parameter [1s]
tol = 1/86400; 
% Start processing
if check_in == 1
    % Create waitbar
    h = waitbar(0,'Please wait...','WindowStyle','modal');
    % Read output file name    
    fout = get(handles.std_output_com,'String');
    set(handles.std_output_com,'BackgroundColor',[1 1 1],'Enable','Inactive');
    % Get full list of stations
    stat = handles.std_input1_sta_full;
    % Open output file name
    out = fopen(fout,'w');
    % Extrapolation yes/no in interp1
    if get(handles.std_extrap_switch,'Value') == 0
        % No extrapolation
        inter_txt = NaN;
    else
        % Extrapolation allowed
        inter_txt = 'extrap';
    end
    status_text = 'Done! Check output file';  
    % Loop over all stations of interest (defined in "std_station_list")    
    for i = 1:length(nsta)        
        % Counter variable for storage
        n_zd = 1; n_sd = 1;
        % Initialise output variable
        out_sd = {}; out_zd = {};
        % Fill wait bar
        waitbar(i/length(nsta),h);
        % Find station entries
        id = strcmp(stat,sta(nsta(i)));
        % Get dates
        mjd0 = handles.std_input1_data(id,1);
        % Delete double entries
        n = hist(mjd0, unique(mjd0));
        i_double = find(n>1);
        if ~isempty(i_double)
            for j = 1:length(i_double)
                id(max(find(id == 1,i_double(j)))) = 0;
            end
        end
        % Get reduced data (mjd, ztd / zwd) without double entries
        mjd0 = handles.std_input1_data(id,1);        
        % Get station coordinates
        ell = handles.std_input2_crd(i,:);      
        % Check end delete double entries
        %[mjd0,b,c] = unique(mjd0)
        % Get corresponding zenith tropospheric delays
        zd_i = strcmp(handles.std_input1_cont,'ZTD [mm]');
        if any(zd_i) == 1
            zd0 = handles.std_input1_data(id,zd_i);
        else
            set(handles.std_status_text,'String','No ZTD found in input file');
            close(h); return;
        end
        % Initialise precision measurements (StdDev [mm] for ZTD, GN and GE)
        stdd   = zeros(length(mjd0),3);
        stdd_i = find(strcmp(handles.std_input1_cont,'StdDev [mm]'));       
        
        % Get ZWD (if available)
        zwd_i = find(strcmp(handles.std_input1_cont,'ZWD [mm]'));
        zwd0  = zeros(length(mjd0),1);
        if ~isempty(zwd_i)
            zwd0 = handles.std_input1_data(id,zwd_i);
        end
        % Check if at least 2 epochs per stations are available
        if length(mjd0) >= 2 && length(zd0) >= 2
            % STD output option (std_i)
            % 1 ... isotropic STD / SWD
            % 2 ... non-isotropic STD /SWD (+Gradients)
            % 3 ... non-isotropic STD /SWD (+Gradients, +Res)          
            switch get(get(handles.std_output_buttongroup,'SelectedObject'),'Tag')
                case 'std_output_button1'
                    % Output option
                    std_i = 1;
                    % Elevation angle
                    str = get(handles.std_elev_edit,'String');
                    check_nan(str,handles.std_elev_edit);
                    if check_in == 1
                        ele = str2double(get(handles.std_elev_edit,'String'));
                    else
                        ele = 0;
                        set(handles.std_status_text,'String','Elevation angle set to Zero');
                    end
                    check_in = 1;
                    % Azimuth angle
                    str = get(handles.std_azi_edit,'String');
                    check_nan(str,handles.std_azi_edit);
                    if check_in == 1
                        azi = str2double(get(handles.std_azi_edit,'String'));
                    else
                        azi = 0;
                        set(handles.std_status_text,'String','Azimuth angle set to Zero');
                    end
                    check_in = 1;
                    % Sampling rate (dt) / Period (mjd1)
                    dt = str2double(get(handles.std_rate_edit,'String'));
                    mjd = mjda:dt/86400:mjde;
                    % Interpolated zd time series
                    zd  = interp1(mjd0,zd0,mjd,'linear',inter_txt);
                    zwd = interp1(mjd0,zwd0,mjd,'linear',inter_txt);
                    % Gradients
                    gn = zeros(length(zd),1);
                    ge = zeros(length(zd),1);
                    % Satellite PRN
                    sat = 'NO';
                    % Observation residuals                
                    res = zeros(length(zd),1); 
                    % Get precision measurements
                    if ~isempty(stdd_i)
                        stdd(:,1) = handles.std_input1_data(id,stdd_i(1));
                    end
                    
                case 'std_output_button2'
                    % Output option
                    std_i = 2;
                    % Elevation angle
                    str = get(handles.std_elev_edit,'String');
                    check_nan(str,handles.std_elev_edit);
                    if check_in == 1
                        ele = str2double(get(handles.std_elev_edit,'String'));
                    else
                        ele = 0;
                        set(handles.std_status_text,'String','Elevation angle set to Zero');
                    end
                    check_in = 1;
                    % Azimuth  angle
                    str = get(handles.std_azi_edit,'String');
                    check_nan(str,handles.std_azi_edit);
                    if check_in == 1
                        azi = str2double(get(handles.std_azi_edit,'String'));
                    else
                        azi = 0;
                        set(handles.std_status_text,'String','Azimuth angle set to Zero');
                    end
                    check_in = 1;
                    % Sampling rate (dt) / Period (mjd1)
                    dt = str2double(get(handles.std_rate_edit,'String'));
                    mjd = mjda:dt/86400:mjde;
                    % Interpolated ztd time series
                    zd  = interp1(mjd0,zd0,mjd,'linear',inter_txt);
                    zwd = interp1(mjd0,zwd0,mjd,'linear',inter_txt);
                    % N_menu-Gradients 
                    str = get(handles.std_gradn_edit,'String');
                    if strcmp(str,'file')
                        gn_i = strcmp(handles.std_input1_cont,'N-Gradient [mm]');              
                        set(handles.std_gradn_edit,'BackgroundColor',[1 1 1],'Enable','Inactive');
                        if any(gn_i) == 1
                            % Read gradients from SINEX TRO
                            gn0 = handles.std_input1_data(id,gn_i);
                        else
                            gn0 = zeros(length(zd0),1);
                            set(handles.std_status_text,'String','N-Gradients not available, set to Zero');
                        end
                    else
                        check_nan(str,handles.std_gradn_edit);
                        if check_in == 1
                            gn0 = zeros(length(zd0),1) + str2double(str);
                        else
                            gn0 = zeros(length(zd0),1);
                            set(handles.std_status_text,'String','N-Gradient set to Zero');
                        end
                        check_in = 1;
                    end
                    % E-Gradients
                    str = get(handles.std_grade_edit,'String');
                    if strcmp(str,'file')
                        ge_i = strcmp(handles.std_input1_cont,'E-Gradient [mm]');
                        set(handles.std_grade_edit,'BackgroundColor',[1 1 1],'Enable','Inactive');
                        if any(ge_i)==1
                            % Read gradients from SINEX TRO
                            ge0 = handles.std_input1_data(id,ge_i);
                        else
                            ge0 = zeros(length(zd0),1);
                            set(handles.std_status_text,'String','E-Gradients not available, set to Zero');
                        end
                    else
                        check_nan(str,handles.std_grade_edit);
                        if check_in == 1
                            ge0 = zeros(length(zd0),1) + str2double(str);
                        else
                            ge0 = zeros(length(zd0),1);
                            set(handles.std_status_text,'String','E-Gradient set to Zero')
                        end
                        check_in = 1;
                    end  
                    % Interpolated gradient time series                
                    gn = interp1(mjd0,gn0,mjd,'linear',inter_txt);
                    ge = interp1(mjd0,ge0,mjd,'linear',inter_txt);
                    % Satellite PRN
                    sat = 'NO';
                    % Observation residuals
                    res = zeros(length(zd),1);
                    set(handles.std_res_edit,'BackgroundColor',[1 1 1],'Enable','Inactive');
                    % Get precision measurements
                    if ~isempty(stdd_i)
                        for n = 1:length(stdd_i)
                            stdd(:,n) = handles.std_input1_data(id,stdd_i(n));
                        end
                    end

                case 'std_output_button3'
                    % Output option
                    std_i = 3;                    
                    % Get rate from user in GUI
                    rate_set = str2double(get(handles.std_rate_edit,'String'));
                    % Combine with rate from residual file
                    m_rate = round(rate_set/handles.std_res_rate);
                    % Define rate (as multiple of residual rate)
                    if m_rate >= 1
                        rate = m_rate*handles.std_res_rate;
                    else
                        rate = handles.std_res_rate;
                    end
                    % Set rate in GUI
                    set(handles.std_rate_edit,'String',sprintf('%d',rate));
                    
                    % Find station in residual file
                    id_s = find(strcmp(handles.std_input3_stat,sta(nsta(i))));
                    mjd1 = handles.std_input3_data(2,id_s);
                    % Get period of interest (mjd_rate)
                    id_ta = find(mjd1 >= mjda-tol); id_te = find(mjd1 <= mjde+tol);
                    if ~isempty(id_ta) && ~isempty(id_te)
                        id_t  = intersect(id_ta,id_te);
                    else                        
                        status_text = sprintf('Error: No residuals found for selected period (%s)',sta{nsta(i)});
                        %out_sd = {};
                        continue;
                    end   
                    if isempty(id_t)
                        continue;
                    end
                    mjd_rate = mjda:rate/86400:max(mjd1(id_t));
                    % Find entries (id_t) within the selected period
                    id_r = [];
                    for r = 1:length(mjd_rate)                        
                        id_r = [id_r,find(abs(mjd1-mjd_rate(r))<tol)];
                    end
                    % Extract mjds of interest (mjd)
                    mjd = mjd1(id_r);
                    % Compute ztd for epochs in mjd1
                    zd  = interp1(mjd0,zd0,mjd,'linear',inter_txt);
                    zwd = interp1(mjd0,zwd0,mjd,'linear',inter_txt);
                    % N-Gradients 
                    str = get(handles.std_gradn_edit,'String');
                    if strcmp(str,'file')
                        gn_i = strcmp(handles.std_input1_cont,'N-Gradient [mm]');                    
                        set(handles.std_gradn_edit,'BackgroundColor',[1 1 1],'Enable','Inactive');
                        if any(gn_i) == 1
                            % Read gradients from SINEX TRO
                            gn0 = handles.std_input1_data(id,gn_i);
                        else
                            gn0 = zeros(length(zd0),1);
                            set(handles.std_status_text,'String','N-Gradients not available, set to Zero');
                        end
                    else
                        check_nan(str,handles.std_gradn_edit);
                        if check_in == 1
                            gn0 = zeros(length(zd0),1) + str2double(str);
                        else
                            gn0 = zeros(length(zd0),1);
                            set(handles.std_status_text,'String','N-Gradient set to Zero')
                        end
                        check_in = 1;
                    end
                    % E-Gradients
                    str = get(handles.std_grade_edit,'String');
                    if strcmp(str,'file')
                        ge_i = strcmp(handles.std_input1_cont,'E-Gradient [mm]');
                        set(handles.std_grade_edit,'BackgroundColor',[1 1 1],'Enable','Inactive');
                        if any(ge_i)==1
                            % Read gradients from SINEX TRO
                            ge0 = handles.std_input1_data(id,ge_i);
                        else
                            ge0 = zeros(length(zd0),1);
                            set(handles.std_status_text,'String','E-Gradients not available, set to Zero')
                        end
                    else
                        check_nan(str,handles.std_grade_edit);
                        if check_in == 1
                            ge0 = zeros(length(zd0),1) + str2double(str);
                        else
                            ge0 = zeros(length(zd0),1);
                            set(handles.std_status_text,'String','E-Gradient set to Zero')
                        end
                        check_in = 1;
                    end                
                    % Interpolated gradient time series
                    gn = interp1(mjd0,gn0,mjd,'linear',inter_txt);
                    ge = interp1(mjd0,ge0,mjd,'linear',inter_txt);
                    % Elevation angle
                    ele = handles.std_input3_data(3,id_s(id_r));  
                    % Azimuth  angle (0� == north direction)
                    azi = handles.std_input3_data(4,id_s(id_r));                 
                    % Satellite PRN
                    sat = handles.std_input3_sat(id_s(id_r));
                    % Observation residuals
                    str = get(handles.std_res_edit,'String');
                    if strcmp(str,'file')
                        set(handles.std_res_edit,'BackgroundColor',[1 1 1],'Enable','Inactive');
                        res = handles.std_input3_data(1,id_s(id_r));
                    else
                        check_nan(str,handles.std_res_edit);
                        if check_in == 1
                            res = zeros(length(zd),1) + str2double(str);
                        else
                            res = zeros(length(zd),1);
                            set(handles.std_status_text,'String','Residuals set to Zero')
                        end
                    end
                    % Status text
                    if rate ~= rate_set
                        status_text = sprintf('Done! Rate was set to %d sec, Check output file',rate);
                    end
            end
            
            % Get e,T for GPT2w_mod * not fully implemented yet *
            map_i = get(handles.std_mapping_popup,'Value');
            if map_i == 4
                e_i = strcmp(handles.std_input1_cont,'WV pressure [hPa]');
                if any(e_i) == 1
                    e0 = handles.std_input1_data(id,e_i);
                else
                    close(h)
                    set(handles.std_status_text,'String','Error: For GPT2w_mod load *.ZWD file with meteo parameters')
                    return
                end                
                T_i = strcmp(handles.std_input1_cont,'Temperaure [�C]');
                if any(T_i) == 1
                    T0 = handles.std_input1_data(id,T_i);                    
                end          
            else
                e0 = zeros(length(zd0),1);
                T0 = zeros(length(zd0),1);
            end            
            % Interpolated time series
            e = interp1(mjd0,e0,mjd,'linear',inter_txt);
            T = interp1(mjd0,T0,mjd,'linear',inter_txt);
            
            % Compute STD / SWD
            if get(handles.std_delay_switch,'Value') == 0
                [shd,swd,mfh,mfw,maz] = ZTD2STD(mjd,zd,zwd,gn,ge,res,ele,azi,ell,e,T,std_i,map_i);        
            else
                [shd,swd,mfh,mfw,maz] = ZWD2SWD(mjd,zwd,gn,ge,res,ele,azi,ell,e,T,std_i,map_i);
            end   
            
            % Store data string in out_sd to write SWD/STD file
            if get(handles.std_output_switch,'Value') == 0
                if std_i == 1 || std_i == 2
                    for k = 1:length(shd)
                        if ~isnan(swd(k))
                            out_sd{n_sd} = sprintf('%11.5f %4s %3s %8.4f %8.4f %9.4f\n',mjd(k),sta{nsta(i)},sat,(shd(k)+swd(k))/1000,ele,azi);
                            n_sd = n_sd + 1;
                        end
                    end
                % Write statellite PRN (according to residual/aer file)    
                elseif std_i == 3
                    for k = 1:length(shd)
                        if ~isnan(swd(k))
                            prn = satid2prn(sat{k});
                            out_sd{n_sd} = sprintf('%11.5f %4s %3s %8.4f %8.4f %9.4f\n',mjd(k),sta{nsta(i)},prn,(shd(k)+swd(k))/1000,ele(k),azi(k));
                            n_sd = n_sd + 1;
                        end
                    end
                end
            % Store data string in out_zd and out_sd to write SINEX file
            else
                % Get precision measurements
                if ~isempty(stdd_i)
                    for n = 1:length(stdd_i)
                        stdd(:,n) = handles.std_input1_data(id,stdd_i(n));
                    end
                end
                % Compute ZTD, GE, GN precisons for each epoch
                stdd1 = interp1(mjd0,stdd(:,1),mjd,'linear',inter_txt);
                stdd2 = interp1(mjd0,stdd(:,2),mjd,'linear',inter_txt);
                stdd3 = interp1(mjd0,stdd(:,3),mjd,'linear',inter_txt);
                % Get ZHD and ZWD (if zero)
                if get(handles.std_delay_switch,'Value') == 0
                    zhd = shd./mfh;
                    if unique(zwd) == 0, zwd = zd'-zhd; end
                end
                % Zenith data
                time = unique(mjd);
                for l = 1:length(unique(mjd))
                    % Select first entry if the same time step is more often available
                    k = find(mjd == time(l),1);
                    [yr,doy,sod] = mjd2doy(mjd(k));
                    if ~isnan(zd(k))
                        out_zd{n_zd} = sprintf(' %4s %2.2d:%3.3d:%5.5d %9.1f %9.1f %9.3f %9.3f %9.3f %9.3f %9.1f %9.1f %9d %9.1f\n',sta{nsta(i)},yr-2000,doy,sod,zd(k),stdd1(k),gn(k),stdd2(k),ge(k),stdd3(k),zhd(k),zwd(k),0,0);
                        n_zd = n_zd + 1;
                    end
                end
                % Slant data
                for k = 1:length(swd)
                    if ~isnan(swd(k))
                        % MJD to DoY
                        [yr,doy,sod] = mjd2doy(mjd(k));
                        % Get Satellite PRN
                        if std_i == 1 || std_i == 2
                            prn = 'No';
                            out_sd{n_sd} = sprintf(' %4s %2.2d:%3.3d:%5.5d %9.1f %9.1f %9.1f %9.1f %9.1f %9.1f %9.3f %9.3f %9s %9.5f %9.5f %9.4f\n',sta{nsta(i)},yr-2000,doy,sod,swd(k)+shd(k),0,res(k),shd(k),swd(k),0,ele,azi,prn,mfh(k),mfw(k),maz(k));
                        elseif std_i == 3
                            prn = satid2prn(sat{k});                    
                            out_sd{n_sd} = sprintf(' %4s %2.2d:%3.3d:%5.5d %9.1f %9.1f %9.1f %9.1f %9.1f %9.1f %9.3f %9.3f %9s %9.5f %9.5f %9.4f\n',sta{nsta(i)},yr-2000,doy,sod,swd(k)+shd(k),0,res(k),shd(k),swd(k),0,ele(k),azi(k),prn,mfh(k),mfw(k),maz(k));
                        end       
                        n_sd = n_sd + 1;
                    end
                end        
            end 
            check_in = 1;
            clear mjd0 mjd zd gn ge res ele azi ell std_i e T id_t id stdd
        else
            set(handles.std_status_text,'String',['Error: Too less ZTD/ZWD available for station ' sta{nsta(i)}]);
        end
        % Write output file - SWD/STD
        if get(handles.std_output_switch,'Value') == 0
            for l = 1:length(out_sd)
                fprintf(out,out_sd{l});
            end        
        % Write output file - SINEX SNX    
        else
            % Write Output file - Header
            % Current date
            t = clock; mjdn = date2mjd(t(1),t(2),t(3),t(4),t(5),t(6)); [yrn,doyn,sodn] = mjd2doy(mjdn);
            % First lines
            fprintf(out,'%s=TRO 0.09 TUW %2.2d:%3.3d:%5.5d TUW %2.2d:%3.3d:%5.5d %2.2d:%3.3d:%5.5d P  MIX\n','%',yrn-2000,doyn,sodn,yra-2000,doya,soda,yre-2000,doye,sode);
            fprintf(out,'*-------------------------------------------------------------------------------\n');        
            % SNX Header file
            fheader = fopen([pwd '\Slant_Fcn\SNX_Header.txt'],'r');
            while ~feof(fheader)
                line = fgets(fheader);
                fprintf(out,line);
            end
            fclose(fheader);
            % Write Output file - Zenith Delays
            % TROP/SOLUTION block
            fprintf(out,'+TROP/SOLUTION\n');
            fprintf(out,'*SITE ____EPOCH___  TROTOT    STDDEV    TGNTOT    STDDEV    TGETOT    STDDEV    TROHYD    TROWET    NSAT      GDOP\n');
            for l = 1:length(out_zd)
                fprintf(out,out_zd{l});
            end
            fprintf(out,'-TROP/SOLUTION\n');
            fprintf(out,'*-------------------------------------------------------------------------------\n');    
            % Write Output file - Slant Delays
            fprintf(out,'+SLANT/SOLUTION\n');
            fprintf(out,'*SITE ____EPOCH___  SL_TOT    STDDEV    SL_RES    SL_HYD    SL_WET    SL_MPT    SL_ELE    SL_AZI    SAT_ID    MF_HYD    MF_WET    MF_GRD\n');
            for l = 1:length(out_sd)
                fprintf(out,out_sd{l});
            end
            fprintf(out,'-SLANT/SOLUTION\n');
            fprintf(out,'%s=ENDTRO\n','%');
        end    
        clear out_zd out_sd
    end
    % Close Output file and waitbar (h)
    fclose(out);
    close(h)
end
% Set status text
set(handles.std_status_text,'String',status_text); 

% --------------------------- Show data ----------------------------------
function std_data_show_Callback(hObject, eventdata, handles)
% File name
fname = get(handles.std_output_com,'String');
% Read and store data
fid = fopen(fname,'r');
if fid > 0
    if strcmp(fname(end-2:end),'STD') || strcmp(fname(end-2:end),'SWD')
        dat = textscan(fid,'%f %4c %s %f %f %f');
        handles.std_show_data = [cellstr(num2str(dat{1},'%11.5f')),cellstr(dat{2}),...
            cellstr(dat{3}),cellstr(num2str(dat{4},'%8.4f')),...
            cellstr(num2str(dat{5},'%6.4f')),cellstr(num2str(dat{6},'%7.4f'))];
        if get(handles.std_delay_switch,'Value') == 0
            handles.std_show_cont = {'MJD';'Station';'PRN';'STD [m]';'Elev [�]';'Azim [�]'};
        else
            handles.std_show_cont = {'MJD';'Station';'PRN';'SWD [m]';'Elev [�]';'Azim [�]'};
        end
        set(handles.std_data_table,'Data',handles.std_show_data);        
    elseif strcmp(fname(end-2:end),'SNX')
        set(handles.std_status_text,'String','Preview not available for SINEX TRO files');
        return
    end
    set(handles.std_data_table,'ColumnName',handles.std_show_cont);
    fclose(fid);
else
    set(handles.std_status_text,'String','Output file does not exist');
end
set(handles.std_status_text,'String',sprintf('Data loaded from %s',fname));
guidata(hObject, handles);

% --------------------------- Clear all ----------------------------------
function std_clear_all_Callback(hObject, eventdata, handles)
% Reset
set(handles.std_epoch1_year,'String','year');
set(handles.std_epoch1_doy,'String','doy');
set(handles.std_epoch1_sod,'String','sod');
set(handles.std_epoch2_year,'String','year')
set(handles.std_epoch2_doy,'String','doy'); 
set(handles.std_epoch2_sod,'String','sod');
set(handles.std_rate_edit,'String','sec');
set(handles.std_res_edit,'String','0');
set(handles.std_gradn_edit,'String','0');
set(handles.std_grade_edit,'String','0');
set(handles.std_elev_edit,'String','5');
set(handles.std_azi_edit,'String','0');

set(handles.std_res_edit,'String','0');
set(handles.std_gradn_edit,'String','0');
set(handles.std_grade_edit,'String','0');

set(handles.std_output_com,'BackgroundColor',[1 1 1]);
set(handles.std_epoch1_year,'BackgroundColor',[1 1 1]);
set(handles.std_epoch1_doy,'BackgroundColor',[1 1 1]);
set(handles.std_epoch1_sod,'BackgroundColor',[1 1 1]);
set(handles.std_epoch2_year,'BackgroundColor',[1 1 1]);
set(handles.std_epoch2_doy,'BackgroundColor',[1 1 1]);
set(handles.std_epoch2_sod,'BackgroundColor',[1 1 1]);
set(handles.std_rate_edit,'BackgroundColor',[1 1 1]);
set(handles.std_res_edit,'BackgroundColor',[1 1 1]);
set(handles.std_gradn_edit,'BackgroundColor',[1 1 1]);
set(handles.std_grade_edit,'BackgroundColor',[1 1 1]);
set(handles.std_elev_edit,'BackgroundColor',[1 1 1]);
set(handles.std_azi_edit,'BackgroundColor',[1 1 1]);

set(handles.std_input1_list,'String','No file');
set(handles.std_input1_list,'Value',1);
set(handles.std_input2_filename,'String','No file');
set(handles.std_input2_list,'String','');
set(handles.std_input2_list,'Value',1);
set(handles.std_input3_list,'String','No file');
set(handles.std_input3_list,'Value',1);
set(handles.std_station_list,'String','No station');
set(handles.std_station_list,'Value',1);

set(handles.std_output_button1,'Value',1);
set(handles.std_output_button3,'Enable','off');
set(handles.std_output_com,'String','');
set(handles.std_output_com,'Enable','Inactive');
set(handles.std_epoch1_year,'Enable','Inactive');
set(handles.std_epoch1_doy,'Enable','Inactive');
set(handles.std_epoch1_sod,'Enable','Inactive');
set(handles.std_epoch2_year,'Enable','Inactive');
set(handles.std_epoch2_doy,'Enable','Inactive');
set(handles.std_epoch2_sod,'Enable','Inactive');
set(handles.std_rate_edit,'Enable','Inactive');
set(handles.std_res_edit,'Enable','Inactive');
set(handles.std_gradn_edit,'Enable','Inactive');
set(handles.std_grade_edit,'Enable','Inactive');

set(handles.std_data_table,'Data',[]);
set(handles.std_data_table,'ColumnName','');

% Initialise variables
handles.std_input3_data = [];
handles.std_input3_stat = [];
handles.std_input3_sat  = [];
guidata(hObject, handles);


%% ------------------------ Panel Refractivity ---------------------------
%% ------------------------ Sub-panel N (a priori) -----------------------
% ------------------------------------------------------------------------
function uipanel_N_apr_CreateFcn(hObject, eventdata, handles)

% ---------------------------- Points of Interest ------------------------
function N_apr_buttongroup1_SelectionChangeFcn(hObject, eventdata, handles)
handles = guidata(hObject); 
switch get(eventdata.NewValue,'Tag') 
    case 'N_apr_POI_button1'
        set(handles.N_apr_input3_headline,'Enable','off')
        set(handles.N_apr_input3_open,'Enable','off')
        set(handles.N_apr_input3_load,'Enable','off')
        set(handles.N_apr_input3_list,'Enable','off')
        set(handles.N_apr_station_headline,'Enable','off')
        set(handles.N_apr_station_list,'Enable','off')
        set(handles.N_apr_model_lat1,'Enable','inactive')
        set(handles.N_apr_model_lat2,'Enable','inactive')
        set(handles.N_apr_model_lon1,'Enable','inactive')
        set(handles.N_apr_model_lon2,'Enable','inactive')        
        set(handles.N_apr_model_dlat,'Enable','inactive')
        set(handles.N_apr_model_dlon,'Enable','inactive')
        set(handles.N_apr_height_model_par1,'Enable','inactive')
        set(handles.N_apr_height_model_par2,'Enable','inactive')
        set(handles.N_apr_height_model_par3,'Enable','inactive')
        set(handles.N_apr_height_model_par4,'Enable','inactive')
        set(handles.N_apr_height_popup,'Value',1)
        set(handles.N_apr_height_popup,'Enable','on')
        if strcmp(get(get(handles.N_apr_buttongroup2,'SelectedObject'),'Tag'),'N_apr_source_button1')
            set(handles.N_apr_outer_voxel_model,'Enable','on')            
        end
        set(handles.N_apr_stddev_sel,'Enable','on')
    case 'N_apr_POI_button2'
        set(handles.N_apr_input3_headline,'Enable','on')
        set(handles.N_apr_input3_open,'Enable','on')
        set(handles.N_apr_input3_load,'Enable','on')
        set(handles.N_apr_input3_list,'Enable','inactive')
        set(handles.N_apr_station_headline,'Enable','on')
        set(handles.N_apr_station_list,'Enable','on')
        set(handles.N_apr_model_lat1,'Enable','off')
        set(handles.N_apr_model_lat2,'Enable','off')
        set(handles.N_apr_model_lon1,'Enable','off')
        set(handles.N_apr_model_lon2,'Enable','off')
        set(handles.N_apr_model_dlat,'Enable','off')
        set(handles.N_apr_model_dlon,'Enable','off')
        set(handles.N_apr_height_model_par1,'Enable','off')
        set(handles.N_apr_height_model_par2,'Enable','off')
        set(handles.N_apr_height_model_par3,'Enable','off')
        set(handles.N_apr_height_model_par4,'Enable','off')   
        set(handles.N_apr_height_popup,'Value',3)
        set(handles.N_apr_height_popup,'Enable','off')
        set(handles.N_apr_outer_voxel_model,'Enable','off')
end

% --------------------------- Voxel model --------------------------------
function N_apr_model_lat1_Callback(hObject, eventdata, handles)

function N_apr_model_lat1_ButtonDownFcn(hObject, eventdata, handles)
if strcmp(get(hObject,'Enable'),'inactive'); set(hObject,'Enable','On'); end
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function N_apr_model_lat1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function N_apr_model_lat2_Callback(hObject, eventdata, handles)

function N_apr_model_lat2_ButtonDownFcn(hObject, eventdata, handles)
if strcmp(get(hObject,'Enable'),'inactive'); set(hObject,'Enable','On'); end
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function N_apr_model_lat2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function N_apr_model_dlat_Callback(hObject, eventdata, handles)

function N_apr_model_dlat_ButtonDownFcn(hObject, eventdata, handles)
if strcmp(get(hObject,'Enable'),'inactive'); set(hObject,'Enable','On'); end
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function N_apr_model_dlat_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function N_apr_model_lon1_Callback(hObject, eventdata, handles)

function N_apr_model_lon1_ButtonDownFcn(hObject, eventdata, handles)
if strcmp(get(hObject,'Enable'),'inactive'); set(hObject,'Enable','On'); end
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function N_apr_model_lon1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function N_apr_model_lon2_Callback(hObject, eventdata, handles)

function N_apr_model_lon2_ButtonDownFcn(hObject, eventdata, handles)
if strcmp(get(hObject,'Enable'),'inactive'); set(hObject,'Enable','On'); end
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function N_apr_model_lon2_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function N_apr_model_dlon_Callback(hObject, eventdata, handles)

function N_apr_model_dlon_ButtonDownFcn(hObject, eventdata, handles)
if strcmp(get(hObject,'Enable'),'inactive'); set(hObject,'Enable','On'); end
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function N_apr_model_dlon_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ------------------------ Station coordinates (Input 3) -----------------
function N_apr_input3_open_Callback(hObject, eventdata, handles)
% Read file names
[filename1, handles.N_apr_input3_pathname1] = uigetfile({...
    '*.NEU','NEU coordinate file'},...
    'Select File',handles.atom_start_input,'MultiSelect','on');
% Pass file names to listbox
if isequal(filename1,0)
    set(handles.N_apr_station_list,'Value',1);
    set(handles.N_apr_input3_list,'Value',1)
else    
    set(handles.N_apr_input3_headline,'String',cellstr(filename1));
    set(handles.N_apr_input3_headline,'Value',1)
end
guidata(hObject, handles);

function N_apr_input3_list_Callback(hObject, eventdata, handles)

function N_apr_input3_list_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    %set(hObject,'BackgroundColor','white');
end

function N_apr_input3_load_Callback(hObject, eventdata, handles)
% Read filename
str = get(handles.N_apr_input3_headline,'String');
if strcmp(str,'No file') ~= 1
    % Clear list
    set(handles.N_apr_input3_list,'String','');
    % Set path name of coordinate file   
    fullpathname = strcat(handles.N_apr_input3_pathname1,str{1});
    % Read coordinates from file
    [dat1,dat2] = read_NEU_all(fullpathname,handles);    
    handles.N_apr_input3_crd = dat1;
    handles.N_apr_input3_sta = dat2;
    id = find(dat1 == 0,1);
    if ~isempty(id)
        set(handles.N_apr_status_text,'String','No coordinates found! Please select CRD file with coordinates for all stations')
    else
        set(handles.N_apr_input3_list,'String',dat2);
        set(handles.N_apr_status_text,'String','CRD loaded from file, select station(s) from listbox');
        set(handles.N_apr_input3_list,'Value',[]);
        set(handles.N_apr_station_list,'Value',1)
        set(handles.N_apr_station_list,'String',cellfun(@(x) x(1:5),dat2,'UniformOutput',false))
        set(handles.N_apr_station_headline,'String','Selected: 1');
        if get(handles.N_apr_height_popup,'Value') == 1
            % Compute vertical layers accoring to Perler 2011 with exponential increase
            Hmin = str2double(get(handles.N_apr_height_model_par1,'String'));
            Hmax = str2double(get(handles.N_apr_height_model_par2,'String'));
            q    = str2double(get(handles.N_apr_height_model_par3,'String'));
            dH0  = str2double(get(handles.N_apr_height_model_par4,'String'));
            poi_H = height_model(Hmin,Hmax,q,dH0);
            set(handles.N_apr_height_list,'Value',1)
            set(handles.N_apr_height_list,'String',poi_H);
            set(handles.N_apr_height_model_par1,'BackgroundColor',[1 1 1])
            set(handles.N_apr_height_model_par2,'BackgroundColor',[1 1 1])
            set(handles.N_apr_height_model_par3,'BackgroundColor',[1 1 1])
            set(handles.N_apr_height_model_par4,'BackgroundColor',[1 1 1])
            set(handles.N_apr_height_model_par1,'Enable','inactive')
            set(handles.N_apr_height_model_par2,'Enable','inactive')
            set(handles.N_apr_height_model_par3,'Enable','inactive')
            set(handles.N_apr_height_model_par4,'Enable','inactive') 
        elseif get(handles.N_apr_height_popup,'Value') == 2
            set(handles.N_apr_height_list,'Value',1)
            set(handles.N_apr_height_list,'String','Test');            
        elseif get(handles.N_apr_height_popup,'Value') == 3
            set(handles.N_apr_height_list,'String',['heights read from' str]);
            set(handles.N_apr_height_list,'Value',2);
        end        
    end
    guidata(hObject, handles);
end

% ------------------------ Station list ----------------------------------
function N_apr_station_list_Callback(hObject, eventdata, handles)
% Set the limit of files which can be selected
set(hObject,'min',0,'max',500);
% Use 'Entf to delete entries in listbox
set(hObject,'keypressfcn',@key_check)
% Count number of selected stations
set(handles.N_apr_station_headline,'String',['Selected: ' num2str(length(get(hObject,'Value')))]);
guidata(hObject, handles);

function N_apr_station_list_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ---------------------- Panels for height model ------------------------
function N_apr_height_popup_Callback(hObject, eventdata, handles)
hm_val = get(hObject,'Value');
switch hm_val
    case 1
        Hmin = str2double(get(handles.N_apr_height_model_par1,'String'));
        Hmax = str2double(get(handles.N_apr_height_model_par2,'String'));
        q    = str2double(get(handles.N_apr_height_model_par3,'String'));
        dH0  = str2double(get(handles.N_apr_height_model_par4,'String'));
        poi_H = height_model(Hmin,Hmax,q,dH0);
        set(handles.N_apr_height_list,'Value',1)
        set(handles.N_apr_height_list,'String',poi_H);
        set(handles.N_apr_height_model_par1,'BackgroundColor',[1 1 1])
        set(handles.N_apr_height_model_par2,'BackgroundColor',[1 1 1])
        set(handles.N_apr_height_model_par3,'BackgroundColor',[1 1 1])
        set(handles.N_apr_height_model_par4,'BackgroundColor',[1 1 1])
        set(handles.N_apr_height_model_par1,'Enable','inactive')
        set(handles.N_apr_height_model_par2,'Enable','inactive')
        set(handles.N_apr_height_model_par3,'Enable','inactive')
        set(handles.N_apr_height_model_par4,'Enable','inactive')         
    case 2
        % Check if grib1 data exist and read height layers
        if get(handles.N_apr_opt1_popup,'Value') == 1
            set(handles.N_apr_height_list,'Value',1)
            set(handles.N_apr_height_list,'String','Error: Load NWM or refractivity data first');
        elseif get(handles.N_apr_opt1_popup,'Value') == 2
            if isfield(handles,'N_apr_heights1')
                set(handles.N_apr_height_list,'Value',1)
                set(handles.N_apr_height_list,'String',handles.N_apr_heights1);
                set(handles.N_apr_height_model_par1,'Enable','off')
                set(handles.N_apr_height_model_par2,'Enable','off')
                set(handles.N_apr_height_model_par3,'Enable','off')
                set(handles.N_apr_height_model_par4,'Enable','off')
            else
                set(handles.N_apr_height_list,'Value',1)
                set(handles.N_apr_height_list,'String','Error: Load NWM or refractivity data first');
            end
        % Check if refractivity fields data exist and read height layers
        elseif get(handles.N_apr_opt1_popup,'Value') == 3
            if isfield(handles,'N_apr_heights2')
                set(handles.N_apr_height_list,'Value',1)
                set(handles.N_apr_height_list,'String',handles.N_apr_heights2);
                set(handles.N_apr_height_model_par1,'Enable','off')
                set(handles.N_apr_height_model_par2,'Enable','off')
                set(handles.N_apr_height_model_par3,'Enable','off')
                set(handles.N_apr_height_model_par4,'Enable','off')
            else
                set(handles.N_apr_height_list,'Value',1)
                set(handles.N_apr_height_list,'String','Error: Load NWM or refractivity data first');
            end
        end            
    case 3
        if get(handles.N_apr_POI_button2,'Value') == 1
            str = get(handles.N_apr_input3_headline,'String');
            if strcmp(str,'No file')
                set(handles.N_apr_height_list,'Value',1)  
                set(handles.N_apr_height_list,'String','Error: Load CRD file first');                
            else
                set(handles.N_apr_height_list,'String',['heights read from' str]);
                set(handles.N_apr_height_list,'Value',2);
            end
            set(handles.N_apr_height_model_par1,'Enable','off')
            set(handles.N_apr_height_model_par2,'Enable','off')
            set(handles.N_apr_height_model_par3,'Enable','off')
            set(handles.N_apr_height_model_par4,'Enable','off')
        else
            set(handles.N_apr_height_list,'Value',1)  
            set(handles.N_apr_height_list,'String','Error: Load CRD file first');
        end
end

function N_apr_height_popup_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function N_apr_height_check_Callback(hObject, eventdata, handles)

function N_apr_height_model_par1_Callback(hObject, eventdata, handles)

function N_apr_height_model_par1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function N_apr_height_model_par1_ButtonDownFcn(hObject, eventdata, handles)
if strcmp(get(hObject,'Enable'),'inactive'); set(hObject,'Enable','on'); end
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function N_apr_height_model_par2_Callback(hObject, eventdata, handles)

function N_apr_height_model_par2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function N_apr_height_model_par2_ButtonDownFcn(hObject, eventdata, handles)
if strcmp(get(hObject,'Enable'),'inactive'); set(hObject,'Enable','on'); end
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function N_apr_height_model_par3_Callback(hObject, eventdata, handles)

function N_apr_height_model_par3_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function N_apr_height_model_par3_ButtonDownFcn(hObject, eventdata, handles)
if strcmp(get(hObject,'Enable'),'inactive'); set(hObject,'Enable','on'); end
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function N_apr_height_model_par4_Callback(hObject, eventdata, handles)

function N_apr_height_model_par4_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function N_apr_height_model_par4_ButtonDownFcn(hObject, eventdata, handles)
if strcmp(get(hObject,'Enable'),'inactive'); set(hObject,'Enable','on'); end
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

% ---------------- Panels for list of selected height layers -------------
function N_apr_height_list_Callback(hObject, eventdata, handles)
% Set the limit of files which can be selected
set(hObject,'min',0,'max',500);
% Use 'Entf to delete entries in listbox
set(hObject,'keypressfcn',@key_check)
guidata(hObject, handles);

function N_apr_height_list_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ----------------------------- Data source popupmenu --------------------
function N_apr_opt1_popup_Callback(hObject, eventdata, handles)
sm_str = get(hObject,'String');
sm_val = get(hObject,'Value');
switch sm_str{sm_val}
    case 'Standard atmosphere'
        set(handles.N_apr_input1_headline,'Enable','off')
        set(handles.N_apr_input1_open,'Enable','off')
        set(handles.N_apr_input1_load,'Enable','off')
        set(handles.N_apr_input1_list,'Enable','off')
        set(handles.N_apr_input2_headline,'Enable','off')
        set(handles.N_apr_input2_open,'Enable','off')
        set(handles.N_apr_input2_load,'Enable','off')
        set(handles.N_apr_input2_list,'Enable','off')
        set(handles.N_apr_opt2_headline,'Enable','off')
        set(handles.N_apr_opt2_popup,'Enable','off')
        set(handles.N_apr_grib1_param,'Enable','off')
        set(handles.N_apr_grib1_plev,'Enable','off')
        set(handles.N_apr_grib1_epoch,'Enable','off')
        set(handles.N_apr_grid1_list,'Enable','off')
        % Output filename
        switch get(get(handles.N_apr_buttongroup2,'SelectedObject'),'Tag')
            case 'N_apr_source_button1'
                set(handles.N_apr_output_com,'String',[handles.atom_start_output '\Standard_atm.Napr']);
            case 'N_apr_source_button2'
                set(handles.N_apr_output_com,'String',[handles.atom_start_output '\Standard_atm.ZTD']);
        end
    case {'NWM grib1p'}
        set(handles.N_apr_input1_headline,'Enable','on')
        set(handles.N_apr_input1_open,'Enable','on')
        set(handles.N_apr_input1_load,'Enable','on')
        set(handles.N_apr_input1_list,'Enable','on')
        set(handles.N_apr_input2_headline,'Enable','off')
        set(handles.N_apr_input2_open,'Enable','off')
        set(handles.N_apr_input2_load,'Enable','off')
        set(handles.N_apr_input2_list,'Enable','off')
        set(handles.N_apr_opt2_headline,'Enable','on')
        set(handles.N_apr_opt2_popup,'Enable','on')
        set(handles.N_apr_grib1_param,'Enable','on')
        set(handles.N_apr_grib1_plev,'Enable','on')
        set(handles.N_apr_grib1_epoch,'Enable','on')
        set(handles.N_apr_grid1_list,'Enable','on')
    case 'Refractivity fields'
        set(handles.N_apr_input1_headline,'Enable','off')
        set(handles.N_apr_input1_open,'Enable','off')
        set(handles.N_apr_input1_load,'Enable','off')
        set(handles.N_apr_input1_list,'Enable','off')
        set(handles.N_apr_input2_headline,'Enable','on')
        set(handles.N_apr_input2_open,'Enable','on')
        set(handles.N_apr_input2_load,'Enable','on')
        set(handles.N_apr_input2_list,'Enable','on')
        set(handles.N_apr_opt2_headline,'Enable','on')
        set(handles.N_apr_opt2_popup,'Enable','on')
        set(handles.N_apr_grib1_param,'Enable','off')
        set(handles.N_apr_grib1_plev,'Enable','off')
        set(handles.N_apr_grib1_epoch,'Enable','off')
        set(handles.N_apr_grid1_list,'Enable','off')        
end

function N_apr_opt1_popup_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% -------------------------- NWM grib1 (Input 1) -------------------------
function N_apr_input1_open_Callback(hObject, eventdata, handles)
% Read file names
[filename1, handles.N_apr_input1_pathname1] = uigetfile({...
    '*grib1','NWM grib1 data'},...
    'Select File',handles.atom_start_input,'MultiSelect','on');
% Pass file names to listbox
if isequal(filename1,0)
    set(handles.N_apr_input1_list,'String',{'No file'});
    set(handles.N_apr_input1_list,'Value',1)
else    
    set(handles.N_apr_input1_list,'String',cellstr(filename1));
    set(handles.N_apr_input1_list,'Value',1)
    set(handles.N_apr_grid1_list,'Value',1);
    set(handles.N_apr_grid1_list,'String',{'No epoch'});
end
guidata(hObject, handles);

function N_apr_input1_load_Callback(hObject, eventdata, handles)
% Read file names;
str = get(handles.N_apr_input1_list,'String');
val = get(handles.N_apr_input1_list,'Value');
% Check if files exist
if strcmp(str,'No file') ~= 1
    % Initialise variables
    handles.N_apr_input1_data = [];
    handles.N_apr_input1_cont = [];
    % Create waitbar
    h = waitbar(0,'Please wait...','WindowStyle','modal');
    % Read grib settings
    nparam = str2double(get(handles.N_apr_grib1_param,'String')); % Number parameters
    nplev  = str2double(get(handles.N_apr_grib1_plev,'String'));  % Number pressure levels
    nepoch = str2double(get(handles.N_apr_grib1_epoch,'String')); % Number epochs
    if isnan(nepoch); nint = -1; else; nint = 1:nparam*nplev:nparam*nplev*nepoch; end % set nepoch to -1, i.e. read all data
    % Initalise meteo parameters
    Z   = [];  % geopotential in [m^2/s^2]
    Q   = [];  % specific humidity in [kg/kg]
    rH  = [];  % relative humidity [%]
    T   = [];  % temperature in [K]    
    p   = [];  % pressure in [hPa]
    lon = [];  % longitude in [degrees]
    lat = [];  % latitude in [degrees]  
    % Loop to read each input file
    for i = 1:length(val)
        % Reset variables
        if i > 1
            %  p = [];  % pressure in [hPa] 
            %lon = [];  % longitude in [degrees]
            %lat = [];  % latitude in [degrees]
            if nparam >= 3
                Z   = [];  % geopotential in [m^2/s^2]
                Q   = [];  % specific humidity in [kg/kg]
                T   = [];  % temperature in [K]
                rH  = [];  % relative humidity [%]
            end
        end
        % Fill wait bar
        waitbar(i/length(val),h);
        % Path and filename
        folder = handles.N_apr_input1_pathname1;
        file   = str{val(i)};
        % Get available epochs
        grib=read_grib([folder,file],nint,'ParamTable','ECMWF128'); % ,'ParamTable','ECMWF128'
        % Each file consists e.g. of 300 records = 25 pressure levels * 3 parameter * 4 times per day (6 hours temp res)        
        % Send list of epochs to list        
        set(handles.N_apr_grid1_list,'String',unique({grib.stime}))
        % Read epoch selection
        epoch = get(handles.N_apr_grid1_list,'Value');
        rec_start = (epoch-1)*nparam*nplev+1;
        rec_end   = rec_start+nparam*nplev-1;
        % Read Grib1 data, Option '-1' ... all data, 1:nparam*nplev ... 1st epoch
        grib=read_grib([folder,file],rec_start:rec_end,'ParamTable','ECMWF128'); % ,'ParamTable','ECMWF128'
        % Get number of grid points
        if isfield(grib(1).gds,'Nj')
            nlat = grib(1).gds.Nj;
            nlon = grib(1).gds.Ni;
        elseif isfield(grib(1).gds,'Nx')
            nlat = grib(1).gds.Nx;
            nlon = grib(1).gds.Ny;
        end
        % Store nlat and nlon
        handles.N_apr_grid1_nlat = nlat;
        handles.N_apr_grid1_nlon = nlon ;  
        % Get first / last grid point
        lat_first = grib(1).gds.La1;
        lat_last  = grib(1).gds.La2;
        lon_first = grib(1).gds.Lo1;
        lon_last  = grib(1).gds.Lo2;
        % Get resolution
        dint_lat = grib(1).gds.Dj; if lat_first > lat_last; dint_lat = -dint_lat; end
        dint_lon = grib(1).gds.Di; if lon_first > lon_last; dint_lon = -dint_lon; end
        % Lat/Lon vectors for one layer
        lat_1l = kron((lat_first:dint_lat:lat_last)',ones(nlon,1));
        lon_1l = repmat((lon_first:dint_lon:lon_last)',nlat,1);
        % Convert lon [0 180] to lon [0 360]
        lon_1l = mod(lon_1l,360);    
        % Get parameters Z, Q, T for each pressue level
        for n_rec = 1:nparam*nplev
            % Get label of pressure level
            pressure_lev_label=grib(n_rec).level;
            % Get type of parameter
            param_type=grib(n_rec).parameter;
            % If param is not provided read type from filename
            if strcmp(param_type,'None') || strcmp(param_type,'-')
                if ~isempty(strfind(str{val(i)},'GP')) || ~isempty(strfind(str{val(i)},'Z'))
                        param_type = 'Z';
                elseif ~isempty(strfind(str{val(i)},'Q'))
                        param_type = 'Q';
                elseif ~isempty(strfind(str{val(i)},'T'))                        
                        param_type = 'T';
                end
            end                
            % Store data in vector
            switch param_type
                case {'Z','GP','MSLMA'} % MSLMA for ECMWF grib2 files
                    Z = [Z;grib(n_rec).fltarray];
                    % extract pressure value from label and create pressure vector
                    p1(1:(nlat*nlon),1)=str2double(strrep(pressure_lev_label,' mb','')); % in [hPa]; 1 mbar = 1 hPa
                    p = [p;p1];
                    % Repeat lat/lon for all pressure levels
                    lat = [lat;lat_1l];
                    lon = [lon;lon_1l];                     
                case {'Q','SPFH','KX'}
                    Q = [Q;grib(n_rec).fltarray];
                case {'T','TMP','MSLET'}
                    T = [T;grib(n_rec).fltarray];
                case {'RH'}
                    rH = [rH;grib(n_rec).fltarray];
            end
        end
    end    
    % Check unit of p [Pa -> hPa]
    if max(p) > 1100; p = p./100; end    
    % Check content and compute specific humidity if not provided
    if isempty(Q) && ~isempty(rH) && ~isempty(T) && ~isempty(p)
        %e = 6.1078.*rH.*exp((17.10.*(T-273.15))./(235.00+(T-273.15)));
        e = rH.*6.1120.*exp((17.62.*(T-273.15))./(243.12+(T-273.15))); % [hPa] 
        Q = (0.62198*e)./(p-0.37802*e);
    end
    if isempty(Z) || isempty(Q) || isempty(T)
        set(handles.N_apr_status_text,'String','Error: Parameters are missing in grib1 file');
        % Close waitbar
        close(h);
        return
    end
    % Compute further parameters
    gph = Z/9.80665; % geopotential height [m]
    H   = gpm2z(gph,lat/180*pi); % orthometric height [m]
    e   = Q.*p./(0.62198+0.37802*Q); % water vapour [hPa]
    handles.N_apr_heights1 = sort(round(mean(reshape(H,nlat*nlon,[]))));
    
    % Check option of height layer selection
    hm_val = get(handles.N_apr_height_popup,'Value');
    switch hm_val
        % Height model according to Perler (2011)
        case 1
            Hmin = str2double(get(handles.N_apr_height_model_par1,'String'));
            Hmax = str2double(get(handles.N_apr_height_model_par2,'String'));
            q    = str2double(get(handles.N_apr_height_model_par3,'String'));
            dH0  = str2double(get(handles.N_apr_height_model_par4,'String'));
            poi_H = height_model(Hmin,Hmax,q,dH0);
            set(handles.N_apr_height_list,'Value',1)
            set(handles.N_apr_height_list,'String',poi_H);
            set(handles.N_apr_height_model_par1,'BackgroundColor',[1 1 1])
            set(handles.N_apr_height_model_par2,'BackgroundColor',[1 1 1])
            set(handles.N_apr_height_model_par3,'BackgroundColor',[1 1 1])
            set(handles.N_apr_height_model_par4,'BackgroundColor',[1 1 1])
            set(handles.N_apr_height_model_par1,'Enable','inactive')
            set(handles.N_apr_height_model_par2,'Enable','inactive')
            set(handles.N_apr_height_model_par3,'Enable','inactive')
            set(handles.N_apr_height_model_par4,'Enable','inactive')
        case 2
            % Compute mean height of each pressure level
            poi_H = handles.N_apr_heights1;
            set(handles.N_apr_height_list,'Value',1)
            set(handles.N_apr_height_list,'String',poi_H);
        case 3
            % Get mean heights from grib1 file
            str_crd = get(handles.N_apr_input3_headline,'String');
        if strcmp(str_crd,'No file')
            set(handles.N_apr_height_list,'String','Error: Load CRD file first');
            set(handles.N_apr_height_list,'Value',1)  
        else
            % get heights from crd file
            set(handles.N_apr_height_list,'String',['heights read from' str_crd]);
            set(handles.N_apr_height_list,'Value',2);
        end            
    end   

    % Determine time of epoch of the grib-file records for the selected epoch
    year=grib(1).pds.year;
    month=grib(1).pds.month;
    day=grib(1).pds.day;
    hour=grib(1).pds.hour;
    % Calculate mjd for epoch
    for i = 1:length(year)
        handles.N_apr_input1.mjd(i)=cal2jd(year(i), month(i), day(i)) + hour(i)/24 - 2400000.5;    
    end
    
    % Restore data
    handles.N_apr_input1_data = [handles.N_apr_input1_data,{lat,lon,H,e,T,p}];
    handles.N_apr_input1_cont = {'Lat [�]','Lon [�]','orth. Heigth [m]','WV pressure [hPa]','Temperaure [K]','Pressure [hPa]'};
    
    % Status text
    set(handles.N_apr_status_text,'String','Grib1 data loaded');
    
    % Output filename
    switch get(get(handles.N_apr_buttongroup2,'SelectedObject'),'Tag')
        case 'N_apr_source_button1'
            out = [handles.atom_start_output '\' str{val(i)}(1:end-5) 'Napr'];
            %out = [handles.atom_start_output '\' str{val(i)}(1:end-8) '.Napr']; % ALARO
        case 'N_apr_source_button2'
            out = [handles.atom_start_output '\' str{val(i)}(1:end-5) 'ZTD'];
    end
    set(handles.N_apr_output_com,'String',out);
    % Close waitbar
    close(h);    
end
guidata(hObject, handles);

function N_apr_input1_list_Callback(hObject, eventdata, handles)
% Set the limit of files which can be selected
set(hObject,'min',0,'max',3);
% Use 'Entf to delete entries in listbox
set(hObject,'keypressfcn',@key_check)
guidata(hObject, handles);

function N_apr_input1_list_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% -------------------------- List of grib1 epochs ------------------------
function N_apr_grid1_list_Callback(hObject, eventdata, handles)

function N_apr_grid1_list_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% -------------------------- Grib1 settings ------------------------------
function N_apr_grib1_param_Callback(hObject, eventdata, handles)

function N_apr_grib1_param_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function N_apr_grib1_param_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function N_apr_grib1_plev_Callback(hObject, eventdata, handles)

function N_apr_grib1_plev_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function N_apr_grib1_plev_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function N_apr_grib1_epoch_Callback(hObject, eventdata, handles)

function N_apr_grib1_epoch_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function N_apr_grib1_epoch_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% -------------------------- Refractivity fields (Input 2) ---------------
function N_apr_input2_open_Callback(hObject, eventdata, handles)
% Read file names
[filename1, handles.N_apr_input2_pathname1] = uigetfile({...
    '*.N','Refractivity field'},...
    'Select File',handles.atom_start_input,'MultiSelect','on');
% Pass file names to listbox
if isequal(filename1,0)
    set(handles.N_apr_input2_list,'String',{'No file'});
    set(handles.N_apr_input2_list,'Value',1)
else    
    set(handles.N_apr_input2_list,'String',cellstr(filename1));
    set(handles.N_apr_input2_list,'Value',1)
end
guidata(hObject, handles);

function N_apr_input2_list_Callback(hObject, eventdata, handles)
% Set the limit of files which can be selected
set(hObject,'min',0,'max',100);
% Use 'Entf to delete entries in listbox
set(hObject,'keypressfcn',@key_check)
guidata(hObject, handles);

function N_apr_input2_list_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function N_apr_input2_load_Callback(hObject, eventdata, handles)
% Read file names
str = get(handles.N_apr_input2_list,'String');
val = get(handles.N_apr_input2_list,'Value');
% Check if files exist
if strcmp(str,'No file') ~= 1
    % Initialise variables
    handles.N_apr_input2_data = [];
    handles.N_apr_input2_cont = [];
    % Create waitbar
    h = waitbar(0,'Please wait...','WindowStyle','modal');
    % Loop to read each input file
    for i = 1:length(val)
        % Fill wait bar
        waitbar(i/length(val),h);
        % Path name
        fullpathname = strcat(handles.N_apr_input2_pathname1,str{val(i)});
        % Read refractivity data
        [dat1,dat2] = read_refr(fullpathname);      
        % Concatinate cell arrays
        handles.N_apr_input2_data = [handles.N_apr_input2_data;dat1{:}];        
        handles.N_apr_input2_cont = dat2;
    end
    
    % Find height column
    id = strcmp(dat2,'H [m]'); 
    % Compute height layers
    handles.N_apr_heights2 = unique(dat1{:,id});
    
    if strcmp(get(get(handles.N_apr_buttongroup1,'SelectedObject'),'Tag'),'N_apr_POI_button1')
        % Set voxel size to minimum and maximum possible
        id_lat = strcmp(dat2,'Lat [�]');
        id_lon = strcmp(dat2,'Lon [�]');
        % Get min/max lat and lon from file
        dat_lat1 = dat1{id_lat}(1);
        dat_lat2 = dat1{id_lat}(end);
        dat_lon1 = dat1{id_lon}(1);
        dat_lon2 = dat1{id_lon}(end);
        % Get min/max lat and lon from GUI
        vox_lat1 = str2double(get(handles.N_apr_model_lat1,'String'));
        vox_lat2 = str2double(get(handles.N_apr_model_lat2,'String'));
        vox_dlat = str2double(get(handles.N_apr_model_dlat,'String'));
        vox_lon1 = str2double(get(handles.N_apr_model_lon1,'String'));
        vox_lon2 = str2double(get(handles.N_apr_model_lon2,'String'));
        vox_dlon = str2double(get(handles.N_apr_model_dlon,'String'));
        vox_lon1 = mod(vox_lon1,360);
        vox_lon2 = mod(vox_lon2,360);
        % Compare and replace if necessary
        if dat_lat1 > (vox_lat1 + vox_dlat/2)
            set(handles.N_apr_model_lat1,'String',dat_lat1 - vox_dlat/2)
        end
        if dat_lat2 < (vox_lat2 - vox_dlat/2)
            set(handles.N_apr_model_lat2,'String',dat_lat2 + vox_dlat/2)
        end
        if dat_lon1 > (vox_lon1 + vox_dlon/2)
            if dat_lon1 > 180; dat_lon1 = dat_lon1 -360; end
            set(handles.N_apr_model_lon1,'String',dat_lon1 - vox_dlon/2)
        end
        if dat_lon2 < (vox_lon2 - vox_dlon/2)
            if dat_lon2 > 180; dat_lon2 = dat_lon2 -360; end
            set(handles.N_apr_model_lon2,'String',dat_lon2 + vox_dlon/2)
        end
    end    
    
    % Check option of height layer selection
    hm_val = get(handles.N_apr_height_popup,'Value');
    switch hm_val
        % Height model according to Perler (2011)
        case 1
            Hmin = str2double(get(handles.N_apr_height_model_par1,'String'));
            Hmax = str2double(get(handles.N_apr_height_model_par2,'String'));
            q    = str2double(get(handles.N_apr_height_model_par3,'String'));
            dH0  = str2double(get(handles.N_apr_height_model_par4,'String'));
            poi_H = height_model(Hmin,Hmax,q,dH0);
            set(handles.N_apr_height_list,'Value',1)
            set(handles.N_apr_height_list,'String',poi_H);
            set(handles.N_apr_height_model_par1,'BackgroundColor',[1 1 1])
            set(handles.N_apr_height_model_par2,'BackgroundColor',[1 1 1])
            set(handles.N_apr_height_model_par3,'BackgroundColor',[1 1 1])
            set(handles.N_apr_height_model_par4,'BackgroundColor',[1 1 1])
            set(handles.N_apr_height_model_par1,'Enable','inactive')
            set(handles.N_apr_height_model_par2,'Enable','inactive')
            set(handles.N_apr_height_model_par3,'Enable','inactive')
            set(handles.N_apr_height_model_par4,'Enable','inactive')
        case 2
            % Compute mean height of each pressure level
            poi_H = handles.N_apr_heights2;
            set(handles.N_apr_height_list,'Value',1)
            set(handles.N_apr_height_list,'String',poi_H);
        case 3
            % Get mean heights from grib1 file
            str_crd = get(handles.N_apr_input3_headline,'String');
            if strcmp(str_crd,'No file')
                set(handles.N_apr_height_list,'String','Error: Load CRD file first');
                set(handles.N_apr_height_list,'Value',1)  
            else
                % get heights from crd file
                set(handles.N_apr_height_list,'String',['heights read from' str_crd]);
                set(handles.N_apr_height_list,'Value',2);
            end
    end
    
    % Status text
    set(handles.N_apr_status_text,'String','Refractivity fields loaded');
    close(h);
    
    % Output filename
    switch get(get(handles.N_apr_buttongroup2,'SelectedObject'),'Tag')
        case 'N_apr_source_button1'
            out = [handles.atom_start_output '\' str{val(i)}(1:end-1) 'Napr'];
        case 'N_apr_source_button2'
            out = [handles.atom_start_output '\' str{val(i)}(1:end-1) 'ZTD'];
    end    
    set(handles.N_apr_output_com,'String',out);    
end
guidata(hObject, handles);

% ---------------------------- Output parameter --------------------------
function N_apr_buttongroup2_SelectionChangeFcn(hObject, eventdata, handles)
out = get(handles.N_apr_output_com,'String');
switch get(hObject,'Tag')
    case 'N_apr_source_button1'
        out = strrep(out,'.ZTD','.Napr');
        %out = strrep(out,'ZTDs\ECMWF','Refractivities');
        set(handles.N_apr_output_com,'String',out);
        if strcmp(get(get(handles.N_apr_buttongroup1,'SelectedObject'),'Tag'),'N_apr_POI_button1')
            set(handles.N_apr_outer_voxel_model,'Enable','on')            
        end
        set(handles.N_apr_stddev_sel,'Enable','on')
    case 'N_apr_source_button2'
        out = strrep(out,'.Napr','.ZTD');
        %out = strrep(out,'Refractivities','ZTDs\ECMWF');
        set(handles.N_apr_output_com,'String',out);
        set(handles.N_apr_outer_voxel_model,'Enable','off')
        set(handles.N_apr_stddev_sel,'Enable','off')
end

% ------------------------ Horizontal interpolation ----------------------
function N_apr_opt2_popup_Callback(hObject, eventdata, handles)

function N_apr_opt2_popup_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ------------------------ set outer voxel model -------------------------
function N_apr_outer_voxel_model_Callback(hObject, eventdata, handles)

% ----------------------------- set stddev option ------------------------
function N_apr_stddev_sel_Callback(hObject, eventdata, handles)

% --------------------- Compute refractivities/zenith delay --------------
function N_apr_output_save_Callback(hObject, eventdata, handles)
% clear variables
clear poi_H poi_crd
% Get points of interest (POIs)
switch get(get(handles.N_apr_buttongroup1,'SelectedObject'),'Tag')
    case 'N_apr_POI_button1'
        % Voxel model corners + resolution
        vox_lat1 = str2double(get(handles.N_apr_model_lat1,'String'));
        vox_lat2 = str2double(get(handles.N_apr_model_lat2,'String'));
        vox_dlat = str2double(get(handles.N_apr_model_dlat,'String'));        
        vox_lon1 = str2double(get(handles.N_apr_model_lon1,'String'));
        vox_lon2 = str2double(get(handles.N_apr_model_lon2,'String'));
        vox_dlon = str2double(get(handles.N_apr_model_dlon,'String'));               
        % Reset box settings
        set(handles.N_apr_model_lat1,'BackgroundColor',[1 1 1],'Enable','Inactive');
        set(handles.N_apr_model_lat2,'BackgroundColor',[1 1 1],'Enable','Inactive');
        set(handles.N_apr_model_dlat,'BackgroundColor',[1 1 1],'Enable','Inactive');
        set(handles.N_apr_model_lon1,'BackgroundColor',[1 1 1],'Enable','Inactive');
        set(handles.N_apr_model_lon2,'BackgroundColor',[1 1 1],'Enable','Inactive');
        set(handles.N_apr_model_dlon,'BackgroundColor',[1 1 1],'Enable','Inactive');               
        % Number of grid points inner voxel
        vox_nlat = round((vox_lat2-vox_lat1)/vox_dlat);
        vox_nlon = round((vox_lon2-vox_lon1)/vox_dlon);
        if vox_nlat == 0 || vox_nlon == 0
            set(handles.N_apr_status_text,'String','Error, voxel model is not defined wise');
            return
        end
        % Get height information
        H_str = get(handles.N_apr_height_list,'String');
        poi_H = zeros(1,size(H_str,1));        
        for i = 1:size(H_str,1); poi_H(i) = str2double(H_str(i,:)); end 
        % Counter variable
        n = 1;
        % Create poi_crd vector for inner and outer voxel model
        if get(handles.N_apr_outer_voxel_model,'Value') == 1
            poi_crd = zeros((vox_nlat+2)*(vox_nlon+2)*length(poi_H),3);
            for i = 1:length(poi_H)
                for j = 1:vox_nlat+2               
                    for k = 1:vox_nlon+2
                        if j == 1
                            poi_crd(n,1) = vox_lat1-5;
                            if k == 1                                
                                poi_crd(n,2) = vox_lon1-5;
                            elseif k > 1 && k <= vox_nlon+1
                                poi_crd(n,2) = vox_lon1+vox_dlon/2+(k-2)*vox_dlon;
                            elseif k == vox_nlon+2
                                poi_crd(n,2) = vox_lon2+5;
                            end                            
                            poi_crd(n,3) = poi_H(i);
                            n = n + 1;
                        elseif j > 1 && j <= vox_nlat+1
                            poi_crd(n,1) = vox_lat1+vox_dlat/2+(j-2)*vox_dlat;
                            if k == 1                                
                                poi_crd(n,2) = vox_lon1-5;
                            elseif k > 1 && k <= vox_nlon+1
                                poi_crd(n,2) = vox_lon1+vox_dlon/2+(k-2)*vox_dlon;
                            elseif k == vox_nlon+2
                                poi_crd(n,2) = vox_lon2+5;
                            end                            
                            poi_crd(n,3) = poi_H(i);
                            n = n + 1;
                        elseif j == vox_nlat+2
                            poi_crd(n,1) = vox_lat2+5;
                            if k == 1                                
                                poi_crd(n,2) = vox_lon1-5;
                            elseif k > 1 && k <= vox_nlon+1
                                poi_crd(n,2) = vox_lon1+vox_dlon/2+(k-2)*vox_dlon;
                            elseif k == vox_nlon+2
                                poi_crd(n,2) = vox_lon2+5;
                            end                            
                            poi_crd(n,3) = poi_H(i);
                            n = n + 1;
                        end
                    end
                end
            end
        else
            % Create poi_crd vector for inner voxel model
            poi_crd = zeros(vox_nlat*vox_nlon*length(poi_H),3);
            for i = 1:length(poi_H)
                for j = 1:vox_nlat               
                    for k = 1:vox_nlon
                        % Inner voxel model
                        poi_crd(n,1) = vox_lat1+vox_dlat/2+(j-1)*vox_dlat;
                        poi_crd(n,2) = vox_lon1+vox_dlon/2+(k-1)*vox_dlon;
                        poi_crd(n,3) = poi_H(i);
                        n = n + 1;
                    end
                end
            end
        end
    case 'N_apr_POI_button2'
        % GNSS station coordinates
        if strcmp(get(handles.N_apr_station_list,'String'),'No station') == 0
            % Selected stations
            sta_val = get(handles.N_apr_station_list,'Value');
            % Get coordinates for selected stations
            sta_lat = handles.N_apr_input3_crd(sta_val,1);
            sta_lon = handles.N_apr_input3_crd(sta_val,2);
            sta_H   = handles.N_apr_input3_crd(sta_val,3);
            % Counter variable
            n = 1;            
            % Create poi_crd vector (coordinates of each voxel center point)
            poi_crd = zeros(length(sta_lat),3);
            for i = 1:length(sta_H)
                poi_crd(n,1) = sta_lat(i);
                poi_crd(n,2) = sta_lon(i);
                poi_crd(n,3) = sta_H(i);
                n = n + 1;
            end
        else
            set(handles.N_apr_status_text,'String','Error, no coordinates found');
            return
        end        
end

% Output file
fout = get(handles.N_apr_output_com,'String');  
out  = fopen(fout,'w');
set(handles.N_apr_output_com,'BackgroundColor',[1 1 1],'Enable','Inactive');

% Data source
ds_str = get(handles.N_apr_opt1_popup,'String');
ds_var = get(handles.N_apr_opt1_popup,'Value');

% Compute output parameters
switch ds_str{ds_var}
    case 'Standard atmosphere'  
        % Create waitbar
        h = waitbar(0,'Please wait...','WindowStyle','modal');
        switch get(get(handles.N_apr_buttongroup2,'SelectedObject'),'Tag')
            % Compute refractivities for POIs
            case 'N_apr_source_button1'       
                % Initialise variables
                n_poi  = length(poi_crd(:,1));
                % Loop over all POIs
                for i = 1:n_poi
                    waitbar(i/n_poi,h);
                    % Compute values of standard atmosphere
                    [p,T,e] = stdatm(poi_crd(i,3));
                    % Set standard deviation
                    if get(handles.N_apr_stddev_sel,'Value') == 1
                        % Compute specific humidity [kg/kg]
                        Q = 0.622*e/p/(1-0.378*e/p);
                        % Compute standard deviations acc to values defined in Steiner et al. (2006)
                        [stdNh,stdNw] = comp_stddev(p,T,Q,poi_crd(i,3)/1000);
                    else
                        stdNh = 0; stdNw = 0;
                    end
                    [N_h,N_w]  = comp_N(p,T,e);
                    fprintf(out,'%9.5f %10.5f %7.1f %6.3f %6.2f %7.2f %8.3f %7.3f %8.3f %7.3f %6.3f %6.3f\n',poi_crd(i,1),poi_crd(i,2),poi_crd(i,3),e,T,p,N_h+N_w,N_w,0,0,sqrt(stdNh^2+stdNw^2),stdNw);
                end                      
            % Compute zenith delays for POIs
            case 'N_apr_source_button2'
                % Check selected POIs
                switch get(get(handles.N_apr_buttongroup1,'SelectedObject'),'Tag')
                    % Case voxel model
                    case 'N_apr_POI_button1'
                        % Get list of grid points and height layers
                        lat  = unique(poi_crd(:,1));
                        lon  = unique(poi_crd(:,2));
                        href = min(poi_crd(:,3));
                        % Station names
                        sta = 1:(length(lon)*length(lat));
                        sta = cellstr(num2str(sta','%4.4d'));
                        % Compute meteo parameters for predefined heights
                        h_inc = [0:10:2000,2020:20:6000,6050:50:16000,16100:100:36000,36500:500:136000];
                        for i = 1:length(h_inc)
                            [p(i),T(i),e(i)] = stdatm(h_inc(i));
                        end
                        % Counter variable
                        n = 1;
                        % Loop over all latitudes
                        for i = 1:length(lat)
                            waitbar(i/length(lat),h);                       
                            % Compute delays
                            ray = delay2D_grid(p,h_inc',T,e, href,90,lat(i));
                            % Loop over all longitudes
                            for j = 1:length(lon)
                                fprintf(out,'%4s %9.5f %10.5f %7.1f %7.4f %7.4f\n',sta{n},lat(i),lon(j),min(href),ray.dz_h+ray.dz_w,ray.dz_w);
                                n = n + 1;
                            end                            
                        end
                    % Case coordinate file
                    case 'N_apr_POI_button2'
                        % Loop over all latitudes
                        for i = 1:length(poi_crd(:,1))
                            waitbar(i/length(poi_crd(:,1)),h);
                            % Station height from file
                            href = poi_crd(i,3);
                            % Station names
                            sta_str = get(handles.N_apr_station_list,'String');
                            sta_val = get(handles.N_apr_station_list,'Value');
                            sta = sta_str(sta_val);
                            % Compute meteo parameters for station height
                            h_inc = [0:10:2000,2020:20:6000,6050:50:16000,16100:100:36000,36500:500:136000];
                            for j = 1:length(h_inc)
                                [p(j),T(j),e(j)] = stdatm(h_inc(j));
                            end
                            % Compute delays
                            ray = delay2D_grid(p,h_inc',T,e,poi_crd(i,3),90,poi_crd(i,1));
                            fprintf(out,'%4s %9.5f %10.5f %7.1f %7.4f %7.4f\n',sta{i},poi_crd(i,1),poi_crd(i,2),poi_crd(i,3),ray.dz_h,ray.dz_w);                          
                        end
                end
        end
        close(h)
    case 'NWM grib1p'
        % Get meteo data from NMW
        dat = handles.N_apr_input1_data;
        % Number of values (nlat,nlon,np)
        nlat = handles.N_apr_grid1_nlat; %length(unique(dat{1}));
        nlon = handles.N_apr_grid1_nlon; %length(unique(dat{2}));
        np   = length(dat{6})/nlat/nlon;
        % Reshape vector to grid (nlat,nlon,np)
        lat = reshape(dat{1},nlon,nlat,np);
        lon = reshape(dat{2},nlon,nlat,np);
        H   = reshape(dat{3},nlon,nlat,np);
        p   = reshape(dat{6},nlon,nlat,np);
        T   = reshape(dat{5},nlon,nlat,np);
        e   = reshape(dat{4},nlon,nlat,np);
        
        % For ALARO data only (put first pressure level 1000 hPa to end)        
        %H(:,:,np+1) = H(:,:,1); H(:,:,1) = [];
        %p(:,:,np+1) = p(:,:,1); p(:,:,1) = [];
        %T(:,:,np+1) = T(:,:,1); T(:,:,1) = [];
        %e(:,:,np+1) = e(:,:,1); e(:,:,1) = [];
        
        % Resolution 
        if nlat >= 2 && nlon >=2          
            res_lat = (max(lat(1,:,1))-min(lat(1,:,1)))/(nlat-1);
            res_lon = (max(lon(:,1,1))-min(lon(:,1,1)))/(nlon-1);
        else
            set(handles.N_apr_status_text,'String','Error: Resolution of input data cannot be computed, dataset to small');
            return
        end
        % Restore POI crd - lon[0 180] to lon[0 360]
        poi_crd(:,2) = mod(poi_crd(:,2),360);        
        % Create waitbar
        h = waitbar(0,'Please wait...','WindowStyle','modal');
        % Read selection of output parameters
        switch get(get(handles.N_apr_buttongroup2,'SelectedObject'),'Tag')
            % Compute refractivities
            case 'N_apr_source_button1'               
                % Horizontal interpolation option
                hi_str = get(handles.N_apr_opt2_popup,'String');
                hi_val = get(handles.N_apr_opt2_popup,'Value');
                % Define grid width around POI
                switch hi_str{hi_val}
                    case 'Nearest'
                        factor = 1; % Grid points in distance 1*res_lat
                    case 'Linear'
                        factor = 2; % Grid points in distance 2*res_lat
                    case 'Spline'
                        factor = 3; % Grid points in distance 3*res_lat
                end
                % Initialise variables   
                n_poi  = length(poi_crd(:,1));
                % Loop over all grid points
                for i = 1:n_poi
                    % Fill wait bar
                    waitbar(i/n_poi,h);
                    % Find closest grid nodes for each voxel center point
                    [ind_lon]=find(abs(lon(:,1,1)-poi_crd(i,2))<=res_lon*factor);
                    [ind_lat]=find(abs(lat(1,:,1)-poi_crd(i,1))<=res_lat*factor);             
                    % Loop over this grid
                    for j = 1:length(ind_lat)
                        for k = 1:length(ind_lon)
                            % Restore data for each grid point
                            p_a = squeeze(p(ind_lon(k),ind_lat(j),:));
                            H_a = squeeze(H(ind_lon(k),ind_lat(j),:));
                            T_a = squeeze(T(ind_lon(k),ind_lat(j),:));
                            e_a = squeeze(e(ind_lon(k),ind_lat(j),:));
                            lat_a = squeeze(lat(ind_lon(k),ind_lat(j),1));
                            % Vertical interpolation to POI's height
                            [p1(j,k),H1(j,k),T1(j,k),e1(j,k)] = vertical_interp(p_a,H_a,T_a,e_a,lat_a,poi_crd(i,3),'Pressure levels');
                        end
                    end      
                    % Lat/Lon grid
                    lat_grid = lat(ind_lon,ind_lat,1);
                    lon_grid = lon(ind_lon,ind_lat,1);
                    % Horizontal interpolation to voxel center points
                    vox_T = interp2(lat_grid,lon_grid,T1(:,:)',poi_crd(i,1),poi_crd(i,2),hi_str{hi_val});
                    vox_e = interp2(lat_grid,lon_grid,e1(:,:)',poi_crd(i,1),poi_crd(i,2),hi_str{hi_val});
                    vox_p = interp2(lat_grid,lon_grid,p1(:,:)',poi_crd(i,1),poi_crd(i,2),hi_str{hi_val});
                    % Set standard deviation
                    if get(handles.N_apr_stddev_sel,'Value') == 1
                        % Recompute specific humidity [kg/kg]
                        vox_Q = 0.62198*vox_e/vox_p/(1-0.37802*vox_e/vox_p);                            
                        % Compute standard deviations acc to values defined in Steiner et al. (2006)
                        [stdNh,stdNw] = comp_stddev(vox_p,vox_T,vox_Q,poi_crd(i,3)/1000);
                    else
                        stdNh = 0; stdNw = 0;
                    end
                    %Compute refractivity field
                    [N_h,N_w]  = comp_N(vox_p,vox_T,vox_e);
                    % Store data in text file
                    fprintf(out,'%9.5f %10.5f %7.1f %6.3f %6.2f %7.2f %8.3f %7.3f %8.3f %7.3f %6.3f %6.3f\n',poi_crd(i,1),poi_crd(i,2),poi_crd(i,3),vox_e,vox_T,vox_p,N_h+N_w,N_w,0,0,sqrt(stdNh^2+stdNw^2),stdNw);
                    clear p1 H1 T1 e1 vox_T vox_e vox_p
                end                
            % Compute zenith delays for POIs
            case 'N_apr_source_button2'                  
                % Horizontal interpolation option
                hi_str = get(handles.N_apr_opt2_popup,'String');
                hi_val = get(handles.N_apr_opt2_popup,'Value');
                % Define grid width around POI
                switch hi_str{hi_val}
                    case 'Nearest'
                        factor = 1; % Grid points in distance 1*res_lat
                    case 'Linear'
                        factor = 2; % Grid points in distance 2*res_lat
                    case 'Spline'
                        factor = 3; % Grid points in distance 3*res_lat
                end
                % Check selected POIs
                switch get(get(handles.N_apr_buttongroup1,'SelectedObject'),'Tag')      
                    % Case voxel model
                    case 'N_apr_POI_button1'
                        % Get number of grid points and height of lowest layers
                        n_poi = length(poi_crd(:,1))/length(unique(poi_crd(:,3)));
                        href  = zeros(n_poi,1) + min(poi_crd(:,3));
                        % Station names
                        sta = 1:n_poi;
                        sta = cellstr(num2str(sta','%4.4d'));
                    % Case coordinate file
                    case 'N_apr_POI_button2'
                        % Get number of grid points and height of lowest layers
                        n_poi = length(poi_crd(:,1));
                        href  = poi_crd(:,3);
                        % Station names from file
                        sta_str = get(handles.N_apr_station_list,'String');
                        sta_val = get(handles.N_apr_station_list,'Value');
                        sta = sta_str(sta_val);                        
                end
                % Loop over all ground voxels
                for i = 1:n_poi
                    waitbar(i/n_poi,h);
                    % Find closest grid nodes for each voxel center point
                    [ind_lon]=find(abs(lon(:,1,1)-poi_crd(i,2))<=res_lon*factor);
                    [ind_lat]=find(abs(lat(1,:,1)-poi_crd(i,1))<=res_lat*factor);
                    % Check if ind_lat or ind_lon is empty
                    if isempty(ind_lat) || isempty(ind_lon)
                        close(h)
                        set(handles.N_apr_status_text,'String','Error: Station beyond NWM grid');
                        return
                    end
                    % Compute mean height of each pressure level
                    H_mean = squeeze(mean(mean(H(ind_lon,ind_lat,:))));
                    % Loop over this grid
                    for j = 1:length(ind_lat)
                        for k = 1:length(ind_lon)
                            % Restore data for each grid point
                            p_a = squeeze(p(ind_lon(k),ind_lat(j),:));
                            H_a = squeeze(H(ind_lon(k),ind_lat(j),:));
                            T_a = squeeze(T(ind_lon(k),ind_lat(j),:));
                            e_a = squeeze(e(ind_lon(k),ind_lat(j),:));
                            lat_a = squeeze(lat(ind_lon(k),ind_lat(j),1));
                            % Vertical interpolation to POI's height
                            [p1(j,k,:),H1(j,k,:),T1(j,k,:),e1(j,k,:)] = vertical_interp(p_a,H_a,T_a,e_a,lat_a,H_mean,'Pressure levels');
                        end
                    end
                    % Lat/Lon grid
                    lat_grid = lat(ind_lon,ind_lat,1);
                    lon_grid = lon(ind_lon,ind_lat,1);
                    % Loop over height layers
                    for ht = 1:length(H_mean)                                      
                        % Horizontal interpolation to voxel center points
                        inc_T(ht) = interp2(lat_grid,lon_grid,T1(:,:,ht)',poi_crd(i,1),poi_crd(i,2),hi_str{hi_val});
                        inc_e(ht) = interp2(lat_grid,lon_grid,e1(:,:,ht)',poi_crd(i,1),poi_crd(i,2),hi_str{hi_val});
                        inc_p(ht) = interp2(lat_grid,lon_grid,p1(:,:,ht)',poi_crd(i,1),poi_crd(i,2),hi_str{hi_val});                        
                        inc_h(ht) = H_mean(ht);
                    end
                    % Vertical increment according to Rocken et al. (2001)
                    [p2,H2,T2,e2] = vertical_increment(inc_p,inc_h,inc_T,inc_e,poi_crd(i,1),href(i),0);
                    % Compute ZHD and ZWD by vertical integration
                    ray = delay2D_grid(p2,H2',T2,e2,href(i),90,poi_crd(i,1));
                    % Compute ZHD with Formula from Saastamoinen
                    %ZHD = saasthyd(p2(1),poi_crd(i,1)/180*pi,H2(1));
                    % Store data in text file
                    fprintf(out,'%4s %9.5f %10.5f %7.1f %7.4f %7.4f\n',sta{i},poi_crd(i,1),poi_crd(i,2),href(i),ray.dz_h+ray.dz_w,ray.dz_w);   
                    clear p1 H1 T1 e1 inc_T inc_e inc_p inc_h
                end
        end
        set(handles.N_apr_status_text,'String','Done! Check output file');
        % Close waitbar
        close(h);
    case 'Refractivity fields'          
        % Get data from *.N file
        dat = handles.N_apr_input2_data;
        % Number of values (nlat,nlon,np)
        nlat = length(unique(dat(:,1)));
        nlon = length(unique(dat(:,2)));
        np   = length(unique(dat(:,3)));
        % Reshape vector to grid (nlon,nlat,np)
        lat   = reshape(dat(:,1),nlon,nlat,np);
        lon   = reshape(dat(:,2),nlon,nlat,np);
        H     = reshape(dat(:,3),nlon,nlat,np);
        e     = reshape(dat(:,4),nlon,nlat,np);
        T     = reshape(dat(:,5),nlon,nlat,np);
        p     = reshape(dat(:,6),nlon,nlat,np);
        N     = reshape(dat(:,9),nlon,nlat,np);
        Nw    = reshape(dat(:,10),nlon,nlat,np);
        sigN  = reshape(dat(:,11),nlon,nlat,np);
        sigNw = reshape(dat(:,12),nlon,nlat,np);
        % Resolution 
        if nlat >= 2 && nlon >=2
            res_lat = abs(lat(1,2,1)-lat(1,1,1));
            res_lon = abs(lon(2,1,1)-lon(1,1,1));
        else
            set(handles.N_apr_status_text,'String','Error: Resolution of input data cannot be computed, dataset to small');
            return
        end
        % Restore POI crd - lon[-180 180] to lon[0 360]
        poi_crd(:,2) = mod(poi_crd(:,2),360);
        % Create waitbar
        h = waitbar(0,'Please wait...','WindowStyle','modal');
        % Read selection of output parameters        
        switch get(get(handles.N_apr_buttongroup2,'SelectedObject'),'Tag')
            % Compute refractivities
            case 'N_apr_source_button1'             
                % Horizontal interpolation option
                hi_str = get(handles.N_apr_opt2_popup,'String');
                hi_val = get(handles.N_apr_opt2_popup,'Value');
                % Define grid width around POI
                switch hi_str{hi_val}
                    case 'Nearest'
                        factor = 1;
                    case 'Linear'
                        factor = 2; % Grid points in distance 2*res_lat
                    case 'Spline'
                        factor = 3; % Grid points in distance 3*res_lat
                end
                % Initialise variables                
                n_poi  = length(poi_crd(:,1));
                % Loop over all grid points
                for i = 1:n_poi
                    % Fill wait bar
                    waitbar(i/n_poi,h);
                    % Find closest grid nodes for each voxel center point  
                    [ind_lon]=find(abs(lon(:,1,1)-poi_crd(i,2))<=res_lon*factor);
                    [ind_lat]=find(abs(lat(1,:,1)-poi_crd(i,1))<=res_lat*factor);
                    % Loop over this grid
                    for j = 1:length(ind_lat)
                        for k = 1:length(ind_lon)
                            % Restore data for each grid point
                            H_a   = squeeze(H(ind_lon(k),ind_lat(j),:));
                            e_a   = squeeze(e(ind_lon(k),ind_lat(j),:));
                            T_a   = squeeze(T(ind_lon(k),ind_lat(j),:));
                            p_a   = squeeze(p(ind_lon(k),ind_lat(j),:));
                            N_a   = squeeze(N(ind_lon(k),ind_lat(j),:));
                            Nw_a  = squeeze(Nw(ind_lon(k),ind_lat(j),:));
                            sN_a  = squeeze(sigN(ind_lon(k),ind_lat(j),:));
                            sNw_a = squeeze(sigNw(ind_lon(k),ind_lat(j),:));                        
                            % Vertical interpolation to POI�s height
                            e1(k,j)   = interp1(H_a,  e_a,poi_crd(i,3));
                            T1(k,j)   = interp1(H_a,  T_a,poi_crd(i,3));
                            p1(k,j)   = interp1(H_a,  p_a,poi_crd(i,3));
                            N1(k,j)   = interp1(H_a,  N_a,poi_crd(i,3));
                            Nw1(k,j)  = interp1(H_a, Nw_a,poi_crd(i,3));
                            sN1(k,j)  = interp1(H_a, sN_a,poi_crd(i,3));
                            sNw1(k,j) = interp1(H_a,sNw_a,poi_crd(i,3));
                        end
                    end                    
                    % Lat/Lon grid
                    lat_grid = lat(ind_lon,ind_lat,1);
                    lon_grid = lon(ind_lon,ind_lat,1);
                    % Horizontal interpolation to voxel center points
                    vox_e     = interp2(lat_grid,lon_grid,  e1(:,:),poi_crd(i,1),poi_crd(i,2),hi_str{hi_val});
                    vox_T     = interp2(lat_grid,lon_grid,  T1(:,:),poi_crd(i,1),poi_crd(i,2),hi_str{hi_val});
                    vox_p     = interp2(lat_grid,lon_grid,  p1(:,:),poi_crd(i,1),poi_crd(i,2),hi_str{hi_val});
                    vox_Napr  = interp2(lat_grid,lon_grid,  N1(:,:),poi_crd(i,1),poi_crd(i,2),hi_str{hi_val});
                    vox_Nwapr = interp2(lat_grid,lon_grid, Nw1(:,:),poi_crd(i,1),poi_crd(i,2),hi_str{hi_val});
                    vox_sN    = interp2(lat_grid,lon_grid, sN1(:,:),poi_crd(i,1),poi_crd(i,2),hi_str{hi_val});
                    vox_sNw   = interp2(lat_grid,lon_grid,sNw1(:,:),poi_crd(i,1),poi_crd(i,2),hi_str{hi_val});
                    % Store data in text file
                    fprintf(out,'%9.5f %10.5f %7.1f %6.3f %6.2f %7.2f %8.3f %7.3f %8.3f %7.3f %6.3f %6.3f\n',poi_crd(i,1),poi_crd(i,2),poi_crd(i,3),vox_e,vox_T,vox_p,vox_Napr,vox_Nwapr,0,0,vox_sN,vox_sNw);
                    clear e1 T1 p1 N1 Nw1 sN1 sNw1
                end
            % Compute zenith delays for POIs
            case 'N_apr_source_button2'          
                % Horizontal interpolation option
                hi_str = get(handles.N_apr_opt2_popup,'String');
                hi_val = get(handles.N_apr_opt2_popup,'Value');
                % Define grid width around POI
                switch hi_str{hi_val}
                    case 'Nearest'
                        factor = 1; % Grid points in distance 1*res_lat
                    case 'Linear'
                        factor = 2; % Grid points in distance 2*res_lat
                    case 'Spline'
                        factor = 3; % Grid points in distance 3*res_lat
                end
                switch get(get(handles.N_apr_buttongroup1,'SelectedObject'),'Tag')
                    % Case voxel model
                    case 'N_apr_POI_button1'
                        % Get number of grid points and height of lowest layers
                        n_poi = length(poi_crd(:,1))/length(unique(poi_crd(:,3)));
                        href  = zeros(n_poi,1) + min(poi_crd(:,3));
                        % Station names
                        sta = 1:n_poi;
                        sta = cellstr(num2str(sta','%4.4d'));                        
                    case 'N_apr_POI_button2'
                        % Get number of grid points and height of lowest layers
                        n_poi = length(poi_crd(:,1));
                        href  = poi_crd(:,3);
                        % Station names from file
                        sta_str = get(handles.N_apr_station_list,'String');
                        sta_val = get(handles.N_apr_station_list,'Value');
                        sta = sta_str(sta_val);                    
                end
                % Predefined height layers 
                h_inc = [0:10:2000,2020:20:6000,6050:50:16000,16100:100:36000,36500:500:136000];                    
                % Loop over all grid points
                for i = 1:n_poi
                    % Fill wait bar
                    waitbar(i/n_poi,h);
                    % Find closest grid nodes for each voxel center point                    
                    [ind_lon]=find(abs(lon(:,1,1)-poi_crd(i,2))<=res_lon*factor);
                    [ind_lat]=find(abs(lat(1,:,1)-poi_crd(i,1))<=res_lat*factor);
                    % Check if ind_lat or ind_lon is empty
                    if length(ind_lat) < 2 || length(ind_lon) < 2
                        close(h)
                        set(handles.N_apr_status_text,'String','Error: Station beyond grid');
                        return
                    end               
                    % Compute mean height of each pressure level
                    H_mean = squeeze(mean(mean(H(ind_lon,ind_lat,:))));   
                    % Loop over this grid
                    for j = 1:length(ind_lat)
                        for k = 1:length(ind_lon)
                            % Restore data for each grid point
                            H_a  = squeeze(H(ind_lon(k),ind_lat(j),:));
                            N_a  = squeeze(N(ind_lon(k),ind_lat(j),:));
                            Nw_a = squeeze(Nw(ind_lon(k),ind_lat(j),:));
                            % Vertical interpolation 
                            N1(k,j,:)  = interp1(H_a, N_a,H_mean,'linear','extrap');
                            Nw1(k,j,:) = interp1(H_a,Nw_a,H_mean,'linear','extrap');
                        end
                    end
                    % Lat/Lon grid
                    lat_grid = lat(ind_lon,ind_lat,1);
                    lon_grid = lon(ind_lon,ind_lat,1);
                    % Loop over height layers
                    for ht = 1:length(H_mean)      
                        % Horizontal interpolation to voxel center points
                        inc_N(ht)  = interp2(lat_grid,lon_grid, N1(:,:,ht),poi_crd(i,1),poi_crd(i,2),hi_str{hi_val});
                        inc_Nw(ht) = interp2(lat_grid,lon_grid,Nw1(:,:,ht),poi_crd(i,1),poi_crd(i,2),hi_str{hi_val});
                        inc_h(ht)  = H_mean(ht);
                    end
                    % Vertical increment
                    N2  = interp1(inc_h,inc_N,h_inc);
                    Nw2 = interp1(inc_h,inc_Nw,h_inc);
                    % Set all negative values and NaN to zero
                    N2(isnan(N2))   = 0; N2(N2 < 0)   = 0;
                    Nw2(isnan(Nw2)) = 0; Nw2(Nw2 < 0) = 0;
                    % Compute ZHD and ZWD
                    ray = delay2D_Nstart(N2'-Nw2',Nw2',h_inc',href(i),90,poi_crd(i,1));
                    % Store data in text file
                    fprintf(out,'%4s %9.5f %10.5f %7.1f %7.4f %7.4f\n',sta{i},poi_crd(i,1),poi_crd(i,2),href(i),ray.dz_h+ray.dz_w,ray.dz_w);   
                    clear N1 Nw1 N2 Nw2
                end
        end
        % Close waitbar
        close(h);
end
fclose(out);

% ------------------------ Output file name ------------------------------
function N_apr_output_com_Callback(hObject, eventdata, handles)

function N_apr_output_com_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(handles.N_apr_output_com)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function N_apr_output_com_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --------------------------- Show data ----------------------------------
function N_apr_data_show_Callback(hObject, eventdata, handles)
% File name
fname = get(handles.N_apr_output_com,'String');
% Read and store data
fid = fopen(fname,'r');
if fid > 0     
    if strcmp(fname(end-3:end),'Napr')
        dat = textscan(fid,'%f %f %f %f %f %f %f %f %f %f %f %f');
        handles.N_apr_data_show_data = [cellstr(num2str(dat{1},'%7.3f')),...
            cellstr(num2str(dat{2},'%8.3f')),cellstr(num2str(dat{3},'%8.1f')),...
            cellstr(num2str(dat{4},'%6.2f')),cellstr(num2str(dat{5},'%6.2f')),...
            cellstr(num2str(dat{6},'%7.2f')),cellstr(num2str(dat{7},'%6.2f')),...
            cellstr(num2str(dat{8},'%8.3f')),cellstr(num2str(dat{9},'%7.3f')),...
            cellstr(num2str(dat{10},'%6.2f')),cellstr(num2str(dat{11},'%6.3f')),...
            cellstr(num2str(dat{12},'%6.3f'))];         
        handles.N_apr_data_show_cont = {'Lat [�]';'Lon [�]';'H [m]';...
            'e_apr [hPa]';'T_apr [K]';'p_apr [hPa]';'N_apr [ppm]';'Nw_apr [ppm]';...
            'N [ppm]';'Nw [ppm]';'Sig N [ppm]';'Sig Nw [ppm]'};        
    elseif strcmp(fname(end-3:end),'.ZTD')
        dat = textscan(fid,'%s %f %f %f %f %f');
        handles.N_apr_data_show_data = [cellstr(dat{1}),...
            cellstr(num2str(dat{2},'%7.3f')),cellstr(num2str(dat{3},'%8.3f')),...
            cellstr(num2str(dat{4},'%8.2f')),cellstr(num2str(dat{5},'%7.4f')),...
            cellstr(num2str(dat{6},'%7.4f'))]; 
        handles.N_apr_data_show_cont = {'Station';'Lat [�]';'Lon [�]';'H [m]';...
            'ZTD [m]';'ZWD [m]'};        
    end    
    set(handles.N_apr_data_table,'Data',handles.N_apr_data_show_data);
    set(handles.N_apr_data_table,'ColumnName',handles.N_apr_data_show_cont);
else
    set(handles.N_apr_status_text,'String','Output file does not exist');
    return
end
fclose(fid);

% -------------------------- Clear all -----------------------------------
function N_apr_clear_all_Callback(hObject, eventdata, handles)
% Reset
set(handles.N_apr_POI_button1,'Value',1)
set(handles.N_apr_input3_headline,'String',{'No file'});
set(handles.N_apr_input1_list,'String',{'No file'});
set(handles.N_apr_input2_list,'String',{'No file'});
set(handles.N_apr_input3_list,'String',{});
set(handles.N_apr_grid1_list,'String',{'No epoch'});
set(handles.N_apr_grid1_list,'Value',1);
set(handles.N_apr_height_list,'String',{'No heights'});
set(handles.N_apr_height_list,'Value',1);
set(handles.N_apr_station_headline,'String',{'Selected: 0'})
set(handles.N_apr_station_list,'String',{'No station'})
set(handles.N_apr_station_list,'Value',1)
set(handles.N_apr_station_list,'Enable','Off')
set(handles.N_apr_input3_list,'Enable','Off')
set(handles.N_apr_input3_open,'Enable','Off')
set(handles.N_apr_input3_load,'Enable','Off')
set(handles.N_apr_input3_headline,'Enable','Off')
set(handles.N_apr_opt1_popup,'Value',2)
set(handles.N_apr_source_button1,'Value',1)
set(handles.N_apr_opt2_popup,'Value',2)
set(handles.N_apr_data_table,'Data',[])
handles.N_apr_input1_data = [];
handles.N_apr_input2_data = [];


%% ------------------------ Sub-panel 3D Tomography ----------------------
function uipanel_N_new_CreateFcn(hObject, eventdata, handles)

% --------------------------- SWD/STD (Input 1) --------------------------
function N_new_input1_open_Callback(hObject, eventdata, handles)
% Read file names
[filename1, handles.N_new_input1_pathname1] = uigetfile({...
    '*SWD','Slant Wet delays';...
    '*STD','Slant Total delays';...
    '*SWDe','Slant Wet delays COST-format'},...
    'Select File',handles.atom_start_input,'MultiSelect','on');
% Pass file names to listbox
if isequal(filename1,0)
    set(handles.N_new_input1_list,'String',{'No file'});
    set(handles.N_new_input1_list,'Value',1)
else    
    set(handles.N_new_input1_list,'String',cellstr(filename1));
    set(handles.N_new_input1_list,'Value',1)
end
guidata(hObject, handles);

function N_new_input1_list_Callback(hObject, eventdata, handles)
% Set the limit of files which can be selected
set(hObject,'min',0,'max',1000);
% Use 'Entf to delete entries in listbox
set(hObject,'keypressfcn',@key_check)
guidata(hObject, handles);

function N_new_input1_list_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function N_new_input1_load_Callback(hObject, eventdata, handles)
% Read file names in listbox
str = get(handles.N_new_input1_list,'String');
val = get(handles.N_new_input1_list,'Value');
% Check if files exist
if strcmp(str,'No file') ~= 1
    % Initialise variables
    handles.N_new_input1_data = [];
    handles.N_new_input1_cont = [];
    handles.N_new_input1_sta  = {};
    handles.N_new_input1_sat  = {};
    % Create waitbar
    h = waitbar(0,'Please wait...','WindowStyle','modal');
    % Loop to read each input file
    for i = 1:length(val)
        % Fill wait bar
        waitbar(i/length(val),h);
        % Path name
        fullpathname = strcat(handles.N_new_input1_pathname1,str{val(i)});  
        % Read slant delays        
        if strcmp(fullpathname(end-2:end),'SWD')
            [dat1,dat2,sta,sat] = read_SWD(fullpathname);
            set(handles.N_new_button_Nwet,'Value',1)
        elseif strcmp(fullpathname(end-2:end),'STD')
            [dat1,dat2,sta,sat] = read_STD(fullpathname);
            set(handles.N_new_button_Ntot,'Value',1)
        elseif strcmp(fullpathname(end-3:end),'SWDe')
            [dat1,dat2,sta,sat] = read_SWDe(fullpathname);
        end
        % Restore data
        handles.N_new_input1_data = [handles.N_new_input1_data,dat1];
        handles.N_new_input1_cont = dat2;
        handles.N_new_input1_sta  = [handles.N_new_input1_sta;sta];
        handles.N_new_input1_sat  = [handles.N_new_input1_sat;sat];     
    end
    % Close waitbar
    close(h)
    % List of stations
    set(handles.N_new_station_list1,'Value',1);
    set(handles.N_new_station_list1,'String',unique(handles.N_new_input1_sta));  
    % Set time parameter
    mjd1 = min(handles.N_new_input1_data(2,:));
    mjd2 = max(handles.N_new_input1_data(2,:));
    [yy1,mm1,dd1] = jd2cal(fix(mjd1)+2400000.5);
    [yy2,mm2,dd2] = jd2cal(fix(mjd2)+2400000.5);
    set(handles.N_new_t1_day,'String',sprintf('%4d-%2.2d-%2.2d',yy1,mm1,dd1))
    set(handles.N_new_t1_sec,'String',sprintf('%1.0f',round((mjd1-fix(mjd1))*86400)))
    set(handles.N_new_te_day,'String',sprintf('%4d-%2.2d-%2.2d',yy2,mm2,dd2))
    set(handles.N_new_te_sec,'String',sprintf('%1.0f',round((mjd2-fix(mjd2))*86400)))
    set(handles.N_new_tstack_text2,'String',sprintf('epochs (max: %d)',length(unique(handles.N_new_input1_data(2,:)))));
end
guidata(hObject, handles);

% ----------------------------- Station list -----------------------------
function N_new_station_list1_Callback(hObject, eventdata, handles)
% Set the limit of files which can be selected
set(hObject,'min',0,'max',1000);
% Use 'Entf to delete entries in listbox
set(hObject,'keypressfcn',@key_check)
guidata(hObject, handles);

function N_new_station_list1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ----------------------------- crd (Input 3) ----------------------------
function N_new_input3_open_Callback(hObject, eventdata, handles)
% Read file names
[filename1, handles.N_new_input3_pathname1] = uigetfile({...
    '*.NEU','NEU coordinate file'},...
    'Select File',handles.atom_start_input,'MultiSelect','on');
% Pass file names to listbox
if isequal(filename1,0)
    set(handles.N_new_input3_filename,'String',{'No file'});
else
    set(handles.N_new_input3_filename,'String',cellstr(filename1));
    set(handles.N_new_status_text,'String','Load CRD file');
end
guidata(hObject, handles);

function N_new_input3_load_Callback(hObject, eventdata, handles)
% Read filename
str = get(handles.N_new_input3_filename,'String');
if strcmp(str,'No file') ~= 1
    % Read stations
    str1 = get(handles.N_new_station_list1,'String');
    val1 = get(handles.N_new_station_list1,'Value');
    % If at least 1 file exist and at leas 1 baseline is selected
    if isequal(str,'No file') ~= 1 && isequal(str1,'No station') ~= 1
        % Clear list
        set(handles.N_new_input3_list,'String','');
        % Set path name of coordinate file   
        fullpathname = strcat(handles.N_new_input3_pathname1,str{1});
        % Create statlist
        statlist = cellstr(str1(val1));
        % Read coordinates from file
        [dat1,dat2] = read_NEU(fullpathname,statlist,handles);
        handles.N_new_input3_crd = dat1;
        handles.N_new_input3_sta = dat2;
        id = find(dat1 == 0,1);
        if ~isempty(id)
            set(handles.N_new_status_text,'String',[statlist{id},' not found! Please select CRD file with coordinates for all stations'])
        else
            set(handles.N_new_input3_list,'String',dat2);
            set(handles.N_new_status_text,'String','CRD loaded for selected GNSS stations');
            set(handles.N_new_input3_list,'Value',[]);
        end 
    else
       set(handles.N_new_status_text,'String','No file or no station selected'),
    end
    guidata(hObject, handles);
end
% Get layer list entries
str = get(handles.N_new_layer_list1,'String');
val = get(handles.N_new_layer_list1,'Value');
if ~strcmp(str,'No layer')
    % Plot voxel geometry in axes1
    voxel_geometry(val,handles.N_new_axes1,handles);
end

function N_new_input3_list_Callback(hObject, eventdata, handles)
% Set the limit of files which can be selected
set(hObject,'min',0,'max',1);
% Use 'Entf to delete entries in listbox
set(hObject,'keypressfcn',@key_check)
guidata(hObject, handles);

function N_new_input3_list_CreateFcn(hObject, eventdata, handles)

% ----------------------------- N_apr (Input 2) --------------------------
function N_new_input2_open_Callback(hObject, eventdata, handles)
% Read file names
[filename1, handles.N_new_input2_pathname1] = uigetfile({...
    '*Napr','A priori refractivity fields';...
    '*N','Improved refractivity fields';...
    '*Nw','Refractivity fields in COST-format'},...
    'Select File',handles.atom_start_input,'MultiSelect','on');
% Pass file names to listbox
if isequal(filename1,0)
    set(handles.N_new_input2_list,'String',{'No file'});
    set(handles.N_new_input2_list,'Value',1)
else    
    set(handles.N_new_input2_list,'String',cellstr(filename1));
    set(handles.N_new_input2_list,'Value',1)
end
guidata(hObject, handles);

function N_new_input2_list_Callback(hObject, eventdata, handles)
% Set the limit of files which can be selected
set(hObject,'min',0,'max',1000);
% Use 'Entf to delete entries in listbox
set(hObject,'keypressfcn',@key_check)
guidata(hObject, handles);

function N_new_input2_list_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function N_new_input2_load_Callback(hObject, eventdata, handles)
% Read file names in listbox
str = get(handles.N_new_input2_list,'String');
val = get(handles.N_new_input2_list,'Value');
% Check if files exist
if strcmp(str,'No file') ~= 1
    % Initialise variables
    handles.N_new_input2_data = [];
    handles.N_new_input2_cont = [];
    % Create waitbar
    h = waitbar(0,'Please wait...','WindowStyle','modal');
    % Loop to read each input file
    for i = 1:length(val)
        % Fill wait bar
        waitbar(i/length(val),h);
        % Path name
        fullpathname = strcat(handles.N_new_input2_pathname1,str{val(i)});
        if strcmp(fullpathname(end-3:end),'Napr')
            % Read a priori Napr
            [dat1,dat2] = read_refr(fullpathname);
            %[dat1,dat2] = read_Napr(fullpathname);
        elseif strcmp(fullpathname(end),'N')
            [dat1,dat2] = read_refr(fullpathname);          
        elseif strcmp(fullpathname(end-1:end),'Nw')
            % Read a priori Nw
            [dat1,dat2] = read_Nw(fullpathname);
        end
        % Store data in handles vector
        handles.N_new_input2_data = [handles.N_new_input2_data,dat1];
        handles.N_new_input2_cont = [handles.N_new_input2_cont,dat2];
    end
    if ~isempty(handles.N_new_input2_data{1})
        % Get record number
        id_lat = strcmp(handles.N_new_input2_cont,'Lat [�]');
        id_lon = strcmp(handles.N_new_input2_cont,'Lon [�]');
        id_H   = strcmp(handles.N_new_input2_cont,'H [m]');
        id_wet = strcmp(handles.N_new_input2_cont,'Nw_apr [ppm]');
        id_tot = strcmp(handles.N_new_input2_cont,'N_apr [ppm]');
        % Available points / layer
        handles.N_new_lat_vec = unique(dat1{id_lat});
        handles.N_new_lon_vec = unique(dat1{id_lon});
        handles.N_new_H_vec   = unique(dat1{id_H});
        n_lat = length(handles.N_new_lat_vec);
        n_lon = length(handles.N_new_lon_vec);
        n_H   = length(handles.N_new_H_vec);
        % Get refractivities and reshape
        Nw = reshape(handles.N_new_input2_data{id_wet},n_lon,n_lat,n_H);
        Nh = reshape(handles.N_new_input2_data{id_tot}-handles.N_new_input2_data{id_wet},n_lon,n_lat,n_H);
        % Get first layer entries to show
        Nw = Nw(:,:,1);
        Nh = Nh(:,:,1);
        % List of layer
        set(handles.N_new_layer_list1,'Value',1);
        set(handles.N_new_layer_list1,'String',handles.N_new_H_vec);
        % Read buttongroup (output)
        switch get(get(handles.N_new_buttongroup_Napr,'SelectedObject'),'Tag')
            case 'N_new_button_Nwet'; handles.N_new_Napr_show = Nw;
            case 'N_new_button_Ntot'; handles.N_new_Napr_show = Nw + Nh;
        end
        % Check number of available height levels
        if n_H > 1
            % Plot voxel geometry in axes1
            voxel_geometry(1,handles.N_new_axes1,handles);
        else
            set(handles.N_new_status_text,'String','Error: Napr field containts not enough layers');
            return
        end
        
        % Set current axes to axes2
        axes(handles.N_new_axes2);
        % Set axes2 headline
        nlayer = get(handles.N_new_layer_list1,'Value');
        set(handles.N_new_axes2_headline,'String',['A priori refractivity field [ppm] - layer' num2str(nlayer)]);    
        % Plot a priori values of the first layer
        bar3c(handles.N_new_Napr_show);
        colormap(pink);
        % Ratio axes
        if max(max(handles.N_new_Napr_show)) == 0; ratio_z = 0.2; else ratio_z = max(max(handles.N_new_Napr_show))*0.1; end
        daspect([.67 1 ratio_z]);
        axis tight; % delete empty spaces
        % Set xtick and ytick and labels
        set(handles.N_new_axes2,'xtick',[1,round(n_lat/2),n_lat])
        set(handles.N_new_axes2,'xticklabel',{handles.N_new_lat_vec(1),handles.N_new_lat_vec(round(n_lat/2)),handles.N_new_lat_vec(end)})
        set(handles.N_new_axes2,'ytick',[1,round(n_lon/2),n_lon])    
        set(handles.N_new_axes2,'yticklabel',{handles.N_new_lon_vec(1),handles.N_new_lon_vec(round(n_lon/2)),handles.N_new_lon_vec(end)})
        % Close waitbar
        close(h)
        % Set output file name
        if strcmp(fullpathname(end-3:end),'Napr')
            set(handles.N_new_output_com,'String',[handles.atom_start_output '\' str{val(i)}(1:end-5) '.N']);
        elseif strcmp(fullpathname(end-1:end),'Nw')
            set(handles.N_new_output_com,'String',[handles.atom_start_output '\' str{val(i)}(1:end-3) '.N']);
        elseif strcmp(fullpathname(end),'N')
            str_daye = get(handles.N_new_te_day,'String');
            %sec1 = str2double(get(handles.N_new_t1_sec,'String'));
            sece = str2double(get(handles.N_new_te_sec,'String'));
            hr = floor(sece/3600); mn = floor((sece/3600-hr)*60);
            %set(handles.N_new_output_com,'String',[handles.atom_start_output '\' str_daye(1:4) str_daye(6:7) str_daye(9:10) sprintf('%2.2d',hr) '.N']);
            set(handles.N_new_output_com,'String',[handles.atom_start_output '\' str_daye(1:4) str_daye(6:7) str_daye(9:10) sprintf('%2.2d%2.2d',hr,mn) '.N']);
        end
    else
        set(handles.N_new_status_text,'String','Error: A priori refractivity field is empty')
        close(h)
        return
    end
end
guidata(hObject, handles);

% ----------------------------- Layer list -------------------------------
function N_new_layer_list1_Callback(hObject, eventdata, handles)
% Get layer
val = get(hObject,'Value');
% Available points / layer
n_lat = length(handles.N_new_lat_vec);
n_lon = length(handles.N_new_lon_vec);
n_H   = length(handles.N_new_H_vec);
% Get record number
id_wet = strcmp(handles.N_new_input2_cont,'Nw_apr [ppm]');
id_tot = strcmp(handles.N_new_input2_cont,'N_apr [ppm]');
% Get refractivities and reshape
Nw = reshape(handles.N_new_input2_data{id_wet},n_lon,n_lat,n_H);
Nh = reshape(handles.N_new_input2_data{id_tot}-handles.N_new_input2_data{id_wet},n_lon,n_lat,n_H);
Nw = Nw(:,:,val);
Nh = Nh(:,:,val);
% Read buttongroup (output)
switch get(get(handles.N_new_buttongroup_Napr,'SelectedObject'),'Tag')
    case 'N_new_button_Nwet'; handles.N_new_Napr_show = Nw;
    case 'N_new_button_Ntot'; handles.N_new_Napr_show = Nw + Nh;
end
% Plot voxel geometry in axes1
voxel_geometry(val,handles.N_new_axes1,handles);
% Plot a priori refractivity field
% Set current axes to axes2
axes(handles.N_new_axes2);
% Set axes2 headline
set(handles.N_new_axes2_headline,'String',['A priori refractivity field [ppm] - layer' num2str(val)]);
% Plot a priori values
bar3c(handles.N_new_Napr_show);
colormap(pink); 
% Ratio axes
if max(max(abs(handles.N_new_Napr_show))) == 0; ratio = 0.1; else; ratio = max(max(handles.N_new_Napr_show))*0.1; end
daspect([.67 1 ratio]);
axis tight; % delete empty spaces
% Set xtick and ytick and labels
set(handles.N_new_axes2,'xtick',[1,round(n_lat/2),n_lat])
set(handles.N_new_axes2,'xticklabel',{handles.N_new_lat_vec(1),handles.N_new_lat_vec(round(n_lat/2)),handles.N_new_lat_vec(end)})
set(handles.N_new_axes2,'ytick',[1,round(n_lon/2),n_lon])    
set(handles.N_new_axes2,'yticklabel',{handles.N_new_lon_vec(1),handles.N_new_lon_vec(round(n_lon/2)),handles.N_new_lon_vec(end)})
guidata(hObject, handles);
% Plot improved refractivity field
% Check if improved refractivity field is avaiable
if isfield(handles,'N_new_Nimp')
    % Get data for selected layer
    val = get(handles.N_new_layer_list1,'Value');
    if get(handles.N_new_plot_diff,'Value') == 0
        handles.N_new_Nimp_show = handles.N_new_Nimp(:,:,val);
        mul = 1;
    else
        handles.N_new_Nimp_show = handles.N_new_Nimp(:,:,val)-handles.N_new_Napr_show;
        mul = 2;
    end
    % Set current axes to axes3
    axes(handles.N_new_axes3);
    % Set axes2 headline
    set(handles.N_new_axes3_headline,'String',['Improved refractivity field [ppm] - layer' num2str(val)]);
    % Plot a priori values
    bar3c(handles.N_new_Nimp_show);
    colormap(pink); 
    % Ratio axes
    if max(max(abs(handles.N_new_Nimp_show))) == 0; ratio = 0.2; else ratio = mul*max(max(abs(handles.N_new_Nimp_show)))*0.1; end
    daspect([.67 1 ratio]);
    axis tight; % delete empty spaces
    % Set xtick and ytick and labels
    set(handles.N_new_axes3,'xtick',[1,round(n_lat/2),n_lat])
    set(handles.N_new_axes3,'xticklabel',{handles.N_new_lat_vec(1),handles.N_new_lat_vec(round(n_lat/2)),handles.N_new_lat_vec(end)})
    set(handles.N_new_axes3,'ytick',[1,round(n_lon/2),n_lon])    
    set(handles.N_new_axes3,'yticklabel',{handles.N_new_lon_vec(1),handles.N_new_lon_vec(round(n_lon/2)),handles.N_new_lon_vec(end)})
end

function N_new_layer_list1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ------------------------------- Time -----------------------------------
function N_new_t1_day_Callback(hObject, eventdata, handles)

function N_new_t1_day_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function N_new_t1_day_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function N_new_t1_sec_Callback(hObject, eventdata, handles)

function N_new_te_day_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function N_new_t1_sec_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function N_new_te_day_Callback(hObject, eventdata, handles)

function N_new_t1_sec_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function N_new_te_day_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function N_new_te_sec_Callback(hObject, eventdata, handles)

function N_new_te_sec_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function N_new_te_sec_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function N_new_tstack_Callback(hObject, eventdata, handles)

function N_new_tstack_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function N_new_tstack_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ----------------------- Apply a priori N -------------------------------
function N_new_apriori_opt_Callback(hObject, eventdata, handles)

% ----------------------- Apply weights ----------------------------------
function N_new_apriori_weights_Callback(hObject, eventdata, handles)
if get(hObject,'Value') == 1
    set(handles.N_new_sigZTD,'Enable','on')
else
    set(handles.N_new_sigZTD,'Enable','off')
end

% -------------------- LoS enter top layer -------------------------------
function N_new_enter_top_Callback(hObject, eventdata, handles)

% ----------------------- Variance a priori ------------------------------
function N_new_sigZTD_Callback(hObject, eventdata, handles)

function N_new_sigZTD_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ----------------------- Eigenvalue -------------------------------------
function N_new_eigv_Callback(hObject, eventdata, handles)

function N_new_eigv_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ----------------------- Relaxation -------------------------------------
function N_new_relax_edit_Callback(hObject, eventdata, handles)

function N_new_relax_edit_ButtonDownFcn(hObject, eventdata, handles)
if strcmp(get(hObject,'Enable'),'inactive'); set(hObject,'Enable','on'); end
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function N_new_relax_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ----------------------- # Iterations -----------------------------------
function N_new_iterations_edit_Callback(hObject, eventdata, handles)

function N_new_iterations_edit_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function N_new_iterations_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ----------------------- Stop criteria ----------------------------------
function N_new_stop1_edit_Callback(hObject, eventdata, handles)

function N_new_stop1_edit_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function N_new_stop1_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function N_new_stop2_edit_Callback(hObject, eventdata, handles)

function N_new_stop2_edit_ButtonDownFcn(hObject, eventdata, handles)
set(hObject,'Enable','On')
uicontrol(hObject)
set(hObject,'BackgroundColor',[0.94 0.87 0.87])  % light red
guidata(hObject, handles);

function N_new_stop2_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% ----------------------- Ray-tracing option -----------------------------
function N_new_ray_tracing_Callback(hObject, eventdata, handles)

% ----------------------- Interpolation y/n ------------------------------
function N_new_interp_Callback(hObject, eventdata, handles)

% ----------------------- Remove outliers ---------------------------------
function N_new_outliers_Callback(hObject, eventdata, handles)

% ----------------------- Plot differences (Nimp-Napr) -------------------
function N_new_plot_diff_Callback(hObject, eventdata, handles)
% Available points / layer
n_lat = length(handles.N_new_lat_vec);
n_lon = length(handles.N_new_lon_vec);
% Get data for selected layer
val = get(handles.N_new_layer_list1,'Value');
if get(hObject,'Value') == 0
    handles.N_new_Nimp_show = handles.N_new_Nimp(:,:,val);
    mul = 1;
else
    handles.N_new_Nimp_show = handles.N_new_Nimp(:,:,val)-handles.N_new_Napr_show;
    mul = 2;
end
% Set current axes to axes3
axes(handles.N_new_axes3);
% Set axes2 headline
set(handles.N_new_axes3_headline,'String',['Improved refractivity field [ppm] - layer' num2str(val)]);
% Plot a priori values
bar3c(handles.N_new_Nimp_show);
colormap(pink); 
% Ratio axes
if max(max(abs(handles.N_new_Nimp_show))) == 0; ratio = 0.2; else ratio = mul*max(max(abs(handles.N_new_Nimp_show)))*0.1; end
daspect([.67 1 ratio]);
axis tight; % delete empty spaces
% Set xtick and ytick and labels
set(handles.N_new_axes3,'xtick',[1,round(n_lat/2),n_lat])
set(handles.N_new_axes3,'xticklabel',{handles.N_new_lat_vec(1),handles.N_new_lat_vec(round(n_lat/2)),handles.N_new_lat_vec(end)})
set(handles.N_new_axes3,'ytick',[1,round(n_lon/2),n_lon])    
set(handles.N_new_axes3,'yticklabel',{handles.N_new_lon_vec(1),handles.N_new_lon_vec(round(n_lon/2)),handles.N_new_lon_vec(end)})
guidata(hObject, handles);

% -------------------------- Compute Nimpr -------------------------------
function N_new_output_save_Callback(hObject, eventdata, handles)
% Reset status text
set(handles.N_new_status_text,'String','Processing started!')
% Read file names in listbox
str = get(handles.N_new_input2_list,'String');
val_n = get(handles.N_new_input2_list,'Value');
%% Test available dataset
tlay = get(handles.N_new_layer_list1,'String');
if strcmp(tlay,'No layer')
    set(handles.N_new_status_text,'String','Error: Load a priori refractivity field')
        return
end
tsta = get(handles.N_new_station_list1,'String');
if strcmp(tsta,'No station')
    set(handles.N_new_status_text,'String','Error: Load observations (SWDs/STDs)')
    return
end
tcrd = get(handles.N_new_input3_list,'String');
if strcmp(tcrd,'')
    set(handles.N_new_status_text,'String','Error: Load station coordinates')
    return
end

%% Get voxel geometry
% Compute voxel edges from layers defined at center height
edges(1) = handles.N_new_H_vec(1) - (handles.N_new_H_vec(2)-handles.N_new_H_vec(1))/2;
for i = 2:length(handles.N_new_H_vec)+1
    edges(i)  = edges(i-1) + 2*(handles.N_new_H_vec(i-1)-edges(i-1));
end
% Available points and layers
n_lat = length(handles.N_new_lat_vec);
n_lon = length(handles.N_new_lon_vec);
n_H   = length(edges)-1;
% Get record number
id_lat = strcmp(handles.N_new_input2_cont,'Lat [�]');
id_lon = strcmp(handles.N_new_input2_cont,'Lon [�]');
id_H   = strcmp(handles.N_new_input2_cont,'H [m]');
id_wet = strcmp(handles.N_new_input2_cont,'Nw_apr [ppm]');
id_tot = strcmp(handles.N_new_input2_cont,'N_apr [ppm]');
%id_we2 = strcmp(handles.N_new_input2_cont,'Nw [ppm]');
% Get ellipsoidal coordinates
Lat_Napr = handles.N_new_input2_data{id_lat};
Lon_Napr = handles.N_new_input2_data{id_lon};
H_Napr   = handles.N_new_input2_data{id_H};
% Get refractivities
Nh = handles.N_new_input2_data{id_tot}-handles.N_new_input2_data{id_wet};
Nw = handles.N_new_input2_data{id_wet};
% Restore Nh/Nw for ray-tracer
ref_h = reshape(Nh,n_lon*n_lat,n_H)'; % One voxel grid point per column
ref_w = reshape(Nw,n_lon*n_lat,n_H)'; % One voxel grid point per column
phi_N = reshape(Lat_Napr,n_lon*n_lat,n_H)'; % One value per column
lam_N = reshape(Lon_Napr,n_lon*n_lat,n_H)'; % One value per column
h_N   = reshape(H_Napr,n_lon*n_lat,n_H)';   % One value per row

%% Get slant delays
% Get record number
id_sd  = strcmp(handles.N_new_input1_cont,'SWD [m]');
id_mjd = strcmp(handles.N_new_input1_cont,'MJD');
id_ele = strcmp(handles.N_new_input1_cont,'Elevation angle [�]');
id_azi = strcmp(handles.N_new_input1_cont,'Azimuth angle [�]');
% Get slant delays and directions
SD  = handles.N_new_input1_data(id_sd,:)'*1000; % m -> mm
MJD = handles.N_new_input1_data(id_mjd,:);
Sta = handles.N_new_input1_sta;
los = [handles.N_new_input1_data(id_azi,:);handles.N_new_input1_data(id_ele,:)];
% Time variables
str_day1 = get(handles.N_new_t1_day,'String');
sec1 = str2double(get(handles.N_new_t1_sec,'String'));
mjd1 = cal2jd(str2double(str_day1(1:4)),str2double(str_day1(6:7)),str2double(str_day1(9:10))) - 2400000.5 + sec1/86400;
str_daye = get(handles.N_new_te_day,'String');
sec2 = str2double(get(handles.N_new_te_sec,'String'));
mjd2 = cal2jd(str2double(str_daye(1:4)),str2double(str_daye(6:7)),str2double(str_daye(9:10))) - 2400000.5 + sec2/86400;
% Sort vectors
[MJD,rec] = sort(MJD); SD = SD(rec); Sta = Sta(rec); los = los(:,rec);
guidata(hObject, handles);
% Select all data within the defined time range
id1 = find(MJD >= mjd1-1/86400); id2 = find(MJD <= mjd2+1/86400);
SD  = SD(id1(1):id2(end));
MJD = MJD(id1(1):id2(end)); MJD_list = unique(MJD);
Sta = Sta(id1(1):id2(end));
los = los(:,id1(1):id2(end));
% Set max number of epochs
set(handles.N_new_tstack_text2,'String',sprintf('epochs (max: %d)',length(MJD_list)));

%% Get coordinates
ell = handles.N_new_input3_crd;
sta = handles.N_new_input3_sta;
% Station list
str1 = get(handles.N_new_station_list1,'String');
val1 = get(handles.N_new_station_list1,'Value');
statlist = cellstr(str1(val1));
% Check if selected stations and selected coordinates are consistent
for i = 1:length(sta)
    s = strsplit(sta{i});
    if ~strcmp(s(1),statlist{i}) || length(sta) ~= length(statlist)
        set(handles.N_new_status_text,'String','Error: Load station coordinates for selected stations')
        return
    end
end
% Number of stations
n_sta = length(statlist);

% Create waitbar
h = waitbar(0,'Please wait...','WindowStyle','modal');

%% Extract observations
tstack = get(handles.N_new_tstack,'String');
% Get Los top layer option
topl = get(handles.N_new_enter_top,'Value');
% Get ray-tracing option
rayt = get(handles.N_new_ray_tracing,'Value');
% Get output file name
file = get(handles.N_new_output_com,'String');
% Open output file for refractivity estimates
out  = fopen(file,'w');
% Get file ending to check if SWD or STD is processed
ext_sd = get(handles.N_new_input1_list,'String');
if strcmp(ext_sd{1}(end-2:end),'SWD'); opt_sd = 1; else opt_sd = 2; end
% Extract observations
if strcmp(tstack,'all') % take all epochs
    SD_t  = SD;
    MJD_t = MJD;
    Sta_t = Sta;
    los_t = los;
elseif strcmp(tstack,'1') % take first epoch
    id = find(MJD == MJD_list(1));
    SD_t  = SD(id);
    MJD_t = MJD(id);
    Sta_t = Sta(id);
    los_t = los(:,id);    
elseif str2double(tstack) > 1 % select first tstack epochs
    if str2double(tstack) > length(MJD_list)         
        tstack = sprintf('%d',length(MJD_list));
    end
    id  = find(MJD<=MJD_list(str2double(tstack)));
    SD_t  = SD(id);
    MJD_t = MJD(id);
    Sta_t = Sta(id);
    los_t = los(:,id);
else
    close(h);
    set(handles.N_new_status_text,'String',sprintf('Error: No epochs selected, redefine period or stack number'));
    return;
end

%% Set up design matrix (A) and select observations (SD_sel)
% Number of columns of design matrix A
n = n_lon*n_lat*n_H;
% Initialise variables
A = zeros(1,n); SD_top = []; elev = [];
% Counter variable
n_SD  = 1;
% Read eigenvalue threshold
eigv = str2double(get(handles.N_new_eigv,'String'));
% Loop over all stations (n_sta)
for r = 1:n_sta
    % Fill waitbar
    waitbar(r/(n_sta+1),h);
    % Get station entries
    id = strcmp(Sta_t,statlist(r));
    % Get observations for selected station
    SD_sel = SD_t(id);
    los_r  = los_t(:,id);
    % Number of observations
    n_obs = length(SD_sel);
    % Loop over all observations per station (n_obs)
    for s = 1:n_obs
        % Compute travelled distances [m] through each voxel
        % Ray-tracer (for inner and out voxel model) 
        if los_r(2,s) > 15 || rayt == 0            
            % For elevation angle > 10 degrees straight line ray-tracer
            ray = voxel_dist(phi_N(1,:),lam_N(1,:),h_N(:,1),ell(r,1),ell(r,2),ell(r,3),los_r(2,s),los_r(1,s));            
        elseif los_r(2,s) <= 15 && rayt == 1
            % For elevation angle < 10 degrees full 2D ray-tracer
            ray = voxel_dist_2D(ref_h,ref_w,phi_N,lam_N,h_N,ell(r,1),ell(r,2),ell(r,3),los_r(2,s),los_r(1,s));
            %ray = voxel_dist_2D_delay(ref_h,ref_w,phi_N,lam_N,h_N,ell(r,1),ell(r,2),ell(r,3),los_r(2,s),los_r(1,s));
            %ray2 = voxel_dist_2D_delay_mod(ref_h,ref_w,phi_N,lam_N,h_N,ell(r,1),ell(r,2),ell(r,3),los_r(2,s),los_r(1,s));
            %ray = voxel_dist_2D_outer_delay(ref_h,ref_w,phi_N,lam_N,h_N,ell(r,1),ell(r,2),ell(r,3),los_r(2,s),los_r(1,s));
            %fprintf('%s %7.3f %8.1f %7.4f %8.1f %7.4f\n',statlist{r},los_r(2,s),sum(ray.d_voxel),sum(ray.ds_w),sum(ray2.d_voxel),sum(ray2.ds_w))
        end
        % % Set d_voxel to zero if ray passes voxel only slightly (< 50 m)
        % ray.d_voxel(ray.d_voxel < 0.05) = 0;
        % Check whether LOS has to enter voxel model through top layer
        if topl == 1 && ~isempty(ray.d_voxel)
            % Take observation only if signal enters through top layer
            if ~isempty(find(ray.n_voxel(:,2) == n_H, 1))
                % Loop over all voxels
                for i = 1:length(ray.d_voxel)
                    % Compute voxel number (start sw-corner, boundary layer)              
                    num_v = ray.n_voxel(i,1) + (n_lon*n_lat) * (ray.n_voxel(i,2)-1);                        
                    % Fill design matrix
                    A(n_SD,num_v) = ray.d_voxel(i)/1000; % travelled distance [km]
                    % Set observation vector
                    SD_top(n_SD) = SD_sel(s);
                    elev(n_SD)   = los_r(2,s);
                end
                % Increase counter variable
                n_SD = n_SD + 1;
            end
        % Take all observations (if they pass at least one voxel)
        elseif topl == 0 && ~isempty(ray.d_voxel)
            % Loop over all voxels
            for i = 1:length(ray.d_voxel)
                % Compute voxel number (start: sw-corner at boundary layer)              
                num_v = ray.n_voxel(i,1) + (n_lon*n_lat) * (ray.n_voxel(i,2)-1);
                % Fill design matrix
                A(n_SD,num_v) = ray.d_voxel(i)/1000; % travelled distance [km]                    
                % Set observation vector
                SD_top(n_SD) = SD_sel(s); % -SD_out;
                elev(n_SD)   = los_r(2,s);                    
            end                
            % Increase counter variable
            n_SD = n_SD + 1;
        end       
    end
end
% Restore selected SD 
SD_sel = SD_top';

% check vector size, if empty skip processing    
if isempty(SD_sel)
    set(handles.N_new_status_text,'String',sprintf('Error: No observations available for selected stations and time period %9.3f - %9.3f',min(MJD_t),max(MJD_t)));
    close(h)
    return
end

%% Setup weight matrix (P) for selected SD
if get(handles.N_new_apriori_weights,'Value') == 1 
    % Variance of unit weight a priori
    var0 = 1; % [mm^2]
    % Standard deviation
    stdZTD = str2double(get(handles.N_new_sigZTD,'String')); % stdZTD [mm]
    % Define weights
    if max(elev) > 0
        % Elevation dependent weights (wsd)
        wsd = 1./sind(elev').^2.*stdZTD^2;
        % Covariance matrix
        cov = diag(wsd);
        % Weight matrix   
        P = diag(1./(wsd./var0));
    else        
        m = length(A(:,1)); % Number of rows of design matrix A
        % Set weights if elev is not defined or zero
        P = eye(m,m);
    end
end

%% Add a priori N/Nw to observation vector SD_sel and set '1' in A
if get(handles.N_new_apriori_opt,'Value') == 1
    % Get a priori values
    if get(handles.N_new_button_Ntot,'Value') == 1
        Napr = Nh + Nw;        
    elseif get(handles.N_new_button_Nwet,'Value') == 1
        Napr = Nw;       
    end
    % Loop over height layers
    for val = 1:n_H
        % Get a priori N/Nw for each height layer
        id_a = (val-1)*n_lon*n_lat+1;
        id_e = val*n_lon*n_lat;
        Napr_sort = Napr(id_a:id_e);
        % Define corresponding value in designmatrix
        wzd = zeros(length(Napr_sort),n);
        for i = 1:length(Napr_sort)
            % Current voxel iv
            iv = i+(n_lon*n_lat)*(val-1);
             % Set value to 1
            wzd(i,iv) = 1;
        end
        % Extend observation vector
        SD_sel = [SD_sel;Napr_sort];
        % Extend design matrix
        A = [A;wzd];
        % Clear variables
        clear Napr_sort wzd
    end    
    % If 'Apply weights' is ticked
    if get(handles.N_new_apriori_weights,'Value') == 1
        % Get sigma entries
        id_sig_t = strcmp(handles.N_new_input2_cont,'Sig N [ppm]');
        id_sig_w = strcmp(handles.N_new_input2_cont,'Sig Nw [ppm]');
        % Check if sigmas are provided by Napr file
        if any(id_sig_t)
            % Get sigmas of a priori values
            if get(handles.N_new_button_Ntot,'Value') == 1
                stdNapr = handles.N_new_input2_data{id_sig_t};
            elseif get(handles.N_new_button_Nwet,'Value') == 1
                stdNapr = handles.N_new_input2_data{id_sig_w};
            end
            % If sigmas are zero
            if max(abs(stdNapr)) == 0
                % Relative weights of 0.1*Napr
                stdNapr = 0.1*Napr;
                set(handles.N_new_status_text,'String','A priori weights were set to 0.1*N');
                % Sort standard deviation (ascending voxel number)
                stdNapr_sort = [];
                % Loop over height layers
                for val = 1:n_H
                    id_a = (val-1)*n_lon*n_lat+1;
                    id_e = val*n_lon*n_lat;
                    stdNapr_sort = [stdNapr_sort;stdNapr(id_a:id_e)];
                end
                stdNapr = stdNapr_sort;
            end
        else
            % Set relative weights of 0.1*Napr
            stdNapr = 0.1*Napr;
            set(handles.N_new_status_text,'String','A priori weights were set to 0.1*N');
            % Sort standard deviation (ascending voxel number)
            stdNapr_sort = [];
            % Loop over height layers
            for val = 1:n_H
                id_a = (val-1)*n_lon*n_lat+1;
                id_e = val*n_lon*n_lat;
                stdNapr_sort = [stdNapr_sort;stdNapr(id_a:id_e)];
            end
            stdNapr = stdNapr_sort;            
        end
        % Set all '0' values to '1' to avoid numerical problems
        stdNapr(stdNapr == 0) = 1;
        % Add variances to weight matrix P
        cov = diag([diag(cov);stdNapr.^2]);
        P = (cov./var0)^-1; % Weight matrix
    else
        m = length(A(:,1)); % Number of rows of design matrix A
        % Set weights if elev is not defined or zero
        P = eye(m,m);
    end
end

%save('C:\Work\Publications\AMT\Moeller_2018\data\Figure7\A','A');
%save('C:\Work\Publications\AMT\Moeller_2018\data\Figure7\SaveMat.mat');
%load('C:\Work\Publications\AMT\Moeller_2018\data\Figure7\SaveMat.mat');
%load('C:\Work\Publications\AMT\Moeller_2018\data\Figure7\A','A');

%% Setup unit weight matrix (P) if weights are not considered
if get(handles.N_new_apriori_weights,'Value') == 0
    % Number of rows of design matrix A
    m = length(A(:,1));
    % Set weights
    P = eye(m,m);
end 

%% Compute refractivity field N_field using More-Penrose pseudoinverse
% Number of max iterations
n_it = str2double(get(handles.N_new_iterations_edit,'String'));
% Get stop criteria
stop1 = str2double(get(handles.N_new_stop1_edit,'String'));
stop2 = str2double(get(handles.N_new_stop2_edit,'String'));
% Check inversion technique
if get(handles.N_new_button_lsq,'Value') == 1
    % Threshold for residuals
    r_sum1 = 10^8;
    % Loop with covariance matrix for unknowns as weights for next iteration
    for i = 1:n_it
        % ================= Solution 1 ===================================
        if get(handles.N_new_apriori_opt,'Value') == 0
            % Single value decomposition A = U*S*V', see Ausgleichungsrechnung I, page 33 ff.
            % U ... m x m matrix of eigenvectors (possible solution in data space)
            % S ... diagonal matrix with singular values, arranged in decreasing order, eigenvalue = singular value^2
            % V ... n x n matrix of eigenvectors (possible solution in model space)
            [U,S,V] = svd(A'*P*A); % A = U*S*V', A' = V*S'*U, inv(A) = V/S*U'
            % Number of observations to be considered for the tomography solution
            rg = length(S(S > eigv)); % Similar to rank(A) with defined tol
            % Solve equation system with relevant eigenvalues (truncated SVD)
            N_vec1 = V(:,1:rg)/S(1:rg,1:rg)*U(:,1:rg)'*A'*P*SD_sel;
            % Residuals
            res = A*N_vec1 - SD_sel;
            % Number of a priori values / observations
            n_obs = length(res);
            % Misfit function (Chi squared test)
            Chi = (res'*P*res)./length(res);
            % Redundance r derived from Hat-Matrix (Covariance matrix of the observations)
            H  = A*V(:,1:rg)/S(1:rg,1:rg)*U(:,1:rg)'*A';
            r = diag(1-H*P);
            % Variance of unit weight - a posteriori
            s0 = res'*P*res./sum(r);
            % New weights
            P = 1/s0*P;
            % RMS of weighted residuals (r_sum)
            r_sum = sqrt(res'*P*res/length(res));
            % Residual 2-norm
            r_norm = norm(res);            
            % Resolution operator
            % R = V(:,1:rg)*V(:,1:rg)';   
        
        % ================= Solution 2 ===================================
        elseif get(handles.N_new_apriori_opt,'Value') == 1
            % Number of a priori values / observations
            n_apr = size(Napr,1); n_obs = length(SD_sel)-n_apr;            
            % Observation solution
            SD1 = SD_sel(1:end-n_apr);
            A1  = A(1:end-n_apr,:);
            P1  = diag(P); P1 = diag(P1(1:end-n_apr));    
            % Solution 1
            [U,S,V] = svd(A1'*P1*A1);
            rg = length(S(S > eigv));
            N_vec1 = V(:,1:rg)/S(1:rg,1:rg)*U(:,1:rg)'*A1'*P1*SD1;
            Cxx = V(:,1:rg)/S(1:rg,1:rg)*U(:,1:rg)';
            % A priori solution
            SD0 = Napr;
            A0  = A(end-n_apr+1:end,:);
            P0  = diag(P); P0 = diag(P0(end-n_apr+1:end));
            % Solution 2
            [U,S,V] = svd(Cxx);
            rg = length(S(S > 0.00000001));
            [U,S,V] = svd(A0'*P0*A0+V(:,1:rg)/S(1:rg,1:rg)*U(:,1:rg)');
            rg = length(S(S > 0.00000001));
            N_vec1 = N_vec1 + V(:,1:rg)/S(1:rg,1:rg)*U(:,1:rg)'*A0'*P0*(SD0-A0*N_vec1);
            % Residuals
            res = A*N_vec1 - SD_sel;

            % RMS of weighted residuals (r_sum)
            r_sum = sqrt(res'*P*res/length(res));
            % Residual 2-norm
            r_norm = norm(res);
            % Compute misfit function
            Chi1 = (res(1:end-n_apr)'*P1*res(1:end-n_apr))./length(res(1:end-n_apr));
            Chi2 = ((N_vec1-Napr)'*P0*(N_vec1-Napr))./length(Napr);
            Chi  = Chi1+Chi2;
            % Variance of unit weight - a posteriori
            s0  = res'*P*res./sum(r);
            % % Apply variance component analysis
            % if get(handles.N_new_apriori_opt,'Value') == 1
            %     % Select weights of observations (P1) and a priori (P2)
            %     P1 = P(1:n_obs,1:n_obs);
            %     P2 = P(n_obs+1:end,n_obs+1:end);
            %     % Redundance r derived from Hat-Matrix H
            %     H = A*V(:,1:rg)/S(1:rg,1:rg)*U(:,1:rg)'*A';
            %     r = diag(1-H*P);
            %     % Variance of unit weight - a posteriori
            %     s0  = res'*P*res./sum(r);
            %     s01 = res'*diag([diag(P1);zeros(length(P2),1)])*res./sum(r(1:n_obs));
            %     s02 = res'*diag([zeros(length(P1),1);diag(P2)])*res./sum(r(n_obs+1:end));
            %     % New weights
            %     P = diag([1/s01*diag(P1);1/s02*diag(P2)]);              
            % end
            % Resolution operator
            % R = V(:,1:rg)*V(:,1:rg)';
        end        
        
        % Covariance matrix of the unknowns - posteriori (Qxx)
        Cxx = V(:,1:rg)/S(1:rg,1:rg)*U(:,1:rg)';
        Cxx(abs(Cxx)<0.000000001) = 0;
        
        % Standard deviation of the unknowns (refractivity field)
        stdN1 = s0.*sqrt(diag(Cxx));

        % Change of RMS
        c_rms  = (r_sum1-r_sum)/r_sum1*100;

        % Test convergence 1 - Change of RMS
        if c_rms < stop1
            set(handles.N_new_status_text,'String',sprintf('Done, convergence of %6.2f %s reached after %d Iterations',stop1,'%',i));
            % Save last output
            N_vec  = N_vec1;
            stdN   = stdN1;
            break;
        end

        % Test convergence 2 - Variance of unit weight (RMS)
        %if abs(1-s0) < 0.001 % For VCA
        if r_sum < stop2
           set(handles.N_new_status_text,'String',sprintf('Done, Convergence of %5.3f mm reached after %d Iterations',stop2,i));
           %set(handles.N_new_status_text,'String',sprintf('Done, variance of unit weight converged to 1 after %d Iterations',i));
           % Save last output
           N_vec  = N_vec1;
           stdN   = stdN1;
           break;
        end
        
        % Save last output
        r_sum1 = r_sum;
        N_vec  = N_vec1;
        stdN   = stdN1;

        % Delete outliers (observations with large residuals)         
        if get(handles.N_new_outliers,'Value') == 1
            i_res = abs(res(1:length(elev))) > 120*r_sum;
            A(i_res,:) = [];
            P = diag(P); P(i_res) = []; P = diag(P);                
            SD_sel(i_res) = [];                
        end
    end
    if i == n_it
        set(handles.N_new_status_text,'String',sprintf('Done, processing stopped after %d Iterations',i));
    end
    
%% Compute refractivity field N_field using MART
elseif get(handles.N_new_button_MART,'Value') == 1
%     % Get relaxation parameter (lam, % see Bender M. et al. 2011)
%     % ART: lam = 0.175, MART1: lam = 0.2
%     lam = str2double(get(handles.N_new_relax_edit,'String'));
%     % Number of voxels        
%     [~,n_col] = size(A);
%     % Start value
%     N0 = zeros(n_col,1)+1;
%     % Apply weights
%     if get(handles.N_new_apriori_weights,'Value') == 1
%         SD_sel = P*SD_sel;
%     end
%     % ART algorithm
%     for it = 1:n_it
%         N_vec = solver_mart(A,SD_sel,N0,lam);
%         % Test convergence 1 - Change L2 Norm between iterations
%         if norm(N0-N_vec)/norm(N_vec)*100 < stop1               
%             set(handles.N_new_status_text,'String',sprintf('Done, Convergence of %f %s reached after %d Iterations',stop1,'%',it));
%             break;
%         end
%         % Test convergence 2 - Differenz between observations and backprojection
%         if norm(SD_sel-A*N_vec,2) < stop2
%             set(handles.N_new_status_text,'String',sprintf('Done, Convergence of %f mm reached after %d Iterations',stop2,it));
%             break;
%         end
%         % Reset initial values for next iteration
%         N0 = N_vec;
%     end
%     if it == n_it
%         set(handles.N_new_status_text,'String',sprintf('Done, processing stopped after %d Iterations',it));
%     end
%     % Accuracy parameter
%     stdN  = zeros(length(N_vec),1);
end

% Bring vectors back in voxel shape (n,m,p)
handles.N_new_Nimp = reshape(N_vec,n_lon,n_lat,n_H);

%% Store results in output file
for j = 1:length(N_vec)    
    % Store data in text file
    if get(handles.N_new_button_Ntot,'Value') == 1
        fprintf(out,'%9.5f %10.5f %7.1f %6.3f %6.2f %7.2f %8.3f %7.3f %8.3f %7.3f %6.3f %6.3f\n',Lat_Napr(j),Lon_Napr(j),H_Napr(j),0,0,0,Nh(j)+Nw(j),Nw(j),N_vec(j),0,stdN(j),0);    
    elseif get(handles.N_new_button_Nwet,'Value') == 1
        fprintf(out,'%9.5f %10.5f %7.1f %6.3f %6.2f %7.2f %8.3f %7.3f %8.3f %7.3f %6.3f %6.3f\n',Lat_Napr(j),Lon_Napr(j),H_Napr(j),0,0,0,Nh(j)+Nw(j),Nw(j),0,N_vec(j),0,stdN(j));       
    end
    % if sum(A1(:,j)) == 0, flag = 0; else flag = 1; end
    % fprintf(out,'%9.5f %10.5f %7.1f %10.4f %10.4f  %d\n',Lat_Napr(j),Lon_Napr(j),H_Napr(j),N_vec(j),SD0(j),flag);
end

%% Print statistic of the tomography solution
fprintf('%5d %5d %5d %7.1f %2d %6.4f %8.2f %8.2f %5.2f %5.2f\n',size(A,2),n_obs,n_SD-1,S(1)/min(S(S>eigv)),i,eigv,norm(N_vec),r_norm,Chi,r_sum)
% 1  Number of voxels
% 2  Number of observations used
% 3  Number of observations available
% 4  2-norm condition number
% 5  Number of iterations
% 6  Threshold eigenvalue
% 7  Solution 2-norm
% 8  Residual 2-norm
% 9  Misfit function (Chi� test)
% 10 RMS of weighted residuals

%% Plot improved refractivity field
if ~isempty(handles.N_new_Nimp)
    % Get data for selected layer
    val = get(handles.N_new_layer_list1,'Value');
    if get(handles.N_new_plot_diff,'Value') == 0
        handles.N_new_Nimp_show = handles.N_new_Nimp(:,:,val);
        mul = 1;
    else
        handles.N_new_Nimp_show = handles.N_new_Nimp(:,:,val)-handles.N_new_Napr_show;
        mul = 2;
    end
    % Set current axes to axes3
    axes(handles.N_new_axes3);
    % Set axes2 headline
    set(handles.N_new_axes3_headline,'String',['Improved refractivity field [ppm] - layer' num2str(val)]);
    % Plot a priori values
    bar3c(handles.N_new_Nimp_show);
    colormap(pink); 
    % Ratio axes
    if max(max(handles.N_new_Nimp_show)) == 0; ratio = 0.2; else ratio = mul*max(max(abs(handles.N_new_Nimp_show)))*0.1; end
    daspect([.67 1 ratio]);
    axis tight; % delete empty spaces
    % Set xtick and ytick and labels
    set(handles.N_new_axes3,'xtick',[1,round(n_lat/2),n_lat])
    set(handles.N_new_axes3,'xticklabel',{handles.N_new_lat_vec(1),handles.N_new_lat_vec(round(n_lat/2)),handles.N_new_lat_vec(end)})
    set(handles.N_new_axes3,'ytick',[1,round(n_lon/2),n_lon])    
    set(handles.N_new_axes3,'yticklabel',{handles.N_new_lon_vec(1),handles.N_new_lon_vec(round(n_lon/2)),handles.N_new_lon_vec(end)})
    guidata(hObject, handles);
end
fclose(out);
guidata(hObject, handles);
% Close waitbar
close(h);

% ------------------------------- Routine --------------------------------
function N_new_output_routine_Callback(hObject, eventdata, handles)
% Read apriori file names
n = length(get(handles.N_new_input2_list,'String'));
for i = 1:n
    % Go through and load observations
    set(handles.N_new_input1_list,'Value',i)
    N_new_input1_load_Callback(hObject, eventdata, handles)
    handles = guidata(handles.N_new_input1_load);
    % Go through and load a priori files
    set(handles.N_new_input2_list,'Value',i);
    N_new_input2_load_Callback(hObject, eventdata, handles)
    handles = guidata(handles.N_new_input2_load);
    % Select stations
    n_stat = length(get(handles.N_new_station_list1,'String'));
    %n_stat = 1;
    set(handles.N_new_station_list1,'Value',[1:n_stat])
    % Load coordinates
    N_new_input3_load_Callback(hObject, eventdata, handles)
    handles = guidata(handles.N_new_input3_load);
    % Start processing    
    N_new_output_save_Callback(hObject, eventdata, handles)
    handles = guidata(handles.N_new_output_save);
end

% -------------------------- Output file name ----------------------------
function N_new_output_com_Callback(hObject, eventdata, handles)

function N_new_output_com_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% -------------------------- Clear all -----------------------------------
function N_new_clear_all_Callback(hObject, eventdata, handles)

