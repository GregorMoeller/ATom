function N = solver_art(A,SD,N,lam)

% Function solver_art applies the ART algorithm for solving the tomography
% equation system for refractivity

% Copyright (C) 2018 Gregor Moeller
% All rights reserved.
% Email: gregor.moeller@tuwien.ac.at

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.

[n_row,~] = size(A);
A_sq = sum(A.*A,2);
for i = 1:n_row
    N = N-lam*((A(i,:)*N-SD(i))/A_sq(i))*A(i,:)';
end
