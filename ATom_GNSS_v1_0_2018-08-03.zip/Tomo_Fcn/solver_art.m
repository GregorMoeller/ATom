function N = solver_art(A,SD,N,lam)

[n_row,~] = size(A);
A_sq = sum(A.*A,2);
for i = 1:n_row
    N = N-lam*((A(i,:)*N-SD(i))/A_sq(i))*A(i,:)';
end
