function voxel_geometry(i_layer,ax,handles)

% The function voxel_geometry() creates a plot including:
% 1. Voxel model structure
% 2. GNSS station coordinates
% 3. Boarder lines (optional) - not implemented so far

% Copyright (C) 2018 Gregor Moeller
% All rights reserved.
% Email: gregor.moeller@tuwien.ac.at

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% Input:
% i_layer    ... current layer scalar [1,2,...]
% handles    ... matlab global variable
% ax         ... axes in which the voxel model should be plotted

% Further parameters:
% vmin       ... voxel model lower S-W corner: lat and lon in [�], h in [km]
% vmax       ... voxel model upper N-E corner: lat and lon in [�], h in [km]
% edges      ... voxel edges [km]
% layer      ... height layers [km]
% res        ... spatial resolution dlat and dlon [�]
% ell        ... station coordinates lat and lon in [�] and Hort in [m]
% ration     ... for axes scaling

% Output
% grafic of voxel geometry

% Get GNSS station coordinates
if isfield(handles,'N_new_input3_crd') == 0; ell = []; else ell = handles.N_new_input3_crd; end    

% Compute voxel edges from layers at center height
edges(1) = handles.N_new_H_vec(1) - (handles.N_new_H_vec(2)-handles.N_new_H_vec(1))/2;
for i = 2:length(handles.N_new_H_vec)+1
    edges(i)  = edges(i-1) + 2*(handles.N_new_H_vec(i-1)-edges(i-1));
end

% Set units m to km
edges = edges./1000;

% Get lat and lon and create list
lat = handles.N_new_lat_vec;
lon = handles.N_new_lon_vec;
% Check and modify longitudes between 180� and 360�
lon(lon>180) = lon(lon>180)-360;

% existing lat (phi) and lon (lam) of the voxel model
lat = unique(lat);
lon = unique(lon);

% compute voxel model boundaries - inner model
for i = 2:length(lat)-1
    lat_v(i-1) = lat(i) - (lat(3)-lat(2))/2;
    lat_v(i)   = lat(i) + (lat(3)-lat(2))/2;    
end

for i = 2:length(lon)-1
    lon_v(i-1) = lon(i) - (lon(3)-lon(2))/2;
    lon_v(i)   = lon(i) + (lon(3)-lon(2))/2;
end

% compute voxel model boundaries - outer model
lat_v = [2*lat(1)-lat_v(1),lat_v,2*lat(end)-lat_v(end)];
lon_v = [2*lon(1)-lon_v(1),lon_v,2*lon(end)-lon_v(end)];

% Define voxel boundaries
vmin = [lat_v(1),lon_v(1),edges(1)];
vmax = [lat_v(end),lon_v(end),max(edges)];

% Set vector layer
layer = [edges(1);handles.N_new_H_vec./1000;edges(end)];

% Set ratio for axes scaling
ratio = max(edges)/(vmax(2)-vmin(2));

% Set current axes to axes1
axes(ax);

cla % Clear axes
hold on

%% Plot GNSS station coordinates
if ~isempty(ell)
    for i = 1:length(ell(:,1))        
        plot3(ell(i,1),ell(i,2),ell(i,3)/1000,'ro');
        %text(ell(i,1),ell(i,2),ell(i,3)/1000,Sta{i},'Fontsize',8,'Color','blue');
    end
end

%% Plot voxel geometry
daspect([.67 1 ratio]) % Scale axis
BoxVertices = [vmax(1) vmin(2) vmin(3); vmax(1) vmax(2) vmin(3); vmin(1) vmax(2) vmin(3); vmin(1) vmax(2) vmax(3); vmin(1) vmin(2) vmax(3); vmax(1) vmin(2) vmax(3); vmin; vmax ];
BoxFaces = [1 2 3 7; 1 2 8 6; 1 6 5 7; 7 5 4 3; 2 8 4 3; 8 6 5 4];
h = patch('Vertices',BoxVertices,'Faces',BoxFaces,'FaceColor',[1 1 .8]);
set(h, 'FaceAlpha', 0.1);  % Be aware, this option changes appearence of other axes too!!
axis tight;

% Set ticks and labels
grid on;
% Vertical grid
set(handles.N_new_axes1,'ZTick',layer(2:4:end));
set(handles.N_new_axes1,'ZTickLabel',layer(2:4:end)); 
% Horizontal grid
set(handles.N_new_axes1,'XTick',[lat(1),lat(round(length(lat)/2)),lat(end)]);
set(handles.N_new_axes1,'XTickLabel',[lat(1),lat(round(length(lat)/2)),lat(end)]);
set(handles.N_new_axes1,'YTick',[lon(1),lon(round(length(lon)/2)),lon(end)]);
set(handles.N_new_axes1,'YTickLabel',[lon(1),lon(round(length(lon)/2)),lon(end)]);

% Color current layer
LayerVertices = [vmax(1) vmin(2) edges(i_layer); vmax(1) vmax(2) edges(i_layer); vmin(1) vmax(2) edges(i_layer); vmin(1) vmax(2) edges(i_layer+1); vmin(1) vmin(2) edges(i_layer+1); vmax(1) vmin(2) edges(i_layer+1); [vmin(1),vmin(2),edges(i_layer)]; [vmax(1),vmax(2),edges(i_layer+1)] ];
LayerFaces = [1 2 3 7; 1 2 8 6; 1 6 5 7; 7 5 4 3; 2 8 4 3; 8 6 5 4];
h = patch('Vertices',LayerVertices,'Faces',LayerFaces,'FaceColor', 'blue', 'EdgeColor', 'black');
set(h, 'FaceAlpha', 0.1); % Be aware, this option changes appearence of other axes too!!

%% Set view
view(39,-26);
