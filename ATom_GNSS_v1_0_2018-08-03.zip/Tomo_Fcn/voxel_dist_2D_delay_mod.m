function ray = voxel_dist_2D_delay(ref_h,ref_w,phi_N,lam_N,h_N,phi_st,lam_st,h_st,ele,azi)
%
% This function is based on the original delay2D function from Armin Hofmeister
%
% Hofmeister, A. (2016). "Determination of path delays in the atmosphere for 
% geodetic VLBI by means of ray-tracing". PhD thesis. Department of Geodesy 
% and Geoinformation, Faculty of Mathematics and Geoinformation, Technische Universit�t Wien.
%
% It calculates the outgoing elevation angle and the different delay and mapping function
% values for one input station and one starting elevation and azimuth angle.
% The output is a structure array named *ray* which contains the results.
% 
%---------------------------------------------------------------------------------------------------
% History:
% 
% Gregor M�ller
% 14.12.2015: changed input: pres,temp,wvpr,... -> ref_h,ref_w,...
% 15.12.2015: adapt script to voxel model
% 
%---------------------------------------------------------------------------------------------------
% 
% INPUT:
%       All arrays are starting at the lowest height!
% 
%       ref_h.....   hydrostatic refractivity [ppm], matrix containing all levels
%       ref_w.....   wet refractivity [ppm], matrix containing all levels
%       phi_N.....   ellipsoidal (WGS84) latitude of refractivity [degrees]
%       lam_N.....   ellipsoidal (WGS84) longitude of refractivity [degrees]
%       h_N.......   ellipsoidal (WGS84) level heights [m], same for all grid points
%       phi_st....   ellipsoidal (WGS84) latitude of station [degrees]
%       lam_st....   ellipsoidal (WGS84) longitude of station [degrees]
%       h_st......   ellipsoidal (WGS84) of station [m]
%       ele.......   outgoing elevation angle in [�]
%       azi.......   azimuth angle in [�] 
% 
% OUTPUT:
%       ray.e0..............   starting elevation angle in [�] 
%       ray.e_out...........   outgoing elevation angle in [�] 
%       ray.dz_h............   hydrostatic zenith delay in [m]
%       ray.dz_w............   wet zenith delay in [m]
%       ray.dz_total........   total zenith delay in [m]
%       ray.ds_h............   hydrostatic slant path delay in [m]
%       ray.ds_w............   wet slant path delay in [m]
%       ray.ds_total........   total slant path delay in [m]
%       ray.geom_bend.......   total geometric bending effect in [m]
%       ray.ds_h_geom.......   hydrostatic slant path delay + geometric bending effect in [m]
%       ray.ds_total_geom...   total slant path delay + geometric bending effect in [m]
%       ray.d_voxel.........   ray path in each voxel [m]
%       ray.n_voxel.........   affected voxel [n m]
%       ray.ds_w_voxel......   wet slant path delay in each voxel [m]
%       ray.ds_h_voxel......   hydrostatic slant path delay in each voxel [m]
%       
%===================================================================================================

%% Increase vertical resolution to 5 m
% store original height values (center heights)
h_voxc = h_N(:,1);
% heights of voxel edges (h_voxel)
h_voxel    = zeros(length(h_voxc)+1,1);
h_voxel(1) = h_voxc(1,1) - (h_voxc(2,1)-h_voxc(1,1))/2;
%h_voxel(1) = 0; changed for COST Australia campaign
for i = 2:length(h_voxc)+1
    h_voxel(i)  = h_voxel(i-1) + 2*(h_voxc(i-1)-h_voxel(i-1));
end

% increase resolution
h_N = h_voxel(1):5:h_voxel(end);

% new refractivity fields
for i = 1:size(ref_h,2)
    Nh(:,i) = interp1(h_voxc,ref_h(:,i),h_N,'linear','extrap');
    Nw(:,i) = interp1(h_voxc,ref_w(:,i),h_N,'linear','extrap');
end

% set negative values to zero
Nh(Nh<0) = 0; Nw(Nw<0) = 0;

% position vector for new heights
phi_N = repmat(phi_N(1,:),size(Nh,1),1);
lam_N = repmat(lam_N(1,:),size(Nh,1),1);

% restore new values
h_N = repmat(h_N',1,size(Nh,2)); ref_w = Nw; ref_h = Nh;

%% Define, convert and calculate parameters
% define axis of reference ellipsoid (WGS84)
a=6378137.0; % equatorial axis of WGS84 reference ellipsoid in [m]
b=6356752.3142; % polar axis of WGS84 reference ellipsoid in [m]
 
% define transformation coefficient for conversion from [�] to [rad]
deg2rad=pi/180;
rad2deg=1/deg2rad;
 
% calculate gaussian radius of curvature
% see scriptum Terrestrische Bezugsrahmen
e2 = (a^2-b^2)/b^2;
cel = a^2/b;

V = sqrt(1 + e2.*cosd(phi_st).^2);
dNell = cel./V;
dMell = cel./V.^3;
R_g = sqrt(dMell.*dNell);
 
% calculate total refractivities
ref = ref_h + ref_w;
   
% define distance from earth center (Earth radius + height level)
% see scriptum Atmospheric Effects in Geodesy, equation (2.60)
r = R_g + h_N(:,1);

% --> the actual height of the station is used to calculate the refractivity there
% refractivities are calculated for this height (linear interpolation)
rref = R_g + h_st;

% first refractivity
% if the station height is below the first height level in the vector h_N
if h_st < h_N(1,1)
    % set the first refractivity values equal to the values calculated for the first entry in the
    % vector hght (=first height level)    
    nref_w = ref_w(1,:);
    nref_h = ref_h(1,:);
    nref   = ref  (1,:);
else
    % if the station height is above or equal to the first height level in the vector h_N
    % --> do a linear interpolation to get the refractivity at the desired h_N for all voxels
    for i = 1:size(h_N(1,:),2)
        nref_w(i) = interp1(h_N(:,i),ref_w(:,i),h_st,'linear');
        nref_h(i) = interp1(h_N(:,i),ref_h(:,i),h_st,'linear');
        nref(i)   = interp1(h_N(:,i),ref  (:,i),h_st,'linear');
    end
end

% all pressure levels below h_N are discarded
k = find (h_N(:,i) <= h_st);
h_N(k,:)   = [];
r(k)       = [];
ref_w(k,:) = [];
ref_h(k,:) = [];
ref(k,:)   = [];

% create new arrays with values for all height levels beginning at the station height
h_N   = [repmat(h_st,1,size(h_N,2)); h_N];
r     = [rref; r];
ref_w = [nref_w; ref_w];
ref_h = [nref_h; ref_h];
ref   = [nref  ; ref];

%% calculate mean values of refractivity between the levels
% initialize variables
mref   = zeros(size(h_N));

% calculate mean values  total, hydrostatic and wet refractivities between two levels
for i = 1:size(h_N,1)-1;
    mref_h(i,:) = (ref_h(i+1,:) + ref_h(i,:))/2;
    mref_w(i,:) = (ref_w(i+1,:) + ref_w(i,:))/2;
    mref  (i,:) = (ref  (i+1,:) + ref  (i,:))/2;
end

% last entry of mean refractivities is set to ref(end,:)
mref(length(h_N(:,1)),:) = ref(end,:);

% convert refractivities to refractive indices, because
% refractive indices (about 1.0003..) are needed for bending
% see scriptum Atmospheric Effects in Geodesy, equation (2.1)
mref = mref*1e-6 + 1;

% Grid coordinates (for zenith delay only)
nlon = length(unique(lam_N(1,:)));
lat_grid = reshape(phi_N(1,:),nlon,[]);
lon_grid = reshape(lam_N(1,:),nlon,[]);

% Horizontal interpolation to station coordinates (for zenith delay only)
for i = 1:length(mref_w(:,1))
    mref_w_st(i) = interp2(lat_grid,lon_grid,reshape(mref_w(i,:),nlon,[]),phi_st,lam_st);
    mref_h_st(i) = interp2(lat_grid,lon_grid,reshape(mref_h(i,:),nlon,[]),phi_st,lam_st);
end

%% ray-tracing - calculate intersection points of all height levels on the ray
% here the path lengths s between the levels are calucated (with light bending)
% the last value for eps is the elevation angle when the ray leaves the troposphere

% initialize variables for all intersection points on the ray path
s=zeros(length(h_N(:,1))-1,1);
z=zeros(length(h_N(:,1)),1);
y=zeros(length(h_N(:,1)),1);
eta=zeros(length(h_N(:,1)),1);
delta=zeros(length(h_N(:,1)),1);
theta=zeros(length(h_N(:,1)),1);
eps=zeros(length(h_N(:,1)),1);
phi_p=zeros(length(h_N(:,1)),1);
lam_p=zeros(length(h_N(:,1)),1);
i_pos=zeros(length(h_N(:,1)),1);
mref_w_new=zeros(length(h_N(:,1))-1,1);
mref_h_new=zeros(length(h_N(:,1))-1,1);

% set start elevation and azimuth angle [�] converted to [rad], 
e0 = ele*deg2rad; a0 = azi*deg2rad;

% stop criteria eps_final for while loop
eps_final = -90*deg2rad;

% latitude and longitude of start point
phi_p(1) = phi_st*deg2rad; lam_p(1) = lam_st*deg2rad;

% existing lat (phi) and lon (phi) of voxel model
phi_list = unique(phi_N);
lam_list = unique(lam_N);

% compute voxel model boundaries - inner model
for i = 2:length(phi_list)-1
    phi_v(i-1) = phi_list(i) - (phi_list(3)-phi_list(2))/2;
    phi_v(i)   = phi_list(i) + (phi_list(3)-phi_list(2))/2;    
end
for i = 2:length(lam_list)-1
    lam_v(i-1) = lam_list(i) - (lam_list(3)-lam_list(2))/2;
    lam_v(i)   = lam_list(i) + (lam_list(3)-lam_list(2))/2;
end

% compute voxel model boundaries - outer model
phi_v = [2*phi_list(1)-phi_v(1),phi_v,2*phi_list(end)-phi_v(end)];
lam_v = [2*lam_list(1)-lam_v(1),lam_v,2*lam_list(end)-lam_v(end)];

% get entries (i_pos) of closest voxel column
i_pos(1) = find_num_v(phi_p(1)*rad2deg,lam_p(1)*rad2deg,phi_v,lam_v);

% counter variable
n_iter = 0;

% iterate until correct outgoing elevation angle is reached (+/-0.00001 rad)
while abs(ele*deg2rad - eps_final) > 0.00001
    % reset variables
    mref_w_new=zeros(length(h_N(:,1))-1,1);
    mref_h_new=zeros(length(h_N(:,1))-1,1);
    % define values for the first point and second point on the ray
    % see scriptum Atmospheric Effects in Geodesy, equations (2.61) - (2.66)    
    % define theta1
    theta(1) = e0; % in [rad]
    % define the elevation angle at point 1
    eps(1) = e0; % in [rad]    
    % calculate distance s1 from the first to the second point
    s(1) = -r(1)*sin(theta(1)) + sqrt(r(2)^2 - r(1)^2*(cos(theta(1)))^2); % in [m]
    % define z1
    z(1) = r(1); % in [m]
    % define y1
    y(1) = 0; % in [m]
    % define z2
    z(2) = z(1) + s(1)*sin(eps(1)); % in [m]
    % define y2
    y(2) = y(1) + s(1)*cos(eps(1)); % in [m]
    % define eta1
    eta(1)   = 0; % in [rad]
    % define eta2
    eta(2)   = atan(y(2)/z(2)); % in [rad]
    % interpolate mref to current ray position
    mref_new(1) = interp2(lat_grid,lon_grid,reshape(mref(1,:),nlon,[]),phi_p(1)*180/pi,lam_p(1)*180/pi,'spline');
    mref_new(2) = interp2(lat_grid,lon_grid,reshape(mref(2,:),nlon,[]),phi_p(1)*180/pi,lam_p(1)*180/pi,'spline');
    % Set outer refractivtiy field to 1;
    mref_new(isnan(mref_new)) = 1;
    % define theta2
    % only the real part is taken in case that acos delivers a complex number (happens if e0= 0�)
    %theta(2) = real(acos(mref(1,i_pos(1))/mref(2,i_pos(1))*cos(theta(1) + eta(2)))); % in [rad]
    theta(2) = real(acos(mref_new(1)/mref_new(2)*cos(theta(1) + eta(2)))); % in [rad]
    % compute refractivities for the current ray-trace position (closest grid point)   
    %mref_w_new(1) = (ref_w(2,i_pos(1)) + ref_w(1,i_pos(1)))/2;
    %mref_h_new(1) = (ref_h(2,i_pos(1)) + ref_h(1,i_pos(1)))/2;
    % compute refractivities for the current ray-trace position (horizontal interpolation)
    % works only if voxel model is large enough, ous model mref = NaN
    mref_w_new(1) = interp2(lat_grid,lon_grid,reshape(mref_w(1,:),nlon,[]),phi_p(1)*180/pi,lam_p(1)*180/pi,'spline');
    mref_h_new(1) = interp2(lat_grid,lon_grid,reshape(mref_h(1,:),nlon,[]),phi_p(1)*180/pi,lam_p(1)*180/pi,'spline');
    % Set outer refractivtiy field to 0;
    mref_w_new(isnan(mref_w_new)) = 0;
    mref_h_new(isnan(mref_h_new)) = 0;
    %fprintf('%12.9f %12.9f %3d   1\n',mref(1,i_pos(1)),mref(2,i_pos(1)),i_pos(1));
    % calculate elevation angle at point 2
    eps(2)   = theta(2) - eta(2); % in [rad]
    
    % arc length (delta) between start point and second point
    delta(2) = eta(2);

    % latitude and longitude of second point
    phi_p(2) = asin(sin(phi_p(1))*cos(eta(2))+cos(phi_p(1))*sin(eta(2))*cos(a0));
    lam_p(2) = lam_p(1) + atan2(sin(a0),(cot(eta(2))*cos(phi_p(1))-sin(phi_p(1))*cos(a0)));    
    
    % get entries (i_pos) of closest voxel column
    i_pos(2) = find_num_v(phi_p(2)*rad2deg,lam_p(2)*rad2deg,phi_v,lam_v);
    
    % loop over all remaining height levels (from 2 to end-1)
    % calculate intersection points on the ray
    % see scriptum Atmospheric Effects in Geodesy, equations (2.67) - (2.72)
    for i = 2:length(h_N(:,1))-1;
        s(i) = -r(i)*sin(theta(i)) + sqrt(r(i+1)^2 - r(i)^2*(cos(theta(i)))^2); % in [m]
        z(i+1) = z(i) + s(i)*sin(eps(i)); % in [m]
        y(i+1) = y(i) + s(i)*cos(eps(i)); % in [m]
        eta(i+1) = atan(y(i+1)/z(i+1)); % in [rad]
        delta(i+1) = eta(i+1) - eta(i); % in [rad]
        % interpolat mref to current ray position
        mref_new(1) = interp2(lat_grid,lon_grid,reshape(mref(i,:)  ,nlon,[]),phi_p(i)*180/pi,lam_p(i)*180/pi,'spline');
        mref_new(2) = interp2(lat_grid,lon_grid,reshape(mref(i+1,:),nlon,[]),phi_p(i)*180/pi,lam_p(i)*180/pi,'spline');           
        % Set outer refractivtiy field to 1;
        mref_new(isnan(mref_new)) = 1;
        % define theta2
        %theta(i+1) = real(acos(mref(i,i_pos(i))/mref(i+1,i_pos(i))*cos(theta(i) + delta(i+1)))); % in [rad]
        theta(i+1) = real(acos(1*cos(theta(i) + delta(i+1)))); % in [rad]
        %fprintf('%12.9f %12.9f %3d %3d\n',mref(i,i_pos(i)),mref(i+1,i_pos(i)),i_pos(i),i);
        eps(i+1) = theta(i+1) - eta(i+1); % in [rad]
        phi_p(i+1) = asin(sin(phi_p(1))*cos(eta(i+1))+cos(phi_p(1))*sin(eta(i+1))*cos(a0)); % in [rad]
        lam_p(i+1) = lam_p(1) + atan2(sin(a0),(cot(eta(i+1))*cos(phi_p(1))-sin(phi_p(1))*cos(a0))); % in [rad]                
        % compute refractivities for the current ray-trace position (closest grid point)        
        %mref_w_new(i) = (ref_w(i+1,i_pos(i)) + ref_w(i,i_pos(i)))/2;
        %mref_h_new(i) = (ref_h(i+1,i_pos(i)) + ref_h(i,i_pos(i)))/2;
        % compute refractivities for the current ray-trace position (horizontal interpolation)
        % works only if voxel model is large enough, ous model mref = NaN
        mref_w_new(i) = interp2(lat_grid,lon_grid,reshape(mref_w(i,:),nlon,[]),phi_p(i)*180/pi,lam_p(i)*180/pi,'spline');
        mref_h_new(i) = interp2(lat_grid,lon_grid,reshape(mref_h(i,:),nlon,[]),phi_p(i)*180/pi,lam_p(i)*180/pi,'spline');      
        % Set outer refractivtiy field to 0;
        mref_w_new(isnan(mref_w_new)) = 0;
        mref_h_new(isnan(mref_h_new)) = 0;
        % get entries (i_pos) of closest voxel column
        i_pos(i+1) = find_num_v(phi_p(i+1)*rad2deg,lam_p(i+1)*rad2deg,phi_v,lam_v);
        % check if ray is still inside voxel model
        %if phi_p(i+1)*rad2deg >= phi_v(end) || phi_p(i+1)*rad2deg <= phi_v(1) || lam_p(i+1)*rad2deg >= lam_v(end) || lam_p(i+1)*rad2deg < lam_v(1)
        %    n_iter = 10
        %    break;
        %end
    end
    
    % define bending correction at voxel top according to [Hobiger 2008a]
    g_bend_end = 0.02*exp(-h_N(end)/6000)/tand(ele);
    % get final (=outgoing) elevation angle
    eps_final = eps(i+1) - g_bend_end*deg2rad; % + g_bend_end*deg2rad; 
    
    % Set start elevtation angle for the next iteration (max iteration: 10)
    if n_iter < 5
        e0 = e0 + (ele*deg2rad - eps_final);
        n_iter = n_iter + 1;
    else
        break;
    end
end

% % Output ray path coordinates
% for i = 1:length(phi_p)
%     fprintf('%8.5f  %8.5f  %7.1f\n',phi_p(i)*rad2deg,lam_p(i)*rad2deg,h_N(i))
% end

%% ray-tracing
% initialize variables
dgeo = zeros(length(eps)-1,1);
dh   = zeros(length(h_N(:,1))-1,1);

% convert starting and outgoing elevation angle from [rad] to [�]
ray.e0 = e0*rad2deg;
ray.e_out = eps_final*rad2deg;

% get entries inside the voxel model
id_in  = find(phi_p*rad2deg <= phi_v(end) & phi_p*rad2deg >= phi_v(1) & lam_p*rad2deg <= lam_v(end) & lam_p*rad2deg >= lam_v(1));
% Remove last entry
id_in(end) = [];

for n = 1:length(id_in) %length(i_pos)-1
    % calculate bending effect for each height level
    % see scriptum Atmospheric Effects in Geodesy, equation (2.75)
    dgeo(n) = s(n) - cos(eps(n)-eps_final)*s(n); % in [m]  

    % calculate height differences between levels in zenith direction
    dh(n) = h_N(n+1,1) - h_N(n,1); % in [m]

    % calculate hydrostatic zenith delay
    % see scriptum Atmospheric Effects in Geodesy, equation (2.74)    
    %ray.dz_h(n) = ((mref_h(n)*1e-6)*dh(n)); % in [m]
    ray.dz_h(n) = ((mref_h_st(n)*1e-6)*dh(n)); % in [m]
    
    % calculate wet zenith delay
    % see scriptum Atmospheric Effects in Geodesy, equation (2.74)
    %ray.dz_w(n) = ((mref_w(n)*1e-6)*dh(n)); % in [m]
    ray.dz_w(n) = ((mref_w_st(n)*1e-6)*dh(n)); % in [m]

    % calculate total zenith delay
    ray.dz_total(n) = ray.dz_h(n)+ray.dz_w(n); % in [m]

    % calculate hydrostatic slant delay
    % see scriptum Atmospheric Effects in Geodesy, equation (2.74)
    ray.ds_h(n) = ((mref_h_new(n)*1e-6)*s(n)); % in [m]

    % calculate wet slant delay
    % see scriptum Atmospheric Effects in Geodesy, equation (2.74)
    ray.ds_w(n) = ((mref_w_new(n)*1e-6)*s(n)); % in [m]

    % calculate total slant delay
    ray.ds_total(n) = ray.ds_h(n)+ray.ds_w(n); % in [m]
end

% delete lowest entries
h_N(1,:) = [];
i_pos(1) = [];

% get indices of traversed voxels
i_vox = unique(i_pos(id_in));

% initialise variable and equal vectors
ray.d_voxel    = [];
ray.n_voxel    = [];
ray.geom_bend_voxel = [];

% counter variable
n = 0;

%% Path lengths in each traversed voxel
for j = 1:length(h_voxel)-1
    % all signal fractions  - vertical seperation
    ind2 = find(h_N(id_in,1) > h_voxel(j) & h_N(id_in,1) <= h_voxel(j+1));
    for i = 1:length(i_vox)
        % all signal fractions - horizontal seperation
        ind1 = find(i_pos(id_in) == i_vox(i));
        ind  = intersect(ind1,ind2);
        if ~isempty(ind)
            n = n + 1;
            % Bending effect in each voxel
            ray.geom_bend_voxel(n) = sum(dgeo(id_in(ind)));
            % Ray path in each voxel including bending!!
            ray.d_voxel(n)   = sum(s(id_in(ind))) + ray.geom_bend_voxel(n);
            % Affected voxel
            ray.n_voxel(n,:) = [i_vox(i);j];
        end
    end
end

% % calculate total geometric bending effect
% ray.geom_bend=sum(dgeo); % in [m]
% % 
% % % hydrostatic slant delay + geometric bending effect
% % ray.ds_h_geom = ray.ds_h+ray.geom_bend; % in [m]
% % 
% % % calculate total slant delay + geometric bending effect
% % ray.ds_total_geom = ray.ds_total+ray.geom_bend;% in [m]
% % 
% % %ray

end
