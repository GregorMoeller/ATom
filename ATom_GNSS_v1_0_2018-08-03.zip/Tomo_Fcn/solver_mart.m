function N = solver_mart(A,SD,N,lam)

[n_row,n_col] = size(A);
A_sq = sum(A.*A,2);
for i = 1:n_row
    A_N = A(i,:)*N;
    for j = 1:n_col
        N(j) = N(j).*(SD(i)./A_N)^(lam*A(i,j)/sqrt(A_sq(i)));
    end
end

%         N0    = zeros(N,1); % A priori refractivity field
%         lam   = 0.2;        % Relaxation factor 0.2 for MART1, see Bender M. et al. 2011
%         for k = 1:1 % Iterations 100-200 optimal
%             for i = 1:M % Number of SWDs (313 in this test case)
%                 % Algebraic reconstruction technique (ART)
%                 N0
%                 lam
%                 SD_sel(i)
%                 A(i,:)*N0
%                 sum(A.*A,2)
%                 A(i,:)'
%                 N0 = N0 + lam*((SD_sel(i)-A(i,:)*N0)/sum(A.*A,2))*A(i,:)'
%                 % Multiple ART (MART1)
%                 N0(j)*(SD_sel(i)/dot(A(i,:),N0)).^(lam*A(i,j)/sqrt(dot(A(i,:),A(i,:))))
%             end
%             % Add Gaussien constraints on un-traveresed voxels
%         end
