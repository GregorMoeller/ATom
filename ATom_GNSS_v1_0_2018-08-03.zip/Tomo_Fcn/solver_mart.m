function N = solver_mart(A,SD,N,lam)

% Function solver_art applies the MART algorithm for solving the tomography
% equation system for refractivity

% Copyright (C) 2018 Gregor Moeller
% All rights reserved.
% Email: gregor.moeller@tuwien.ac.at

% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.

[n_row,n_col] = size(A);
A_sq = sum(A.*A,2);
for i = 1:n_row
    A_N = A(i,:)*N;
    for j = 1:n_col
        N(j) = N(j).*(SD(i)./A_N)^(lam*A(i,j)/sqrt(A_sq(i)));
    end
end

