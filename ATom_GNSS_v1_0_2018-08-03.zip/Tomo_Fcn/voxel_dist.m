function ray = voxel_dist(phi_N,lam_N,h_N,phi_st,lam_st,h_st,ele,azi)
%
% This function is based on the original delay2D function from Armin Hofmeister
%
% Hofmeister, A. (2016). "Determination of path delays in the atmosphere for 
% geodetic VLBI by means of ray-tracing". PhD thesis. Department of Geodesy 
% and Geoinformation, Faculty of Mathematics and Geoinformation, Technische Universit�t Wien.
%
% It calculates the straight ray paths within each voxel. The output is a 
% structure array named *ray* which contains the results.
% 
%---------------------------------------------------------------------------------------------------
% History:
% 
% Gregor M�ller
% 30.03.2017: adapt script to voxel model
% 
%---------------------------------------------------------------------------------------------------
% 
% INPUT:
%       All arrays are starting at the lowest height!
% 
%       phi_N.....   ellipsoidal (WGS84) latitude of voxel center point [degrees]
%       lam_N.....   ellipsoidal (WGS84) longitude of voxel center point [degrees]
%       h_N.......   ellipsoidal (WGS84) level heights [m]
%       phi_st....   ellipsoidal (WGS84) latitude of station [degrees]
%       lam_st....   ellipsoidal (WGS84) longitude of station [degrees]
%       h_st......   ellipsoidal (WGS84) height of station [m]
%       ele.......   outgoing elevation angle in [�]
%       azi.......   azimuth angle in [�] 
% 
% OUTPUT:
%       ray.d_voxel.........   ray path in each voxel [m]
%       ray.n_voxel.........   affected voxel [n m]    
%       
%===================================================================================================

%% Initialise parameters
% define transformation coefficient for conversion from [�] to [rad]
deg2rad=pi/180;
rad2deg=1/deg2rad;

% existing lat (phi) and lon (lam) of the voxel model
phi_list = unique(phi_N);
lam_list = unique(lam_N);

% compute voxel model boundaries - inner model
for i = 2:length(phi_list)-1
    phi_v(i-1) = phi_list(i) - (phi_list(3)-phi_list(2))/2;
    phi_v(i)   = phi_list(i) + (phi_list(3)-phi_list(2))/2;    
end
for i = 2:length(lam_list)-1
    lam_v(i-1) = lam_list(i) - (lam_list(3)-lam_list(2))/2;
    lam_v(i)   = lam_list(i) + (lam_list(3)-lam_list(2))/2;
end

% compute voxel model boundaries - outer model
phi_v = [2*phi_list(1)-phi_v(1),phi_v,2*phi_list(end)-phi_v(end)];
lam_v = [2*lam_list(1)-lam_v(1),lam_v,2*lam_list(end)-lam_v(end)];

% store original height values (center heights)
h_voxc = h_N;

% heights of voxel edges (h_voxel)
h_voxel    = zeros(length(h_voxc)+1,1);
h_voxel(1) = h_voxc(1) - (h_voxc(2)-h_voxc(1))/2;
for i = 2:length(h_voxc)+1
    h_voxel(i) = h_voxel(i-1) + 2*(h_voxc(i-1)-h_voxel(i-1));
end

%% Define ellipsoid and compute Gaussian radius (R_g) for given station
% define axis of reference ellipsoid (WGS84)
a=6378137.0; % equatorial axis of WGS84 reference ellipsoid in [m]
b=6356752.3142; % polar axis of WGS84 reference ellipsoid in [m]
 
% calculate gaussian radius of curvature
% see scriptum Terrestrische Bezugsrahmen
e2 = (a^2-b^2)/b^2;
cel = a^2/b;

V = sqrt(1 + e2.*cosd(phi_st).^2);
dNell = cel./V;
dMell = cel./V.^3;
R_g = sqrt(dMell.*dNell);


%% Determine height levels for given voxel grid
% Complement angle to azimuth (az), see law of sin
sin_az = sind(azi)*cosd(phi_st)./cosd(phi_v); % Eq. 74 Ray-tracing_geometry.pdf
az = asind(sin_az(abs(sin_az) <=1));

% Geocentric angle for lon and lat
eta_lon = acotd(sind(azi)./tand(lam_v-lam_st)./cosd(phi_st)+tand(phi_st)*cosd(azi)); % Hofmeister PhD, p. 78
eta_lat1 = atan2(tand((phi_st-phi_v(abs(sin_az) <=1))/2).*sind((azi+az)/2),sind((azi-az)/2))*360/pi;
az = 180 - az; % asin has two solutions: az and 180-az
eta_lat2 = atan2(tand((phi_st-phi_v(abs(sin_az) <=1))/2).*sind((azi+az)/2),sind((azi-az)/2))*360/pi;
eta_lat = [eta_lat1,eta_lat2];

% Compute height for given voxel model boundaries
h_lat = (cosd(ele)./cosd(ele+eta_lat)-1)*R_g + h_st;
h_lon = (cosd(ele)./cosd(ele+eta_lon)-1)*R_g + h_st;

% extract all relevant height levels
h_N = unique([h_lat,h_lon,h_voxel']);
h_N = h_N(h_N>0&h_N<=h_voxel(end));

% define distance from earth center (Earth radius + height level)
% see scriptum Atmospheric Effects in Geodesy, equation (2.60)
r = R_g + h_N';

% all pressure levels below h_N are discarded
k = find(h_N <= h_st);
h_N(k) = [];
r(k)   = [];

% create new arrays with values for all height levels beginning at the station height
h_N = [h_st,h_N];
r   = [R_g+h_st; r];


%% ray-tracing - calculate intersection points of all height levels on the ray
% here the path lengths s between the levels are calucated (with light bending)
% the last value for eps is the elevation angle when the ray leaves the troposphere

% initialize variables for all intersection points on the ray path
s=zeros(length(h_N(:,1))-1,1);
z=zeros(length(h_N(:,1)),1);
y=zeros(length(h_N(:,1)),1);
eta=zeros(length(h_N(:,1)),1);
delta=zeros(length(h_N(:,1)),1);
theta=zeros(length(h_N(:,1)),1);
phi_p=zeros(length(h_N(:,1)),1);
lam_p=zeros(length(h_N(:,1)),1);
i_pos=zeros(length(h_N(:,1)),1);

% set start elevation and azimuth angle [�] converted to [rad], 
e0 = ele*deg2rad; a0 = azi*deg2rad;

% latitude and longitude of start point
phi_p(1) = phi_st*deg2rad; lam_p(1) = lam_st*deg2rad;

% get entries (i_pos) of closest voxel column
i_pos(1) = find_num_v(phi_p(1)*rad2deg,lam_p(1)*rad2deg,phi_v,lam_v);

% define values for the first point and second point on the ray
% see scriptum Atmospheric Effects in Geodesy, equations (2.61) - (2.66)    
% define theta1
theta(1) = e0; % in [rad]
% calculate distance s1 from the first to the second point
s(1) = -r(1)*sin(theta(1)) + sqrt(r(2)^2 - r(1)^2*(cos(theta(1)))^2); % in [m]
% define z1
z(1) = r(1);
% define z2
z(2) = z(1) + s(1)*sin(e0); % in [m]
% define y2 (y1 = 0)
y(2) = s(1)*cos(e0); % in [m]
% define eta1
eta(1)   = 0; % in [rad]
% define eta2
eta(2)   = atan(y(2)/z(2)); % in [rad]
% define theta2
theta(2) = acos(cos(theta(1) + eta(2))); % in [rad]

% arc length (delta) between start point and second point
delta(2) = eta(2);

% latitude and longitude of second point
phi_p(2) = asin(sin(phi_p(1))*cos(eta(2))+cos(phi_p(1))*sin(eta(2))*cos(a0));
lam_p(2) = lam_p(1) + atan2(sin(a0),(cot(eta(2))*cos(phi_p(1))-sin(phi_p(1))*cos(a0)));

% get entries (i_pos) of closest voxel column
i_pos(2) = find_num_v(phi_p(2)*rad2deg,lam_p(2)*rad2deg,phi_v,lam_v);
    
% loop over all remaining height levels (from 2 to end-1)
% see scriptum Atmospheric Effects in Geodesy, equations (2.67) - (2.72)
% and PhD thesis Armin Hofmeister p.78ff

for i = 2:length(h_N)-1
    s(i) = -r(i)*sin(theta(i)) + sqrt(r(i+1)^2 - r(i)^2*(cos(theta(i)))^2); % in [m]
    z(i+1) = z(i) + s(i)*sin(e0); % in [m]
    y(i+1) = y(i) + s(i)*cos(e0); % in [m]
    eta(i+1) = atan(y(i+1)/z(i+1)); % in [rad]
    delta(i+1) = eta(i+1) - eta(i); % in [rad]
    theta(i+1) = acos(cos(theta(i) + delta(i+1))); % in [rad]
    phi_p(i+1) = asin(sin(phi_p(1))*cos(eta(i+1))+cos(phi_p(1))*sin(eta(i+1))*cos(a0)); % in [rad]
    lam_p(i+1) = lam_p(1) + atan2(sin(a0),(cot(eta(i+1))*cos(phi_p(1))-sin(phi_p(1))*cos(a0))); % in [rad]                
    % get entries (i_pos) of closest voxel column
    i_pos(i+1) = find_num_v(phi_p(i+1)*rad2deg,lam_p(i+1)*rad2deg,phi_v,lam_v);
end

% % Output ray path coordinates
% for i = 1:length(phi_p)
%     fprintf('%7.5f  %7.5f  %7.1f\n',phi_p(i)*rad2deg,lam_p(i)*rad2deg,h_N(i))
% end

% get entries inside the voxel model
id_in  = phi_p*rad2deg <= phi_v(end) & phi_p*rad2deg >= phi_v(1) & lam_p*rad2deg <= lam_v(end) & lam_p*rad2deg >= lam_v(1);

% counter variable
n = find((h_N(id_in(1)) - h_voxel) < 0,1,'first') - 1; %n = 1;

% path lengths in each traversed voxel
for j = 1:length(h_N(id_in))-1  
    if ~isempty(intersect(h_voxel,h_N(j)))
        n = n + 1;           
    end
    % Ray path in each voxel
    ray.d_voxel(j)   = s(j);      
    % Affected voxel
    ray.n_voxel(j,:) = [i_pos(j+1);n]; 
end


