function [i_pos] = find_num_v(phi_p,lam_p,phi_v,lam_v)

% The function find_num_v checks in which voxel (phi_v,lam_v)
% a point (phi_p,lam_p) is located

% Input
% phi_p    ... latitude point [degrees]
% lam_p    ... longitude point [degrees]
% phi_v    ... latidudes voxel model [degrees]
% lam_v    ... longitudes voxel models [degrees]

% Output
% i_pos    ... voxel id

% Computde differences
dphi = phi_p-phi_v;
dlam = lam_p-lam_v;

% Get index of phi / lam
n_lat = find(dphi>=0,1,'last');
n_lon = find(dlam>=0,1,'last');

% Correct index if outside
if isempty(n_lat)
    n_lat = 1;
end
if isempty(n_lon)
    n_lon = 1;
end
if n_lon == length(lam_v)
    n_lon = n_lon - 1;
end
if n_lat == length(phi_v)
    n_lat = n_lat - 1;
end

% Compute voxel id
i_pos = n_lon + (length(lam_v)-1)*(n_lat-1);



